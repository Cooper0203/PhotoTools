package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var fb: FacebookSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        fb = FacebookSection(this)
        setContentView(fb.view)
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fb.onActivityResult(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        Uploader.onChange = null
        super.onDestroy()
    }
}
