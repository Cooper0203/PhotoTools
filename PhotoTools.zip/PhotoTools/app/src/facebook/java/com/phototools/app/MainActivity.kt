package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var fb: FacebookSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fb = FacebookSection(this)
        val box = Ui.column(this)
        box.addView(fb.view)
        setContentView(Ui.scroll(this, box))
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fb.onActivityResult(requestCode, resultCode, data)
    }
}
