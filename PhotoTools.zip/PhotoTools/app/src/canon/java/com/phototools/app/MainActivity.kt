package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var canon: CanonSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        canon = CanonSection(this, false, false)
        setContentView(canon.view)
        canon.onCreate(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        canon.onNewIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        canon.onConfigChanged()
    }

    override fun onDestroy() {
        canon.onDestroy()
        super.onDestroy()
    }
}
