package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var canon: CanonSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        canon = CanonSection(this, false, false)
        canon.view.setPadding(0, 40, 0, 0)
        setContentView(canon.view)
        canon.onCreate(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        canon.onNewIntent(intent)
    }

    override fun onDestroy() {
        canon.onDestroy()
        super.onDestroy()
    }
}
