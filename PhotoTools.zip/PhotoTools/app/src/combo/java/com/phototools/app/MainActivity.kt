package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle

class MainActivity : Activity() {
    private lateinit var section: CanonSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        section = CanonSection(this, true)
        setContentView(section.view)
        section.onCreate(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        section.onNewIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        section.onConfigChanged()
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        section.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Compatibility callback")
    override fun onBackPressed() {
        if (!section.onBack()) super.onBackPressed()
    }

    override fun onDestroy() {
        section.onDestroy()
        super.onDestroy()
    }
}
