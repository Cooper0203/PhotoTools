package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle

class MainActivity : Activity() {
    private var section: CanonSection? = null
    private var pending: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        pending = intent
        if (Roles.remembered(this)) start(Roles.get(this)) else chooseRole()
    }

    private fun chooseRole() {
        section?.onDestroy()
        section = null
        setContentView(RoleScreen.build(this, "Android Photobooth") { role, remember ->
            Roles.set(this, role, remember)
            start(role)
        })
    }

    private fun start(role: Int) {
        val s = CanonSection(this, true, role) { changeMode() }
        section = s
        setContentView(s.view)
        s.onCreate(pending)
        pending = null
    }

    private fun changeMode() {
        if (Roles.get(this) == Roles.SERVER) ServerService.stop(this)
        Roles.app(this).edit().putBoolean("role_remember", false).apply()
        chooseRole()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val s = section
        if (s != null) s.onNewIntent(intent) else pending = intent
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        section?.onConfigChanged()
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        section?.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Compatibility callback")
    override fun onBackPressed() {
        if (section?.onBack() != true) super.onBackPressed()
    }

    override fun onDestroy() {
        section?.onDestroy()
        super.onDestroy()
    }
}
