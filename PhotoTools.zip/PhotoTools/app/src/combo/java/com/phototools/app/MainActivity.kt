package com.phototools.app

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.View

class MainActivity : Activity() {
    private lateinit var canon: CanonSection
    private lateinit var fb: FacebookSection

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        canon = CanonSection(this, true, true)
        fb = FacebookSection(this)
        canon.extraChange = { fb.refresh() }
        val box = Ui.column(this)
        box.addView(canon.view)
        box.addView(View(this).apply {
            setBackgroundColor(0xFFBBBBBB.toInt())
            layoutParams = android.widget.LinearLayout.LayoutParams(-1, 3).apply { setMargins(0, 48, 0, 48) }
        })
        box.addView(fb.view)
        setContentView(Ui.scroll(this, box))
        canon.onCreate(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        canon.onNewIntent(intent)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        canon.onConfigChanged()
    }

    override fun onResume() {
        super.onResume()
        fb.refresh()
    }

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        fb.onActivityResult(requestCode, resultCode, data)
    }

    override fun onDestroy() {
        canon.onDestroy()
        super.onDestroy()
    }
}
