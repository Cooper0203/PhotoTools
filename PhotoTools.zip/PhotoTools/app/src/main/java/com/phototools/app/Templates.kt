package com.phototools.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class Slot(val x: Int, val y: Int, val w: Int, val h: Int)

class Template(
    val id: String,
    val name: String,
    val wPx: Int,
    val hPx: Int,
    val wIn: Double,
    val hIn: Double,
    val bg: Int,
    val hasOverlay: Boolean,
    val slots: List<Slot>
) {
    fun sizeText(): String = String.format(
        Locale.US, "%.1f x %.1f cm  |  %.2f x %.2f in  |  %d x %d px",
        wIn * 2.54, hIn * 2.54, wIn, hIn, wPx, hPx
    )
}

object TemplateStore {
    private fun file(c: Context) = File(c.filesDir, "templates.json")
    fun overlayFile(c: Context, id: String) = File(c.filesDir, "tpl_$id.png")

    fun load(c: Context): MutableList<Template> {
        val out = ArrayList<Template>()
        try {
            val f = file(c)
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val sa = o.getJSONArray("slots")
                val slots = ArrayList<Slot>()
                for (k in 0 until sa.length()) {
                    val s = sa.getJSONArray(k)
                    slots.add(Slot(s.getInt(0), s.getInt(1), s.getInt(2), s.getInt(3)))
                }
                out.add(Template(
                    o.getString("id"), o.getString("name"), o.getInt("wPx"), o.getInt("hPx"),
                    o.getDouble("wIn"), o.getDouble("hIn"), o.getInt("bg"), o.getBoolean("overlay"), slots
                ))
            }
        } catch (_: Exception) {}
        return out
    }

    fun save(c: Context, list: List<Template>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("id", t.id); o.put("name", t.name)
            o.put("wPx", t.wPx); o.put("hPx", t.hPx)
            o.put("wIn", t.wIn); o.put("hIn", t.hIn)
            o.put("bg", t.bg); o.put("overlay", t.hasOverlay)
            val sa = JSONArray()
            for (s in t.slots) sa.put(JSONArray().put(s.x).put(s.y).put(s.w).put(s.h))
            o.put("slots", sa)
            arr.put(o)
        }
        file(c).writeText(arr.toString())
    }

    fun delete(c: Context, id: String) { try { overlayFile(c, id).delete() } catch (_: Exception) {} }
}

object TemplateTools {
    fun toPx(unit: String, v: Double, dpi: Double): Double = when (unit) {
        "cm" -> v / 2.54 * dpi
        "mm" -> v / 25.4 * dpi
        "inch" -> v * dpi
        else -> v
    }

    fun toInches(unit: String, v: Double, dpi: Double): Double = when (unit) {
        "cm" -> v / 2.54
        "mm" -> v / 25.4
        "inch" -> v
        else -> v / dpi
    }

    fun fromInches(unit: String, inches: Double, dpi: Double): Double = when (unit) {
        "cm" -> inches * 2.54
        "mm" -> inches * 25.4
        "inch" -> inches
        else -> inches * dpi
    }

    fun gridSlots(w: Int, h: Int, rows: Int, cols: Int, marginPct: Double, gapPct: Double): List<Slot> {
        val r = max(1, rows)
        val c = max(1, cols)
        val margin = min(w, h) * marginPct / 100.0
        val gap = min(w, h) * gapPct / 100.0
        val cw = max(10.0, (w - 2 * margin - gap * (c - 1)) / c)
        val ch = max(10.0, (h - 2 * margin - gap * (r - 1)) / r)
        val out = ArrayList<Slot>()
        for (ri in 0 until r) for (ci in 0 until c) {
            out.add(Slot((margin + ci * (cw + gap)).toInt(), (margin + ri * (ch + gap)).toInt(), cw.toInt(), ch.toInt()))
        }
        return out
    }

    /** Finds transparent "windows" in a template PNG (connected transparent areas). */
    fun detectSlots(src: Bitmap): List<Slot> {
        val sc = min(1f, 500f / max(src.width, src.height))
        val sw = max(1, (src.width * sc).toInt())
        val sh = max(1, (src.height * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, false)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        val hole = BooleanArray(sw * sh) { (px[it] ushr 24) < 40 }
        val seen = BooleanArray(sw * sh)
        val queue = IntArray(sw * sh)
        val found = ArrayList<Slot>()
        for (start in hole.indices) {
            if (!hole[start] || seen[start]) continue
            var head = 0
            var tail = 0
            queue[tail++] = start
            seen[start] = true
            var minX = sw
            var minY = sh
            var maxX = 0
            var maxY = 0
            var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % sw
                val y = p / sw
                area++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && hole[p - 1] && !seen[p - 1]) { seen[p - 1] = true; queue[tail++] = p - 1 }
                if (x < sw - 1 && hole[p + 1] && !seen[p + 1]) { seen[p + 1] = true; queue[tail++] = p + 1 }
                if (y > 0 && hole[p - sw] && !seen[p - sw]) { seen[p - sw] = true; queue[tail++] = p - sw }
                if (y < sh - 1 && hole[p + sw] && !seen[p + sw]) { seen[p + sw] = true; queue[tail++] = p + sw }
            }
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            if (area < sw * sh * 0.01) continue
            if (bw >= sw * 0.97 && bh >= sh * 0.97) continue
            if (area < bw * bh * 0.5) continue
            found.add(Slot((minX / sc).toInt(), (minY / sc).toInt(), (bw / sc).toInt() + 1, (bh / sc).toInt() + 1))
        }
        val rowTol = src.height * 0.08
        return found.sortedWith(compareBy({ Math.round(it.y / rowTol) }, { it.x }))
    }

    /** Decodes so the result is at least maxW x maxH (for filling a window). */
    fun decodeCover(ctx: Context, uri: Uri, maxW: Int, maxH: Int): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val s = max(1, min(info.size.width / max(1, maxW), info.size.height / max(1, maxH)))
            if (s > 1) dec.setTargetSampleSize(s)
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    /** Decodes so the longest side is at most cap pixels (full quality viewing). */
    fun decodeFit(ctx: Context, uri: Uri, cap: Int, software: Boolean): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            val s = max(1, (max(info.size.width, info.size.height) + cap - 1) / cap)
            if (s > 1) dec.setTargetSampleSize(s)
            if (software) dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    }

    fun drawCover(cv: Canvas, b: Bitmap, dst: RectF, p: Paint) {
        val sc = max(dst.width() / b.width, dst.height() / b.height)
        val sw = dst.width() / sc
        val sh = dst.height() / sc
        val sx = (b.width - sw) / 2f
        val sy = (b.height - sh) / 2f
        cv.save()
        cv.clipRect(dst)
        cv.drawBitmap(b, Rect(sx.toInt(), sy.toInt(), (sx + sw).toInt(), (sy + sh).toInt()), dst, p)
        cv.restore()
    }

    /** Builds the final full-size picture: background, photos in the windows, template on top. */
    fun compose(ctx: Context, t: Template, uris: List<Uri?>): Bitmap {
        val out = Bitmap.createBitmap(t.wPx, t.hPx, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(t.bg)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        for ((i, s) in t.slots.withIndex()) {
            val u = uris.getOrNull(i) ?: continue
            try {
                val b = decodeCover(ctx, u, s.w, s.h)
                drawCover(cv, b, RectF(s.x.toFloat(), s.y.toFloat(), (s.x + s.w).toFloat(), (s.y + s.h).toFloat()), paint)
                b.recycle()
            } catch (_: Exception) {}
        }
        if (t.hasOverlay) {
            val f = TemplateStore.overlayFile(ctx, t.id)
            if (f.exists()) {
                val ov = BitmapFactory.decodeFile(f.path)
                if (ov != null) { cv.drawBitmap(ov, null, Rect(0, 0, t.wPx, t.hPx), paint); ov.recycle() }
            }
        }
        return out
    }

    fun preview(ctx: Context, t: Template, maxDim: Int): Bitmap {
        val sc = maxDim.toFloat() / max(t.wPx, t.hPx)
        val w = max(1, (t.wPx * sc).toInt())
        val h = max(1, (t.hPx * sc).toInt())
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(t.bg)
        val fill = Paint().apply { color = 0xFFB8C2D0.toInt() }
        for (s in t.slots) cv.drawRect(s.x * sc, s.y * sc, (s.x + s.w) * sc, (s.y + s.h) * sc, fill)
        if (t.hasOverlay) {
            val f = TemplateStore.overlayFile(ctx, t.id)
            if (f.exists()) {
                val ov = BitmapFactory.decodeFile(f.path)
                if (ov != null) { cv.drawBitmap(ov, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG)); ov.recycle() }
            }
        }
        return out
    }
}
