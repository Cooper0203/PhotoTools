package com.phototools.app

import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build

object CanonControl {
    const val ACTION_PERMISSION = "com.phototools.app.USB_PERMISSION"

    fun isCamera(d: UsbDevice): Boolean {
        if (d.vendorId == 0x04A9) return true
        for (i in 0 until d.interfaceCount) {
            if (d.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_STILL_IMAGE) return true
        }
        return false
    }

    fun findCamera(c: Context): UsbDevice? {
        val u = c.getSystemService(Context.USB_SERVICE) as UsbManager
        return u.deviceList.values.firstOrNull { isCamera(it) }
    }

    @Suppress("DEPRECATION")
    fun deviceFrom(i: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        else i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)

    fun start(c: Context, d: UsbDevice) {
        c.startForegroundService(Intent(c, CanonSyncService::class.java).putExtra(UsbManager.EXTRA_DEVICE, d))
    }
}
