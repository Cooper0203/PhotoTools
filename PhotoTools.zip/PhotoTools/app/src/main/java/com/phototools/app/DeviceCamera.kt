package com.phototools.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import java.io.ByteArrayOutputStream

/** The phone / tablet camera as a stand-in for the Canon (testing, or when the Canon is not available). */
@Suppress("DEPRECATION")
class DeviceCamera(private val act: Activity) {
    private val mgr = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var preview: ImageReader? = null
    private var still: ImageReader? = null
    private var sensor = 90
    private var front = false
    private var lastFrame = 0L

    @Volatile var running = false
    var onFrame: ((Bitmap) -> Unit)? = null
    var onProblem: ((String) -> Unit)? = null
    var onStill: ((ByteArray) -> Unit)? = null

    @SuppressLint("MissingPermission")
    fun start(frontFacing: Boolean) {
        stop()
        front = frontFacing
        try {
            val want = if (frontFacing) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
            val id = mgr.cameraIdList.firstOrNull { mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want }
            if (id == null) { onProblem?.invoke("This device has no ${if (frontFacing) "front" else "back"} camera"); return }
            val ch = mgr.getCameraCharacteristics(id)
            sensor = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            if (map == null) { onProblem?.invoke("Camera not supported"); return }
            val ps = pickPreview(map.getOutputSizes(ImageFormat.YUV_420_888))
            val ss = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width.toLong() * it.height } ?: ps
            val th = HandlerThread("devcam").also { it.start() }
            thread = th
            val h = Handler(th.looper)
            handler = h
            preview = ImageReader.newInstance(ps.width, ps.height, ImageFormat.YUV_420_888, 2).also {
                it.setOnImageAvailableListener({ r -> onPreview(r) }, h)
            }
            still = ImageReader.newInstance(ss.width, ss.height, ImageFormat.JPEG, 2)
            mgr.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(cd: CameraDevice) { device = cd; makeSession(cd) }
                override fun onDisconnected(cd: CameraDevice) { cd.close(); fail("Phone camera disconnected") }
                override fun onError(cd: CameraDevice, error: Int) { cd.close(); fail("Phone camera error $error") }
            }, h)
        } catch (e: SecurityException) {
            onProblem?.invoke("Camera permission needed")
        } catch (e: Exception) {
            onProblem?.invoke("Cannot open the phone camera: ${e.message}")
        }
    }

    private fun pickPreview(sizes: Array<Size>): Size {
        val ok = sizes.filter { it.width <= 1280 && it.height <= 960 }
        return ok.maxByOrNull { it.width * it.height } ?: sizes.minByOrNull { it.width * it.height } ?: Size(640, 480)
    }

    private fun fail(msg: String) {
        stop()
        onProblem?.invoke(msg)
    }

    private fun makeSession(cd: CameraDevice) {
        val h = handler ?: return
        val pv = preview ?: return
        val st = still ?: return
        cd.createCaptureSession(listOf(pv.surface, st.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                session = s
                try {
                    val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                        addTarget(pv.surface)
                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                    }.build()
                    s.setRepeatingRequest(req, null, h)
                    running = true
                } catch (e: Exception) {
                    fail("Preview failed: ${e.message}")
                }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { fail("Phone camera could not start") }
        }, h)
    }

    private fun rotationDeg(): Int = when (act.windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_90 -> 90
        Surface.ROTATION_180 -> 180
        Surface.ROTATION_270 -> 270
        else -> 0
    }

    private fun turn(): Int = if (front) (sensor + rotationDeg()) % 360 else (sensor - rotationDeg() + 360) % 360

    private fun onPreview(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrame < 60) return
            lastFrame = now
            val cb = onFrame ?: return
            val bmp = toBitmap(img) ?: return
            cb(bmp)
        } finally {
            img.close()
        }
    }

    private fun toBitmap(img: Image): Bitmap? {
        val w = img.width
        val h = img.height
        val py = img.planes[0]
        val pu = img.planes[1]
        val pv = img.planes[2]
        val out = ByteArray(w * h * 3 / 2)
        var pos = 0
        val yb = py.buffer
        for (row in 0 until h) {
            yb.position(row * py.rowStride)
            yb.get(out, pos, w)
            pos += w
        }
        val ub = pu.buffer
        val vb = pv.buffer
        for (row in 0 until h / 2) {
            for (col in 0 until w / 2) {
                out[pos++] = vb.get(row * pv.rowStride + col * pv.pixelStride)
                out[pos++] = ub.get(row * pu.rowStride + col * pu.pixelStride)
            }
        }
        val bos = ByteArrayOutputStream()
        YuvImage(out, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), 70, bos)
        val raw = bos.toByteArray()
        val bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: return null
        val deg = turn()
        if (deg == 0) return bmp
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg.toFloat()) }, true)
    }

    fun capture() {
        val cd = device ?: return
        val s = session ?: return
        val r = still ?: return
        val h = handler ?: return
        try {
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireNextImage()
                if (img != null) {
                    try {
                        val b = img.planes[0].buffer
                        val bytes = ByteArray(b.remaining())
                        b.get(bytes)
                        onStill?.invoke(bytes)
                    } finally {
                        img.close()
                    }
                }
            }, h)
            val req = cd.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(r.surface)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                set(CaptureRequest.JPEG_ORIENTATION, turn())
            }.build()
            s.capture(req, null, h)
        } catch (e: Exception) {
            onProblem?.invoke("Capture failed: ${e.message}")
        }
    }

    fun stop() {
        running = false
        try { session?.close() } catch (_: Exception) {}
        try { device?.close() } catch (_: Exception) {}
        try { preview?.close() } catch (_: Exception) {}
        try { still?.close() } catch (_: Exception) {}
        session = null
        device = null
        preview = null
        still = null
        thread?.quitSafely()
        thread = null
        handler = null
    }
}
