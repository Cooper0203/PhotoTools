package com.phototools.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.provider.DocumentsContract
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.roundToInt

object Qr {
    fun make(text: String, px: Int): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, px, px, mapOf(EncodeHintType.MARGIN to 1))
        val pixels = IntArray(px * px)
        for (y in 0 until px) for (x in 0 until px) pixels[y * px + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
        return Bitmap.createBitmap(pixels, px, px, Bitmap.Config.ARGB_8888)
    }
}

/** Turns Canon EOS property codes into readable camera settings (display only). */
object CamInfo {
    const val APERTURE = 0xD101
    const val SHUTTER = 0xD102
    const val ISO = 0xD103
    const val EV = 0xD104
    const val MODE = 0xD105
    const val WB = 0xD109
    const val SHOTS = 0xD11B

    private val isoTable = mapOf(
        0x00 to "Auto", 0x40 to "50", 0x48 to "100", 0x4b to "125", 0x4d to "160", 0x50 to "200", 0x53 to "250", 0x55 to "320",
        0x58 to "400", 0x5b to "500", 0x5d to "640", 0x60 to "800", 0x63 to "1000", 0x65 to "1250", 0x68 to "1600",
        0x6b to "2000", 0x6d to "2500", 0x70 to "3200", 0x73 to "4000", 0x75 to "5000", 0x78 to "6400",
        0x7b to "8000", 0x7d to "10000", 0x80 to "12800", 0x88 to "25600"
    )
    private val wbTable = mapOf(0 to "Auto", 1 to "Daylight", 2 to "Cloudy", 3 to "Tungsten", 4 to "Fluorescent", 5 to "Flash",
        6 to "Manual", 8 to "Shade", 9 to "Kelvin", 10 to "PC-1", 11 to "PC-2", 12 to "PC-3", 14 to "Manual 2", 15 to "Manual 3")
    private val modeTable = mapOf(0 to "P", 1 to "Tv", 2 to "Av", 3 to "M", 4 to "Bulb", 5 to "A-DEP", 6 to "DEP", 7 to "C",
        9 to "A+", 10 to "Night", 11 to "Sports", 12 to "Portrait", 13 to "Landscape", 14 to "Close-up", 15 to "Flash off", 19 to "CA")
    private val speeds = intArrayOf(4, 5, 6, 8, 10, 13, 15, 20, 25, 30, 40, 50, 60, 80, 100, 125, 160, 200, 250, 320, 400, 500,
        640, 800, 1000, 1250, 1600, 2000, 2500, 3200, 4000, 5000, 6400, 8000)

    fun iso(v: Int?): String = if (v == null) "-" else isoTable[v] ?: (100 * 2.0.pow((v - 0x48) / 8.0)).roundToInt().toString()

    fun aperture(v: Int?): String {
        if (v == null || v <= 0) return "-"
        val f = 2.0.pow((v - 8) / 16.0)
        val t = if (f >= 10) String.format(Locale.US, "%.0f", f) else String.format(Locale.US, "%.1f", f).removeSuffix(".0")
        return "f/$t"
    }

    fun shutter(v: Int?): String {
        if (v == null || v <= 0) return "-"
        if (v == 0x0C) return "Bulb"
        val t = 2.0.pow((0x38 - v) / 8.0)
        if (t >= 0.3) {
            val s = if (t >= 10) t.roundToInt().toString() else String.format(Locale.US, "%.1f", t).removeSuffix(".0")
            return "$s\""
        }
        val d = 1.0 / t
        val best = speeds.minByOrNull { abs(ln(it / d)) } ?: d.roundToInt()
        return "1/$best"
    }

    fun ev(v: Int?): String {
        if (v == null) return "-"
        val b = (v and 0xFF).toByte().toInt()
        return String.format(Locale.US, "%+.1f", b / 8.0)
    }

    fun wb(v: Int?): String = if (v == null) "-" else wbTable[v] ?: "WB $v"
    fun mode(v: Int?): String = if (v == null) "-" else modeTable[v] ?: "Mode $v"
    fun shots(v: Int?): String = if (v == null || v < 0 || v > 99999) "-" else v.toString()
}

/** Copies pictures to a USB flash drive, hard drive or memory card chosen with Android's folder picker. */
object ExternalCopy {
    fun tree(p: SharedPreferences): Uri? {
        val s = p.getString("ext_tree", "") ?: ""
        return if (s.isEmpty()) null else Uri.parse(s)
    }

    fun label(p: SharedPreferences): String {
        val t = tree(p) ?: return "No drive selected"
        return try { Uri.decode(DocumentsContract.getTreeDocumentId(t)) } catch (_: Exception) { t.toString() }
    }

    private fun parentDoc(t: Uri): Uri = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))

    /** Creates a sub-folder named like Client_20261114_183000 and returns its document uri. */
    fun newFolder(ctx: Context, p: SharedPreferences): Uri? {
        val t = tree(p) ?: return null
        val name = "Client_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return try { DocumentsContract.createDocument(ctx.contentResolver, parentDoc(t), DocumentsContract.Document.MIME_TYPE_DIR, name) } catch (_: Exception) { null }
    }

    /** Copies one file. into = a folder made by newFolder, or null for the top of the chosen drive folder. */
    fun copy(ctx: Context, p: SharedPreferences, src: Uri, name: String, mime: String, into: Uri? = null): Boolean {
        val t = tree(p) ?: return false
        return try {
            val parent = into ?: parentDoc(t)
            val doc = DocumentsContract.createDocument(ctx.contentResolver, parent, mime, name) ?: return false
            val ins = ctx.contentResolver.openInputStream(src) ?: return false
            val out = ctx.contentResolver.openOutputStream(doc) ?: return false
            ins.use { i -> out.use { o -> i.copyTo(o, 64 * 1024) } }
            true
        } catch (_: Exception) { false }
    }
}
