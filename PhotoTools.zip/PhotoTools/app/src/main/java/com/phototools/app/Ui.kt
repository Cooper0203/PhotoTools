package com.phototools.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Ui {
    fun column(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(32, 48, 32, 32)
    }

    fun text(c: Context, s: String, size: Float = 15f, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setPadding(0, 12, 0, 12)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(c: Context, label: String, onClick: () -> Unit): Button = Button(c).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    fun scroll(c: Context, v: View): ScrollView = ScrollView(c).apply { addView(v) }
}
