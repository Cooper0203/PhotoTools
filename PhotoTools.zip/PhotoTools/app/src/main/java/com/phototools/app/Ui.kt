package com.phototools.app

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.graphics.Color
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object Ui {
    val BG = 0xFF0B0F17.toInt()
    val CARD = 0xFF161C2A.toInt()
    val CARD2 = 0xFF222B3F.toInt()
    val ACCENT = 0xFF3B82F6.toInt()
    val TEXT = 0xFFF1F5F9.toInt()
    val MUTED = 0xFF94A3B8.toInt()
    val RED = 0xFFEF4444.toInt()
    val GREEN = 0xFF22C55E.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, color: Int, radiusDp: Int, oval: Boolean = false): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(c, radiusDp).toFloat()
        }

    fun lp(c: Context, w: Int, h: Int, weight: Float = 0f, top: Int = 0, bottom: Int = 0, side: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(dp(c, side), dp(c, top), dp(c, side), dp(c, bottom)) }

    fun label(c: Context, s: String, size: Float = 14f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    /** Tappable rounded "button" made from a TextView. */
    fun pill(c: Context, s: String, bg: Int, fg: Int = TEXT, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = s
            textSize = 15f
            setTextColor(fg)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 12))
            background = shape(c, bg, 14)
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun card(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(c, CARD, 18)
        setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14))
    }

    /** Round icon button made from an emoji / symbol. */
    fun icon(c: Context, glyph: String, bg: Int = 0x99000000.toInt(), fg: Int = Color.WHITE, textSp: Float = 18f, onClick: () -> Unit): TextView =
        TextView(c).apply {
            text = glyph
            textSize = textSp
            setTextColor(fg)
            gravity = Gravity.CENTER
            background = shape(c, bg, 0, true)
            isClickable = true
            setOnClickListener { onClick() }
        }

    fun input(c: Context, value: String, hint: String = ""): EditText = EditText(c).apply {
        setText(value)
        this.hint = hint
        setTextColor(TEXT)
        setHintTextColor(MUTED)
        inputType = InputType.TYPE_CLASS_TEXT
        setSingleLine(true)
        background = shape(c, CARD2, 12)
        setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
    }

    fun detach(v: View) { (v.parent as? ViewGroup)?.removeView(v) }

    // ---- plain helpers used by the Facebook screen ----
    fun column(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(32, 48, 32, 32)
    }

    fun text(c: Context, s: String, size: Float = 15f, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = size
            setPadding(0, 12, 0, 12)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun button(c: Context, label: String, onClick: () -> Unit): Button = Button(c).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    fun scroll(c: Context, v: View): ScrollView = ScrollView(c).apply { addView(v) }
}
