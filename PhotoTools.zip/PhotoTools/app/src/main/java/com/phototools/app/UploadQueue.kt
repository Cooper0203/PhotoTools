package com.phototools.app

import android.content.Context
import android.net.Uri

/** Ordered list of media waiting to be shared to Facebook. Saved on the phone. */
object UploadQueue {
    private fun prefs(c: Context) = c.getSharedPreferences("queue", Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): List<Uri> =
        (prefs(c).getString("items", "") ?: "").split("\n").filter { it.isNotBlank() }.map { Uri.parse(it) }

    @Synchronized
    fun addAll(c: Context, uris: Collection<Uri>) {
        val cur = LinkedHashSet(all(c))
        cur.addAll(uris)
        write(c, cur)
    }

    @Synchronized
    fun removeAll(c: Context, uris: Collection<Uri>) {
        val cur = LinkedHashSet(all(c))
        cur.removeAll(uris.toSet())
        write(c, cur)
    }

    @Synchronized
    fun clear(c: Context) = write(c, emptySet())

    private fun write(c: Context, set: Set<Uri>) {
        prefs(c).edit().putString("items", set.joinToString("\n") { it.toString() }).apply()
    }
}
