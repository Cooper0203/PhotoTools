package com.phototools.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** Composition guides drawn over the live camera picture. Touches pass straight through. */
class GuideView(c: Context) : View(c) {
    companion object {
        val NAMES = listOf("Off", "Rule of thirds", "Grid 4 x 4", "Golden ratio", "Centre cross", "Diagonals", "Thirds + diagonals")
    }

    var mode = 0
    var aspect = 1.5f
    var fit = false

    private val light = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCCFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.5f * resources.displayMetrics.density
    }
    private val dark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x66000000; style = Paint.Style.STROKE; strokeWidth = 3.2f * resources.displayMetrics.density
    }

    private fun line(cv: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) {
        cv.drawLine(x1, y1, x2, y2, dark)
        cv.drawLine(x1, y1, x2, y2, light)
    }

    override fun onDraw(cv: Canvas) {
        if (mode == 0) return
        val vw = width.toFloat()
        val vh = height.toFloat()
        var l = 0f
        var t = 0f
        var w = vw
        var h = vh
        if (fit && aspect > 0f) {
            w = min(vw, vh * aspect)
            h = w / aspect
            l = (vw - w) / 2f
            t = (vh - h) / 2f
        }
        val r = l + w
        val b = t + h
        fun vert(f: Float) = line(cv, l + w * f, t, l + w * f, b)
        fun horiz(f: Float) = line(cv, l, t + h * f, r, t + h * f)
        when (mode) {
            1 -> { vert(1f / 3); vert(2f / 3); horiz(1f / 3); horiz(2f / 3) }
            2 -> { for (f in listOf(0.25f, 0.5f, 0.75f)) { vert(f); horiz(f) } }
            3 -> { vert(0.382f); vert(0.618f); horiz(0.382f); horiz(0.618f) }
            4 -> {
                vert(0.5f); horiz(0.5f)
                val cx = l + w / 2f
                val cy = t + h / 2f
                cv.drawCircle(cx, cy, min(w, h) * 0.04f, dark)
                cv.drawCircle(cx, cy, min(w, h) * 0.04f, light)
            }
            5 -> { line(cv, l, t, r, b); line(cv, r, t, l, b) }
            6 -> { vert(1f / 3); vert(2f / 3); horiz(1f / 3); horiz(2f / 3); line(cv, l, t, r, b); line(cv, r, t, l, b) }
        }
    }
}
