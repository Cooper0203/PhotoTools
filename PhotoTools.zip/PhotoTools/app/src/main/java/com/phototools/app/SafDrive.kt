package com.phototools.app

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.IOException

/**
 * Uploads to a folder the user picks with Android's own file picker (Storage Access Framework).
 * When that folder is on Google Drive the Drive app does the upload. No API keys, client IDs or developer account.
 */
object SafDrive {
    const val REQ = 203
    private fun p(c: Context) = Cloud.prefs(c)

    fun tree(c: Context): Uri? = (p(c).getString("saf_tree", "") ?: "").takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
    fun wantsOriginals(c: Context) = tree(c) != null && p(c).getBoolean("saf_orig", false)
    fun wantsFinals(c: Context) = tree(c) != null && p(c).getBoolean("saf_final", false)

    fun isDrive(t: Uri): Boolean = (t.authority ?: "").contains("docs", true) && (t.authority ?: "").contains("google", true)

    fun label(c: Context): String {
        val t = tree(c) ?: return "No folder chosen yet"
        val id = try { Uri.decode(DocumentsContract.getTreeDocumentId(t)) } catch (_: Exception) { "" }
        return (if (isDrive(t)) "Google Drive" else (t.authority ?: "storage")) + "  -  " + id
    }

    private fun root(t: Uri): Uri = DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t))

    private fun childDir(ctx: Context, t: Uri, parent: Uri, name: String): Uri? {
        val kids = DocumentsContract.buildChildDocumentsUriUsingTree(t, DocumentsContract.getDocumentId(parent))
        try {
            ctx.contentResolver.query(
                kids, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    if (c.getString(1) == name && c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        return DocumentsContract.buildDocumentUriUsingTree(t, c.getString(0))
                    }
                }
            }
        } catch (_: Exception) {}
        return DocumentsContract.createDocument(ctx.contentResolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, name)
    }

    /** Copies one file into the chosen folder. Skips files that were already sent (same name and size). */
    fun copy(ctx: Context, src: Uri, name: String, mime: String): CloudRes {
        val t = tree(ctx) ?: return CloudRes(false, "No Drive folder chosen", true)
        var size = -1L
        try {
            ctx.contentResolver.query(src, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) size = it.getLong(0) }
        } catch (_: Exception) {}
        val key = "$name|$size"
        val done = p(ctx).getStringSet("saf_done", emptySet()) ?: emptySet()
        if (key in done) return CloudRes(true, "already uploaded")
        try {
            var dir = root(t)
            val ev = (ctx.getSharedPreferences("canon", Context.MODE_PRIVATE).getString("session_label", "") ?: "")
                .replace(Regex("[^A-Za-z0-9 _.-]"), "").trim()
            if (ev.isNotEmpty()) {
                dir = childDir(ctx, t, dir, ev) ?: return CloudRes(false, "Cannot create the event folder there", false)
            }
            if (p(ctx).getBoolean("saf_sub", true)) {
                dir = childDir(ctx, t, dir, if (name.startsWith("Booth_")) "Template pictures" else "Camera photos")
                    ?: return CloudRes(false, "Cannot create a sub-folder there", false)
            }
            val doc = DocumentsContract.createDocument(ctx.contentResolver, dir, mime, name)
                ?: return CloudRes(false, "Cannot create the file in that folder", false)
            try {
                val ins = ctx.contentResolver.openInputStream(src) ?: throw IOException("Cannot read $name")
                val out = ctx.contentResolver.openOutputStream(doc) ?: throw IOException("Cannot write $name")
                ins.use { i ->
                    out.use { o ->
                        val buf = ByteArray(64 * 1024)
                        var sent = 0L
                        var last = 0L
                        while (true) {
                            val n = i.read(buf)
                            if (n < 0) break
                            o.write(buf, 0, n)
                            sent += n
                            val now = System.currentTimeMillis()
                            if (size > 0 && now - last > 400) {
                                last = now
                                Uploader.progress("Drive: $name  ${(sent * 100 / size).toInt()}%")
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                try { DocumentsContract.deleteDocument(ctx.contentResolver, doc) } catch (_: Exception) {}
                throw e
            }
            p(ctx).edit().putStringSet("saf_done", HashSet(done).apply { add(key) }).apply()
            return CloudRes(true, "ok")
        } catch (e: SecurityException) {
            return CloudRes(false, "Folder permission lost - choose the Drive folder again", true)
        }
    }

    /** Writes and removes a tiny file to prove the folder works. */
    fun test(ctx: Context): String {
        val t = tree(ctx) ?: return "Choose a folder first."
        return try {
            val doc = DocumentsContract.createDocument(ctx.contentResolver, root(t), "text/plain", "photobooth_test.txt")
                ?: return "Cannot create files in that folder."
            ctx.contentResolver.openOutputStream(doc)?.use { it.write("ok".toByteArray()) }
            try { DocumentsContract.deleteDocument(ctx.contentResolver, doc) } catch (_: Exception) {}
            (if (isDrive(t)) "Works. This folder is on Google Drive." else "Works. This folder is on: ${t.authority}.") +
                (if (isDrive(t)) "" else "\nIt is not Google Drive - for Drive pick a folder under the Drive entry of the picker.")
        } catch (e: SecurityException) {
            "Permission lost - choose the folder again."
        } catch (e: Exception) {
            "Could not write there: ${e.message}"
        }
    }

    fun pick(act: Activity) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        act.startActivityForResult(i, REQ)
    }

    /** Returns true when the result belonged to the folder picker. */
    fun onResult(ctx: Context, req: Int, res: Int, data: Intent?): Boolean {
        if (req != REQ) return false
        val u = data?.data
        if (res == Activity.RESULT_OK && u != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (_: Exception) {}
            p(ctx).edit().putString("saf_tree", u.toString()).apply()
        }
        return true
    }

    /** Fallback when the picker does not offer Drive: hand a batch to the Drive app (it asks which folder). */
    fun shareToDriveApp(act: Activity, uris: List<Uri>): Boolean {
        if (uris.isEmpty()) return false
        val i = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
            val clip = ClipData.newUri(act.contentResolver, "files", uris[0])
            for (u in uris.drop(1)) clip.addItem(ClipData.Item(u))
            clipData = clip
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        return try {
            act.startActivity(Intent(i).setPackage("com.google.android.apps.docs"))
            true
        } catch (_: Exception) {
            try { act.startActivity(Intent.createChooser(i, "Send to Google Drive")); true } catch (_: Exception) { false }
        }
    }
}
