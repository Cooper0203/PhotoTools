package com.phototools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.print.PrintHelper
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

/** Sends a JPEG straight to a Wi-Fi printer using IPP (the protocol behind AirPrint / Mopria). */
object Ipp {
    private fun str(o: DataOutputStream, tag: Int, name: String, v: String) {
        val b = v.toByteArray()
        o.writeByte(tag); o.writeShort(name.length); o.writeBytes(name); o.writeShort(b.size); o.write(b)
    }

    private fun int(o: DataOutputStream, tag: Int, name: String, v: Int) {
        o.writeByte(tag); o.writeShort(name.length); o.writeBytes(name); o.writeShort(4); o.writeInt(v)
    }

    private fun find(b: ByteArray, pat: String, from: Int = 0): Int {
        val p = pat.toByteArray()
        var i = from
        while (i <= b.size - p.size) {
            var ok = true
            for (k in p.indices) if (b[i + k] != p[k]) { ok = false; break }
            if (ok) return i
            i++
        }
        return -1
    }

    /** Returns the IPP status code (0x0000..0x00FF means accepted). */
    fun printJob(
        host: String, port: Int, path: String, data: ByteArray, jobName: String,
        copies: Int, media: String?, color: String, quality: Int, scaling: String, portrait: Boolean
    ): Int {
        val bo = ByteArrayOutputStream()
        val o = DataOutputStream(bo)
        o.writeShort(0x0101); o.writeShort(0x0002); o.writeInt(1)
        o.writeByte(0x01)
        str(o, 0x47, "attributes-charset", "utf-8")
        str(o, 0x48, "attributes-natural-language", "en")
        str(o, 0x45, "printer-uri", "ipp://$host:$port/$path")
        str(o, 0x42, "requesting-user-name", "photobooth")
        str(o, 0x42, "job-name", jobName)
        str(o, 0x49, "document-format", "image/jpeg")
        o.writeByte(0x02)
        int(o, 0x21, "copies", copies)
        if (media != null) str(o, 0x44, "media", media)
        str(o, 0x44, "print-color-mode", color)
        int(o, 0x23, "print-quality", quality)
        str(o, 0x44, "print-scaling", scaling)
        int(o, 0x23, "orientation-requested", if (portrait) 3 else 4)
        o.writeByte(0x03)
        o.write(data)
        val body = bo.toByteArray()

        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), 6000)
            s.soTimeout = 30000
            val head = "POST /$path HTTP/1.1\r\nHost: $host:$port\r\nContent-Type: application/ipp\r\n" +
                "Content-Length: ${body.size}\r\nConnection: close\r\nUser-Agent: Photobooth\r\n\r\n"
            val out = s.getOutputStream()
            out.write(head.toByteArray()); out.write(body); out.flush()
            val resp = ByteArrayOutputStream()
            val tmp = ByteArray(4096)
            val ins = s.getInputStream()
            try {
                while (true) {
                    val n = ins.read(tmp)
                    if (n < 0) break
                    resp.write(tmp, 0, n)
                    val cur = resp.toByteArray()
                    val he = find(cur, "\r\n\r\n")
                    if (he >= 0) {
                        val h = String(cur, 0, he).lowercase()
                        val m = Regex("content-length:\\s*(\\d+)").find(h)
                        if (m != null && cur.size >= he + 4 + m.groupValues[1].toInt()) break
                        if (h.contains("chunked") && find(cur, "0\r\n\r\n", he) >= 0) break
                    }
                }
            } catch (_: SocketTimeoutException) {}
            val r = resp.toByteArray()
            val he = find(r, "\r\n\r\n")
            if (he < 0) throw IOException("No answer from printer")
            val first = String(r, 0, minOf(r.size, 40))
            val http = Regex("HTTP/1\\.[01] (\\d+)").find(first)?.groupValues?.get(1)?.toInt() ?: 0
            if (http != 200) throw IOException("Printer answered HTTP $http")
            var bs = he + 4
            if (String(r, 0, he).lowercase().contains("chunked")) {
                val nl = find(r, "\r\n", bs)
                if (nl >= 0) bs = nl + 2
            }
            if (r.size < bs + 4) throw IOException("Empty printer reply")
            return ((r[bs + 2].toInt() and 0xFF) shl 8) or (r[bs + 3].toInt() and 0xFF)
        }
    }
}

/** Finds Wi-Fi printers on the local network (mDNS / Bonjour "_ipp._tcp"). */
class PrinterFinder(ctx: Context, private val onFound: (String, String, Int, String) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var disc: NsdManager.DiscoveryListener? = null
    private val queue = java.util.ArrayDeque<NsdServiceInfo>()
    private var busy = false

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String?) {}
            override fun onDiscoveryStopped(t: String?) {}
            override fun onStartDiscoveryFailed(t: String?, e: Int) {}
            override fun onStopDiscoveryFailed(t: String?, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo?) {}
            override fun onServiceFound(s: NsdServiceInfo?) {
                if (s != null) synchronized(queue) { queue.add(s) }
                next()
            }
        }
        disc = l
        try { nsd.discoverServices("_ipp._tcp", NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    @Synchronized
    private fun next() {
        if (busy) return
        val s = synchronized(queue) { queue.poll() } ?: return
        busy = true
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(si: NsdServiceInfo?, e: Int) { busy = false; next() }
                override fun onServiceResolved(si: NsdServiceInfo?) {
                    busy = false
                    if (si != null) {
                        val host = si.host?.hostAddress
                        if (host != null) {
                            val rp = si.attributes?.get("rp")?.let { String(it, Charsets.UTF_8) } ?: "ipp/print"
                            onFound(si.serviceName ?: host, host, si.port, rp.trimStart('/'))
                        }
                    }
                    next()
                }
            })
        } catch (_: Exception) { busy = false }
    }

    fun stop() {
        disc?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        disc = null
    }
}

object Printing {
    private fun dark(act: Activity) = AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)

    fun label(p: SharedPreferences): String =
        if (p.getString("pr_mode", "system") == "ipp" && !p.getString("pr_host", "").isNullOrEmpty())
            "${p.getString("pr_name", "Printer")}  (${p.getString("pr_host", "")})"
        else "Android print screen (choose each time)"

    private fun media(key: String?): String? = when (key) {
        "4x6" -> "na_index_4x6_4x6in"
        "5x7" -> "na_5x7_5x7in"
        "a6" -> "iso_a6_105x148mm"
        "a4" -> "iso_a4_210x297mm"
        "letter" -> "na_letter_8.5x11in"
        else -> null
    }

    fun print(act: Activity, p: SharedPreferences, uri: Uri, portrait: Boolean, status: (String) -> Unit) {
        val host = p.getString("pr_host", "") ?: ""
        if (p.getString("pr_mode", "system") != "ipp" || host.isEmpty()) { systemPrint(act, uri, portrait, status); return }
        val name = p.getString("pr_name", host) ?: host
        status("Sending to $name ...")
        val port = p.getInt("pr_port", 631)
        val path = p.getString("pr_path", "ipp/print") ?: "ipp/print"
        val copies = (p.getString("pr_copies", "1") ?: "1").toIntOrNull() ?: 1
        val color = if (p.getString("pr_color", "color") == "mono") "monochrome" else "color"
        val quality = when (p.getString("pr_quality", "normal")) { "draft" -> 3; "high" -> 5; else -> 4 }
        val scaling = if (p.getString("pr_scale", "fit") == "fill") "fill" else "fit"
        val fallback = p.getBoolean("pr_fallback", true)
        val med = media(p.getString("pr_media", "auto"))
        Thread {
            try {
                val data = act.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Cannot read the picture")
                val code = Ipp.printJob(host, port, path, data, "Photobooth", copies, med, color, quality, scaling, portrait)
                if (code > 0xFF) throw IOException("Printer replied 0x" + Integer.toHexString(code))
                act.runOnUiThread { status("Sent to $name") }
            } catch (e: Exception) {
                act.runOnUiThread {
                    status("Printer problem: ${e.message}")
                    if (fallback) systemPrint(act, uri, portrait, status)
                }
            }
        }.start()
    }

    private fun systemPrint(act: Activity, uri: Uri, portrait: Boolean, status: (String) -> Unit) {
        try {
            val ph = PrintHelper(act)
            ph.scaleMode = PrintHelper.SCALE_MODE_FIT
            ph.orientation = if (portrait) PrintHelper.ORIENTATION_PORTRAIT else PrintHelper.ORIENTATION_LANDSCAPE
            ph.printBitmap("Photobooth", uri)
            status("Android print screen opened")
        } catch (e: Exception) {
            status("Could not print: ${e.message}")
        }
    }

    private fun row(act: Activity, title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.shape(act, Ui.CARD2, 12)
            setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(Ui.label(act, title, 15f, Ui.TEXT, true))
        if (sub.isNotEmpty()) r.addView(Ui.label(act, sub, 12f, Ui.MUTED))
        return r
    }

    fun selectPrinter(act: Activity, p: SharedPreferences, onDone: () -> Unit) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(act, 16), Ui.dp(act, 12), Ui.dp(act, 16), Ui.dp(act, 12))
        }
        box.addView(Ui.label(act, "Select printer", 18f, Ui.TEXT, true))
        box.addView(Ui.label(act, "Searching Wi-Fi printers on this network ...", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2, bottom = 8))
        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list)
        val dlgRef = arrayOfNulls<AlertDialog>(1)
        list.addView(row(act, "Android print screen", "Choose the printer each time") {
            p.edit().putString("pr_mode", "system").apply()
            dlgRef[0]?.dismiss(); onDone()
        }, Ui.lp(act, -1, -2, bottom = 6))
        val shown = HashSet<String>()
        val finder = PrinterFinder(act) { name, host, port, path ->
            act.runOnUiThread {
                if (shown.add("$host:$port")) {
                    list.addView(row(act, name, "$host:$port") {
                        p.edit().putString("pr_mode", "ipp").putString("pr_name", name).putString("pr_host", host)
                            .putInt("pr_port", port).putString("pr_path", path).apply()
                        dlgRef[0]?.dismiss(); onDone()
                    }, Ui.lp(act, -1, -2, bottom = 6))
                }
            }
        }
        box.addView(Ui.label(act, "Or type the printer's IP address", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val ip = Ui.input(act, "", "192.168.1.50")
        box.addView(ip, Ui.lp(act, -1, -2, top = 4))
        box.addView(Ui.pill(act, "Use this IP", Ui.ACCENT) {
            val t = ip.text.toString().trim()
            if (t.isNotEmpty()) {
                val host = t.substringBefore(':')
                val port = t.substringAfter(':', "631").toIntOrNull() ?: 631
                p.edit().putString("pr_mode", "ipp").putString("pr_name", host).putString("pr_host", host)
                    .putInt("pr_port", port).putString("pr_path", "ipp/print").apply()
                dlgRef[0]?.dismiss(); onDone()
            }
        }, Ui.lp(act, -1, -2, top = 8))
        val d = dark(act).setView(ScrollView(act).apply { addView(box) })
            .setNegativeButton("Close", null)
            .setOnDismissListener { finder.stop() }
            .create()
        dlgRef[0] = d
        d.show()
        finder.start()
    }

    private fun chips(act: Activity, box: LinearLayout, title: String, opts: List<Pair<String, String>>, p: SharedPreferences, key: String, def: String) {
        box.addView(Ui.label(act, title, 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val list = ArrayList<TextView>()
        fun paint() {
            val cur = p.getString(key, def)
            for (c in list) c.background = Ui.shape(act, if (c.tag == cur) Ui.ACCENT else Ui.CARD2, 12)
        }
        for ((label, value) in opts) {
            val c = Ui.pill(act, label, Ui.CARD2) { p.edit().putString(key, value).apply(); paint() }
            c.textSize = 12f
            c.setPadding(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8))
            c.tag = value
            list.add(c)
            row.addView(c, Ui.lp(act, 0, -2, 1f, side = 2))
        }
        paint()
        box.addView(row, Ui.lp(act, -1, -2, top = 4))
    }

    fun settings(act: Activity, p: SharedPreferences) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(act, 16), Ui.dp(act, 12), Ui.dp(act, 16), Ui.dp(act, 12))
        }
        box.addView(Ui.label(act, "Print settings", 18f, Ui.TEXT, true))
        box.addView(Ui.label(act, label(p), 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        chips(act, box, "Paper size", listOf("Printer default" to "auto", "4x6 in" to "4x6", "5x7 in" to "5x7", "A6" to "a6", "A4" to "a4", "Letter" to "letter"), p, "pr_media", "auto")
        chips(act, box, "Copies", listOf("1" to "1", "2" to "2", "3" to "3", "4" to "4"), p, "pr_copies", "1")
        chips(act, box, "Colour", listOf("Colour" to "color", "Black & white" to "mono"), p, "pr_color", "color")
        chips(act, box, "Quality", listOf("Draft" to "draft", "Normal" to "normal", "High" to "high"), p, "pr_quality", "normal")
        chips(act, box, "Picture on paper", listOf("Fit whole picture" to "fit", "Fill paper (crop)" to "fill"), p, "pr_scale", "fit")
        box.addView(Switch(act).apply {
            text = "If the printer can't be reached, open the Android print screen"
            textSize = 13f
            setTextColor(Ui.TEXT)
            isChecked = p.getBoolean("pr_fallback", true)
            setOnCheckedChangeListener { _, on -> p.edit().putBoolean("pr_fallback", on).apply() }
        }, Ui.lp(act, -1, -2, top = 14))
        dark(act).setView(ScrollView(act).apply { addView(box) }).setPositiveButton("Done", null).show()
    }
}
