package com.phototools.app

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import androidx.print.PrintHelper
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One way of talking HTTP to a printer: over Wi-Fi/network, or over a USB cable (IPP-over-USB). */
interface PrintLink {
    /** Sends the HTTP request and returns the raw HTTP answer. */
    fun exchange(head: String, body: ByteArray): ByteArray
    fun close()
}

class NetLink(private val host: String, private val port: Int) : PrintLink {
    override fun exchange(head: String, body: ByteArray): ByteArray {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), 6000)
            s.soTimeout = 30000
            val out = s.getOutputStream()
            out.write(head.toByteArray()); out.write(body); out.flush()
            val ins = s.getInputStream()
            return Ipp.readHttp { buf -> try { ins.read(buf) } catch (_: SocketTimeoutException) { -1 } }
        }
    }
    override fun close() {}
}

class UsbLink(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint
) : PrintLink {
    private fun write(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = minOf(b.size - off, 16384)
            val r = conn.bulkTransfer(outEp, b, off, n, 15000)
            if (r <= 0) throw IOException("USB write to the printer failed")
            off += r
        }
    }

    override fun exchange(head: String, body: ByteArray): ByteArray {
        write(head.toByteArray())
        write(body)
        return Ipp.readHttp { buf -> conn.bulkTransfer(inEp, buf, buf.size, 30000) }
    }

    override fun close() {
        try { conn.releaseInterface(iface) } catch (_: Exception) {}
        try { conn.close() } catch (_: Exception) {}
    }
}

/** Printers connected with a USB cable. Works with printers that support IPP-over-USB (most recent models). */
object UsbPrinter {
    private const val ACTION = "com.phototools.app.USB_PRINTER_PERMISSION"

    private fun mgr(c: Context) = c.getSystemService(Context.USB_SERVICE) as UsbManager

    fun isPrinter(d: UsbDevice): Boolean {
        for (i in 0 until d.interfaceCount) if (d.getInterface(i).interfaceClass == UsbConstants.USB_CLASS_PRINTER) return true
        return false
    }

    fun hasIppUsb(d: UsbDevice): Boolean {
        for (i in 0 until d.interfaceCount) {
            val f = d.getInterface(i)
            if (f.interfaceClass == UsbConstants.USB_CLASS_PRINTER && f.interfaceSubclass == 1 && f.interfaceProtocol == 4) return true
        }
        return false
    }

    fun list(c: Context): List<UsbDevice> = mgr(c).deviceList.values.filter { isPrinter(it) }

    fun find(c: Context, p: SharedPreferences): UsbDevice? {
        val vid = p.getInt("pr_usb_vid", -1)
        val pid = p.getInt("pr_usb_pid", -1)
        return list(c).firstOrNull { it.vendorId == vid && it.productId == pid }
    }

    fun name(d: UsbDevice): String = (d.productName ?: "USB printer") + (if (hasIppUsb(d)) "" else "  (no IPP-over-USB)")

    fun ensurePermission(c: Context, d: UsbDevice, cb: (Boolean) -> Unit) {
        val m = mgr(c)
        if (m.hasPermission(d)) { cb(true); return }
        val r = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, i: Intent?) {
                try { c.unregisterReceiver(this) } catch (_: Exception) {}
                cb(i?.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) == true)
            }
        }
        val f = IntentFilter(ACTION)
        if (Build.VERSION.SDK_INT >= 33) c.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED) else c.registerReceiver(r, f)
        val pi = PendingIntent.getBroadcast(c, 1, Intent(ACTION).setPackage(c.packageName), PendingIntent.FLAG_MUTABLE)
        m.requestPermission(d, pi)
    }

    fun open(c: Context, d: UsbDevice): UsbLink? {
        val m = mgr(c)
        if (!m.hasPermission(d)) return null
        val conn = m.openDevice(d) ?: return null
        for (i in 0 until d.interfaceCount) {
            val f = d.getInterface(i)
            if (f.interfaceClass != UsbConstants.USB_CLASS_PRINTER || f.interfaceSubclass != 1 || f.interfaceProtocol != 4) continue
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null
            for (e in 0 until f.endpointCount) {
                val ep = f.getEndpoint(e)
                if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                    if (ep.direction == UsbConstants.USB_DIR_IN) inEp = ep else outEp = ep
                }
            }
            if (inEp != null && outEp != null && conn.claimInterface(f, true)) {
                try { conn.setInterface(f) } catch (_: Exception) {}
                return UsbLink(conn, f, inEp, outEp)
            }
        }
        conn.close()
        return null
    }
}

/** IPP (the protocol behind AirPrint / Mopria): print a JPEG, or ask the printer how it is doing. */
object Ipp {
    class Reply(val status: Int, val attrs: Map<String, String>)

    private fun str(o: DataOutputStream, tag: Int, name: String, v: String) {
        val b = v.toByteArray()
        o.writeByte(tag); o.writeShort(name.length); o.writeBytes(name); o.writeShort(b.size); o.write(b)
    }

    private fun more(o: DataOutputStream, tag: Int, v: String) {
        val b = v.toByteArray()
        o.writeByte(tag); o.writeShort(0); o.writeShort(b.size); o.write(b)
    }

    private fun int(o: DataOutputStream, tag: Int, name: String, v: Int) {
        o.writeByte(tag); o.writeShort(name.length); o.writeBytes(name); o.writeShort(4); o.writeInt(v)
    }

    private fun find(b: ByteArray, pat: String, from: Int = 0): Int {
        val p = pat.toByteArray()
        var i = from
        while (i <= b.size - p.size) {
            var ok = true
            for (k in p.indices) if (b[i + k] != p[k]) { ok = false; break }
            if (ok) return i
            i++
        }
        return -1
    }

    /** Reads an HTTP answer using [reader] (returns bytes read, or -1 at end / timeout). */
    fun readHttp(reader: (ByteArray) -> Int): ByteArray {
        val resp = ByteArrayOutputStream()
        val tmp = ByteArray(16384)
        var empty = 0
        while (true) {
            val n = reader(tmp)
            if (n < 0) break
            if (n == 0) { if (++empty > 5) break; continue }
            resp.write(tmp, 0, n)
            val cur = resp.toByteArray()
            val he = find(cur, "\r\n\r\n")
            if (he >= 0) {
                val h = String(cur, 0, he).lowercase()
                val m = Regex("content-length:\\s*(\\d+)").find(h)
                if (m != null && cur.size >= he + 4 + m.groupValues[1].toInt()) break
                if (h.contains("chunked") && find(cur, "0\r\n\r\n", he) >= 0) break
            }
        }
        return resp.toByteArray()
    }

    private fun httpBody(r: ByteArray): ByteArray {
        val he = find(r, "\r\n\r\n")
        if (he < 0) throw IOException("No answer from the printer")
        val first = String(r, 0, minOf(r.size, 40))
        val http = Regex("HTTP/1\\.[01] (\\d+)").find(first)?.groupValues?.get(1)?.toInt() ?: 0
        if (http != 200) throw IOException("The printer answered HTTP $http")
        var bs = he + 4
        if (!String(r, 0, he).lowercase().contains("chunked")) return r.copyOfRange(bs, r.size)
        val out = ByteArrayOutputStream()
        while (bs < r.size) {
            val nl = find(r, "\r\n", bs)
            if (nl < 0) break
            val size = String(r, bs, nl - bs).trim().substringBefore(';').toIntOrNull(16) ?: break
            if (size == 0) break
            val st = nl + 2
            if (st + size > r.size) break
            out.write(r, st, size)
            bs = st + size + 2
        }
        return out.toByteArray()
    }

    private fun header(o: DataOutputStream, op: Int, printerUri: String) {
        o.writeShort(0x0101); o.writeShort(op); o.writeInt(1)
        o.writeByte(0x01)
        str(o, 0x47, "attributes-charset", "utf-8")
        str(o, 0x48, "attributes-natural-language", "en")
        str(o, 0x45, "printer-uri", printerUri)
    }

    private fun send(link: PrintLink, hostHeader: String, path: String, body: ByteArray): ByteArray {
        val head = "POST /$path HTTP/1.1\r\nHost: $hostHeader\r\nContent-Type: application/ipp\r\n" +
            "Content-Length: ${body.size}\r\nConnection: close\r\nUser-Agent: Photobooth\r\n\r\n"
        return httpBody(link.exchange(head, body))
    }

    /** Returns the IPP status code (0x0000..0x00FF means accepted). */
    fun printJob(
        link: PrintLink, hostHeader: String, path: String, data: ByteArray, jobName: String,
        copies: Int, media: String?, color: String, quality: Int, scaling: String, portrait: Boolean
    ): Int {
        val bo = ByteArrayOutputStream()
        val o = DataOutputStream(bo)
        header(o, 0x0002, "ipp://$hostHeader/$path")
        str(o, 0x42, "requesting-user-name", "photobooth")
        str(o, 0x42, "job-name", jobName)
        str(o, 0x49, "document-format", "image/jpeg")
        o.writeByte(0x02)
        int(o, 0x21, "copies", copies)
        if (media != null) str(o, 0x44, "media", media)
        str(o, 0x44, "print-color-mode", color)
        int(o, 0x23, "print-quality", quality)
        str(o, 0x44, "print-scaling", scaling)
        int(o, 0x23, "orientation-requested", if (portrait) 3 else 4)
        o.writeByte(0x03)
        o.write(data)
        val b = send(link, hostHeader, path, bo.toByteArray())
        if (b.size < 4) throw IOException("Empty reply from the printer")
        return ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
    }

    /** Asks the printer for its name, model and state (used by "Test connection"). */
    fun status(link: PrintLink, hostHeader: String, path: String): Reply {
        val bo = ByteArrayOutputStream()
        val o = DataOutputStream(bo)
        header(o, 0x000B, "ipp://$hostHeader/$path")
        str(o, 0x44, "requested-attributes", "printer-state")
        more(o, 0x44, "printer-state-reasons")
        more(o, 0x44, "printer-name")
        more(o, 0x44, "printer-make-and-model")
        more(o, 0x44, "printer-is-accepting-jobs")
        o.writeByte(0x03)
        val b = send(link, hostHeader, path, bo.toByteArray())
        if (b.size < 8) throw IOException("Empty reply from the printer")
        val status = ((b[2].toInt() and 0xFF) shl 8) or (b[3].toInt() and 0xFF)
        val attrs = LinkedHashMap<String, String>()
        var i = 8
        var last = ""
        while (i < b.size) {
            val tag = b[i].toInt() and 0xFF
            i++
            if (tag == 0x03) break
            if (tag <= 0x0F) continue
            if (i + 2 > b.size) break
            val nl = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
            if (i + nl + 2 > b.size) break
            val name = if (nl > 0) String(b, i, nl) else last
            i += nl
            val vl = ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
            if (i + vl > b.size) break
            val v = when (tag) {
                0x21, 0x23 -> if (vl == 4) (((b[i].toInt() and 0xFF) shl 24) or ((b[i + 1].toInt() and 0xFF) shl 16) or ((b[i + 2].toInt() and 0xFF) shl 8) or (b[i + 3].toInt() and 0xFF)).toString() else ""
                0x22 -> if (vl >= 1 && b[i].toInt() != 0) "true" else "false"
                else -> String(b, i, vl)
            }
            i += vl
            last = name
            attrs[name] = if (attrs.containsKey(name) && nl == 0) attrs[name] + ", " + v else v
        }
        return Reply(status, attrs)
    }
}

/** Finds services on the local network with mDNS (printers: "_ipp._tcp", photobooth servers: "_photobooth._tcp"). */
class PrinterFinder(ctx: Context, private val type: String = "_ipp._tcp", private val onFound: (String, String, Int, String) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var disc: NsdManager.DiscoveryListener? = null
    private val queue = java.util.ArrayDeque<NsdServiceInfo>()
    private var busy = false

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String?) {}
            override fun onDiscoveryStopped(t: String?) {}
            override fun onStartDiscoveryFailed(t: String?, e: Int) {}
            override fun onStopDiscoveryFailed(t: String?, e: Int) {}
            override fun onServiceLost(s: NsdServiceInfo?) {}
            override fun onServiceFound(s: NsdServiceInfo?) {
                if (s != null) synchronized(queue) { queue.add(s) }
                next()
            }
        }
        disc = l
        try { nsd.discoverServices(type, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    @Synchronized
    private fun next() {
        if (busy) return
        val s = synchronized(queue) { queue.poll() } ?: return
        busy = true
        try {
            nsd.resolveService(s, object : NsdManager.ResolveListener {
                override fun onResolveFailed(si: NsdServiceInfo?, e: Int) { busy = false; next() }
                override fun onServiceResolved(si: NsdServiceInfo?) {
                    busy = false
                    if (si != null) {
                        val host = si.host?.hostAddress
                        if (host != null) {
                            val rp = si.attributes?.get("rp")?.let { String(it, Charsets.UTF_8) } ?: "ipp/print"
                            onFound(si.serviceName ?: host, host, si.port, rp.trimStart('/'))
                        }
                    }
                    next()
                }
            })
        } catch (_: Exception) { busy = false }
    }

    fun stop() {
        disc?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        disc = null
    }
}


object Printing {
    class TestResult(val ok: Boolean, val text: String)
    private class Target(val link: PrintLink, val hostHeader: String, val path: String, val name: String)

    private fun dark(act: Activity) = AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)

    fun label(p: SharedPreferences): String = when {
        p.getString("pr_mode", "system") == "ipp" && !p.getString("pr_host", "").isNullOrEmpty() ->
            "${p.getString("pr_name", "Printer")}  (${p.getString("pr_host", "")})"
        p.getString("pr_mode", "system") == "usb" -> "${p.getString("pr_name", "USB printer")}  (USB cable)"
        else -> "Android print screen (choose each time)"
    }

    fun isOk(p: SharedPreferences) = p.getBoolean("pr_ok", false)
    fun statusLine(p: SharedPreferences): String =
        (if (isOk(p)) "\u25CF Connected - " else "\u25CB Not connected - ") + (p.getString("pr_msg", "tap Connect printer") ?: "")

    private fun media(key: String?): String? = when (key) {
        "4x6" -> "na_index_4x6_4x6in"
        "5x7" -> "na_5x7_5x7in"
        "a6" -> "iso_a6_105x148mm"
        "a4" -> "iso_a4_210x297mm"
        "letter" -> "na_letter_8.5x11in"
        else -> null
    }

    fun isPortrait(ctx: Context, uri: Uri): Boolean {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            o.outHeight >= o.outWidth
        } catch (_: Exception) { true }
    }

    private fun openTarget(ctx: Context, p: SharedPreferences): Target {
        val name = p.getString("pr_name", "Printer") ?: "Printer"
        return when (p.getString("pr_mode", "system")) {
            "ipp" -> {
                val host = p.getString("pr_host", "") ?: ""
                if (host.isEmpty()) throw IOException("No printer selected")
                val port = p.getInt("pr_port", 631)
                Target(NetLink(host, port), "$host:$port", p.getString("pr_path", "ipp/print") ?: "ipp/print", name)
            }
            "usb" -> {
                val d = UsbPrinter.find(ctx, p) ?: throw IOException("USB printer not found. Plug in the cable and switch the printer on.")
                val l = UsbPrinter.open(ctx, d) ?: throw IOException("No USB access yet. Open Settings > Connect printer and allow it.")
                Target(l, "localhost", "ipp/print", name)
            }
            else -> throw IOException("No printer selected")
        }
    }

    /** Blocking. Returns null when the picture was sent, otherwise a short error text. */
    fun sendBlocking(ctx: Context, p: SharedPreferences, data: ByteArray, portrait: Boolean, job: String): String? {
        val mode = p.getString("pr_mode", "system")
        if (mode != "ipp" && mode != "usb") return "No printer selected"
        val copies = (p.getString("pr_copies", "1") ?: "1").toIntOrNull() ?: 1
        val color = if (p.getString("pr_color", "color") == "mono") "monochrome" else "color"
        val quality = when (p.getString("pr_quality", "normal")) { "draft" -> 3; "high" -> 5; else -> 4 }
        val scaling = if (p.getString("pr_scale", "fit") == "fill") "fill" else "fit"
        var t: Target? = null
        return try {
            t = openTarget(ctx, p)
            val code = Ipp.printJob(t.link, t.hostHeader, t.path, data, job, copies, media(p.getString("pr_media", "auto")), color, quality, scaling, portrait)
            if (code > 0xFF) "The printer replied 0x" + Integer.toHexString(code) else null
        } catch (e: Exception) {
            e.message ?: "Printer error"
        } finally {
            t?.link?.close()
        }
    }

    /** Blocking: asks the printer if it is reachable, working and ready to print. */
    fun testBlocking(ctx: Context, p: SharedPreferences): TestResult {
        if (p.getString("pr_mode", "system") == "system") return TestResult(true, "Android print screen - you pick the printer when printing")
        var t: Target? = null
        return try {
            t = openTarget(ctx, p)
            val r = Ipp.status(t.link, t.hostHeader, t.path)
            if (r.status > 0xFF) return TestResult(false, "The printer replied 0x" + Integer.toHexString(r.status))
            val state = r.attrs["printer-state"]?.toIntOrNull()
            val model = r.attrs["printer-make-and-model"] ?: r.attrs["printer-name"] ?: t.name
            val reasons = r.attrs["printer-state-reasons"] ?: "none"
            val bad = listOf("media-jam", "media-empty", "media-needed", "door-open", "cover-open", "marker-supply-empty", "offline", "toner-empty", "paused", "shutdown")
            when {
                state == 5 -> TestResult(false, "$model is stopped ($reasons)")
                r.attrs["printer-is-accepting-jobs"] == "false" -> TestResult(false, "$model is not accepting jobs")
                bad.any { reasons.contains(it) } -> TestResult(false, "$model needs attention: $reasons")
                state == 4 -> TestResult(true, "$model is busy printing")
                else -> TestResult(true, "$model is ready to print")
            }
        } catch (e: Exception) {
            TestResult(false, "Cannot reach the printer: ${e.message}")
        } finally {
            t?.link?.close()
        }
    }

    fun test(act: Activity, p: SharedPreferences, done: (TestResult) -> Unit) {
        Thread {
            val r = testBlocking(act, p)
            p.edit().putBoolean("pr_ok", r.ok).putString("pr_msg", r.text).apply()
            act.runOnUiThread { done(r) }
        }.start()
    }

    private fun testBitmap(): Bitmap {
        val b = Bitmap.createBitmap(1200, 1800, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE; p.strokeWidth = 8f; p.color = Color.BLACK
        c.drawRect(30f, 30f, 1170f, 1770f, p)
        p.style = Paint.Style.FILL; p.textSize = 90f; p.textAlign = Paint.Align.CENTER
        c.drawText("Printer test", 600f, 220f, p)
        p.textSize = 48f
        c.drawText(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()), 600f, 310f, p)
        val cols = intArrayOf(Color.RED, Color.GREEN, Color.BLUE, Color.CYAN, Color.MAGENTA, Color.YELLOW, Color.BLACK, Color.GRAY)
        for ((i, col) in cols.withIndex()) { p.color = col; c.drawRect(120f, 420f + i * 150f, 1080f, 540f + i * 150f, p) }
        return b
    }

    fun testPrint(act: Activity, p: SharedPreferences, status: (String) -> Unit) {
        val bmp = testBitmap()
        val mode = p.getString("pr_mode", "system")
        if (mode != "ipp" && mode != "usb") {
            try {
                val ph = PrintHelper(act)
                ph.scaleMode = PrintHelper.SCALE_MODE_FIT
                ph.orientation = PrintHelper.ORIENTATION_PORTRAIT
                ph.printBitmap("Printer test", bmp)
                status("Android print screen opened")
            } catch (e: Exception) { status("Could not print: ${e.message}") }
            return
        }
        status("Sending the test page ...")
        Thread {
            val bo = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, bo)
            val err = sendBlocking(act, p, bo.toByteArray(), true, "Printer test")
            act.runOnUiThread { status(if (err == null) "Test page sent to the printer" else "Test failed: $err") }
        }.start()
    }

    fun print(act: Activity, p: SharedPreferences, uri: Uri, portrait: Boolean, status: (String) -> Unit) {
        val mode = p.getString("pr_mode", "system")
        if (mode != "ipp" && mode != "usb") { systemPrint(act, uri, portrait, status); return }
        val name = p.getString("pr_name", "printer") ?: "printer"
        val fallback = p.getBoolean("pr_fallback", true)
        status("Sending to $name ...")
        val go = {
            Thread {
                val err = try {
                    val data = act.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Cannot read the picture")
                    sendBlocking(act, p, data, portrait, "Photobooth")
                } catch (e: Exception) { e.message ?: "error" }
                act.runOnUiThread {
                    if (err == null) status("Sent to $name") else {
                        status("Printer problem: $err")
                        if (fallback) systemPrint(act, uri, portrait, status)
                    }
                }
            }.start()
        }
        if (mode == "usb") {
            val d = UsbPrinter.find(act, p)
            if (d == null) {
                status("USB printer not found - plug in the cable")
                if (fallback) systemPrint(act, uri, portrait, status)
                return
            }
            UsbPrinter.ensurePermission(act, d) { ok -> if (ok) go() else status("USB access was not allowed") }
        } else go()
    }

    /** Used by the server when nobody is looking at the screen: only direct printing (Wi-Fi or USB) is possible. */
    fun printHeadless(ctx: Context, p: SharedPreferences, uri: Uri, status: (String) -> Unit) {
        Thread {
            val err = try {
                val data = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw IOException("Cannot read the picture")
                sendBlocking(ctx, p, data, isPortrait(ctx, uri), "Photobooth")
            } catch (e: Exception) { e.message ?: "error" }
            status(if (err == null) "Printed ${Uri.decode(uri.lastPathSegment ?: "")}" else "Print failed: $err")
        }.start()
    }

    private fun systemPrint(act: Activity, uri: Uri, portrait: Boolean, status: (String) -> Unit) {
        try {
            val ph = PrintHelper(act)
            ph.scaleMode = PrintHelper.SCALE_MODE_FIT
            ph.orientation = if (portrait) PrintHelper.ORIENTATION_PORTRAIT else PrintHelper.ORIENTATION_LANDSCAPE
            ph.printBitmap("Photobooth", uri)
            status("Android print screen opened")
        } catch (e: Exception) {
            status("Could not print: ${e.message}")
        }
    }

    private fun row(act: Activity, title: String, sub: String, onClick: () -> Unit): LinearLayout {
        val r = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.shape(act, Ui.CARD2, 12)
            setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            isClickable = true
            setOnClickListener { onClick() }
        }
        r.addView(Ui.label(act, title, 15f, Ui.TEXT, true))
        if (sub.isNotEmpty()) r.addView(Ui.label(act, sub, 12f, Ui.MUTED))
        return r
    }

    /** "Connect printer": pick Wi-Fi, USB cable or the Android print screen, then the app tests it. */
    fun selectPrinter(act: Activity, p: SharedPreferences, onDone: () -> Unit) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(act, 16), Ui.dp(act, 12), Ui.dp(act, 16), Ui.dp(act, 12))
        }
        box.addView(Ui.label(act, "Connect printer", 18f, Ui.TEXT, true))
        box.addView(Ui.label(act, "Pick the printer. The app then tests that it is connected and ready.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2, bottom = 8))
        val list = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(list)
        val dlgRef = arrayOfNulls<AlertDialog>(1)
        val choose = { save: () -> Unit ->
            save()
            p.edit().putBoolean("pr_ok", false).putString("pr_msg", "testing ...").apply()
            dlgRef[0]?.dismiss()
            onDone()
            Printing.test(act, p) { onDone() }
        }
        list.addView(row(act, "Android print screen", "Choose the printer each time") {
            choose { p.edit().putString("pr_mode", "system").apply() }
        }, Ui.lp(act, -1, -2, bottom = 6))

        box.addView(Ui.label(act, "USB cable", 13f, Ui.MUTED, true), Ui.lp(act, -2, -2, top = 8))
        val usbList = UsbPrinter.list(act)
        if (usbList.isEmpty()) box.addView(Ui.label(act, "No USB printer found. Plug the cable into the phone (OTG adapter), switch the printer on, then open this window again.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        for (d in usbList) {
            box.addView(row(act, UsbPrinter.name(d), "USB cable - tap to connect") {
                UsbPrinter.ensurePermission(act, d) { ok ->
                    if (ok) choose {
                        p.edit().putString("pr_mode", "usb").putString("pr_name", d.productName ?: "USB printer")
                            .putInt("pr_usb_vid", d.vendorId).putInt("pr_usb_pid", d.productId).apply()
                    } else act.runOnUiThread { p.edit().putString("pr_msg", "USB access was not allowed").apply(); onDone() }
                }
            }, Ui.lp(act, -1, -2, top = 4))
        }

        box.addView(Ui.label(act, "Wi-Fi printers on this network", 13f, Ui.MUTED, true), Ui.lp(act, -2, -2, top = 12))
        val wifi = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        box.addView(wifi)
        val shown = HashSet<String>()
        val finder = PrinterFinder(act) { name, host, port, path ->
            act.runOnUiThread {
                if (shown.add("$host:$port")) {
                    wifi.addView(row(act, name, "$host:$port") {
                        choose { p.edit().putString("pr_mode", "ipp").putString("pr_name", name).putString("pr_host", host).putInt("pr_port", port).putString("pr_path", path).apply() }
                    }, Ui.lp(act, -1, -2, top = 4))
                }
            }
        }
        box.addView(Ui.label(act, "Or type the printer's IP address", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 12))
        val ip = Ui.input(act, "", "192.168.1.50")
        box.addView(ip, Ui.lp(act, -1, -2, top = 4))
        box.addView(Ui.pill(act, "Use this IP", Ui.ACCENT) {
            val t = ip.text.toString().trim()
            if (t.isNotEmpty()) {
                val host = t.substringBefore(':')
                val port = t.substringAfter(':', "631").toIntOrNull() ?: 631
                choose { p.edit().putString("pr_mode", "ipp").putString("pr_name", host).putString("pr_host", host).putInt("pr_port", port).putString("pr_path", "ipp/print").apply() }
            }
        }, Ui.lp(act, -1, -2, top = 8))
        val d = dark(act).setView(ScrollView(act).apply { addView(box) })
            .setNegativeButton("Close", null)
            .setOnDismissListener { finder.stop() }
            .create()
        dlgRef[0] = d
        d.show()
        finder.start()
    }

    private fun chips(act: Activity, box: LinearLayout, title: String, opts: List<Pair<String, String>>, p: SharedPreferences, key: String, def: String) {
        box.addView(Ui.label(act, title, 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val list = ArrayList<TextView>()
        fun paint() {
            val cur = p.getString(key, def)
            for (c in list) c.background = Ui.shape(act, if (c.tag == cur) Ui.ACCENT else Ui.CARD2, 12)
        }
        for ((label, value) in opts) {
            val c = Ui.pill(act, label, Ui.CARD2) { p.edit().putString(key, value).apply(); paint() }
            c.textSize = 12f
            c.setPadding(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8))
            c.tag = value
            list.add(c)
            row.addView(c, Ui.lp(act, 0, -2, 1f, side = 2))
        }
        paint()
        box.addView(row, Ui.lp(act, -1, -2, top = 4))
    }

    fun settings(act: Activity, p: SharedPreferences, onChanged: () -> Unit = {}) {
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(act, 16), Ui.dp(act, 12), Ui.dp(act, 16), Ui.dp(act, 12))
        }
        box.addView(Ui.label(act, "Print settings", 18f, Ui.TEXT, true))
        box.addView(Ui.label(act, label(p), 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        val res = Ui.label(act, statusLine(p), 12f, Ui.TEXT)
        box.addView(res, Ui.lp(act, -2, -2, top = 6))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.pill(act, "Test connection", Ui.ACCENT) {
            res.text = "Testing ..."
            test(act, p) { r -> res.text = (if (r.ok) "\u25CF " else "\u25CB ") + r.text; onChanged() }
        }, Ui.lp(act, 0, -2, 1f, side = 3))
        row.addView(Ui.pill(act, "Print test page", Ui.CARD2) { testPrint(act, p) { s -> res.text = s } }, Ui.lp(act, 0, -2, 1f, side = 3))
        box.addView(row, Ui.lp(act, -1, -2, top = 8))
        chips(act, box, "Paper size", listOf("Printer default" to "auto", "4x6 in" to "4x6", "5x7 in" to "5x7", "A6" to "a6", "A4" to "a4", "Letter" to "letter"), p, "pr_media", "auto")
        chips(act, box, "Copies", listOf("1" to "1", "2" to "2", "3" to "3", "4" to "4"), p, "pr_copies", "1")
        chips(act, box, "Colour", listOf("Colour" to "color", "Black & white" to "mono"), p, "pr_color", "color")
        chips(act, box, "Quality", listOf("Draft" to "draft", "Normal" to "normal", "High" to "high"), p, "pr_quality", "normal")
        chips(act, box, "Picture on paper", listOf("Fit whole picture" to "fit", "Fill paper (crop)" to "fill"), p, "pr_scale", "fit")
        box.addView(Switch(act).apply {
            text = "If the printer can't be reached, open the Android print screen"
            textSize = 13f
            setTextColor(Ui.TEXT)
            isChecked = p.getBoolean("pr_fallback", true)
            setOnCheckedChangeListener { _, on -> p.edit().putBoolean("pr_fallback", on).apply() }
        }, Ui.lp(act, -1, -2, top = 14))
        dark(act).setView(ScrollView(act).apply { addView(box) }).setPositiveButton("Done", null).show()
    }
}
