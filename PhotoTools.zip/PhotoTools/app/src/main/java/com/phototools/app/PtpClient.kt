package com.phototools.app

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal PTP-over-USB client with the few Canon EOS commands needed (remote mode, events, live view). */
class PtpClient private constructor(
    private val conn: UsbDeviceConnection,
    private val iface: UsbInterface,
    private val inEp: UsbEndpoint,
    private val outEp: UsbEndpoint
) {
    class Reply(val code: Int, val params: IntArray, val data: ByteArray?)
    class Info(val name: String, val size: Long, val format: Int)

    private var txId = 0
    private val chunk = ByteArray(16384)
    private var cPos = 0
    private var cLim = 0

    companion object {
        const val OK = 0x2001
        private val LE = ByteOrder.LITTLE_ENDIAN

        fun open(conn: UsbDeviceConnection, d: UsbDevice): PtpClient? {
            for (i in 0 until d.interfaceCount) {
                val itf = d.getInterface(i)
                if (itf.interfaceClass != UsbConstants.USB_CLASS_STILL_IMAGE) continue
                var bi: UsbEndpoint? = null
                var bo: UsbEndpoint? = null
                for (e in 0 until itf.endpointCount) {
                    val ep = itf.getEndpoint(e)
                    if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK) {
                        if (ep.direction == UsbConstants.USB_DIR_IN) bi = ep else bo = ep
                    }
                }
                if (bi != null && bo != null && conn.claimInterface(itf, true)) {
                    return PtpClient(conn, itf, bi, bo)
                }
            }
            return null
        }

        /** Object ids announced by Canon "object added" style events. */
        fun objectEvents(d: ByteArray): List<Int> {
            val out = ArrayList<Int>()
            val b = ByteBuffer.wrap(d).order(LE)
            var p = 0
            while (p + 8 <= d.size) {
                val size = b.getInt(p)
                val type = b.getInt(p + 4)
                if (type == 0 || size < 8 || p + size > d.size) break
                if ((type == 0xC181 || type == 0xC1A7 || type == 0xC186 || type == 0xC190) && size >= 12) {
                    out.add(b.getInt(p + 8))
                }
                p += size
            }
            return out
        }

        /** Camera setting changes (ISO, shutter, aperture ...) announced by the camera: (property code, value). */
        fun propEvents(d: ByteArray): List<Pair<Int, Int>> {
            val out = ArrayList<Pair<Int, Int>>()
            val b = ByteBuffer.wrap(d).order(LE)
            var p = 0
            while (p + 8 <= d.size) {
                val size = b.getInt(p)
                val type = b.getInt(p + 4)
                if (type == 0 || size < 8 || p + size > d.size) break
                if (type == 0xC189 && size >= 16) out.add(Pair(b.getInt(p + 8), b.getInt(p + 12)))
                p += size
            }
            return out
        }

        fun extractJpeg(d: ByteArray?): ByteArray? {
            if (d == null || d.size < 10) return null
            var s = -1
            for (i in 0 until d.size - 2) {
                if (d[i] == 0xFF.toByte() && d[i + 1] == 0xD8.toByte() && d[i + 2] == 0xFF.toByte()) { s = i; break }
            }
            if (s < 0) return null
            var e = -1
            for (i in d.size - 2 downTo s + 2) {
                if (d[i] == 0xFF.toByte() && d[i + 1] == 0xD9.toByte()) { e = i + 2; break }
            }
            if (e < 0) return null
            return d.copyOfRange(s, e)
        }
    }

    private fun fill() {
        var tries = 0
        while (true) {
            val n = conn.bulkTransfer(inEp, chunk, chunk.size, 15000)
            if (n > 0) { cPos = 0; cLim = n; return }
            if (n < 0) throw IOException("USB read failed")
            if (++tries > 4) throw IOException("USB read empty")
        }
    }

    private fun readBytes(dst: ByteArray, off: Int, len: Int) {
        var o = off
        var left = len
        while (left > 0) {
            if (cPos >= cLim) fill()
            val k = minOf(left, cLim - cPos)
            System.arraycopy(chunk, cPos, dst, o, k)
            cPos += k; o += k; left -= k
        }
    }

    private fun drain(len: Long, sink: OutputStream?) {
        var left = len
        while (left > 0) {
            if (cPos >= cLim) fill()
            val k = minOf(left, (cLim - cPos).toLong()).toInt()
            sink?.write(chunk, cPos, k)
            cPos += k; left -= k
        }
    }

    private fun write(b: ByteArray) {
        var off = 0
        while (off < b.size) {
            val n = minOf(b.size - off, 16384)
            val r = conn.bulkTransfer(outEp, b, off, n, 10000)
            if (r <= 0) throw IOException("USB write failed")
            off += r
        }
    }

    @Synchronized
    fun transact(code: Int, params: IntArray = IntArray(0), out: ByteArray? = null, sink: OutputStream? = null): Reply {
        cPos = 0; cLim = 0
        txId++
        val cmd = ByteBuffer.allocate(12 + 4 * params.size).order(LE)
        cmd.putInt(12 + 4 * params.size).putShort(1).putShort(code.toShort()).putInt(txId)
        for (p in params) cmd.putInt(p)
        write(cmd.array())
        if (out != null) {
            val d = ByteBuffer.allocate(12 + out.size).order(LE)
            d.putInt(12 + out.size).putShort(2).putShort(code.toShort()).putInt(txId).put(out)
            write(d.array())
        }
        var data: ByteArray? = null
        val hdr = ByteArray(12)
        while (true) {
            readBytes(hdr, 0, 12)
            val b = ByteBuffer.wrap(hdr).order(LE)
            val len = b.getInt(0).toLong() and 0xFFFFFFFFL
            val type = b.getShort(4).toInt() and 0xFFFF
            val rc = b.getShort(6).toInt() and 0xFFFF
            val payload = if (len >= 12) len - 12 else 0L
            when (type) {
                2 -> {
                    if (sink != null) drain(payload, sink)
                    else { val bos = ByteArrayOutputStream(); drain(payload, bos); data = bos.toByteArray() }
                }
                3 -> {
                    val pa = ByteArray(payload.toInt())
                    readBytes(pa, 0, pa.size)
                    val pb = ByteBuffer.wrap(pa).order(LE)
                    val ps = IntArray(pa.size / 4) { pb.getInt(it * 4) }
                    return Reply(rc, ps, data)
                }
                else -> drain(payload, null)
            }
        }
    }

    fun ok(code: Int, vararg p: Int): Boolean = transact(code, p).code == OK

    fun openSession(): Boolean {
        val c = transact(0x1002, intArrayOf(1)).code
        return c == OK || c == 0x201E
    }

    fun closeSession() { try { transact(0x1003) } catch (_: Exception) {} }
    fun release() { try { conn.releaseInterface(iface) } catch (_: Exception) {} }

    fun setProp(prop: Int, value: Int): Boolean {
        val b = ByteBuffer.allocate(12).order(LE)
        b.putInt(12).putInt(prop).putInt(value)
        return transact(0x9110, out = b.array()).code == OK
    }

    /** Remote shutter (full press). Falls back to the old single command on older bodies. */
    fun shoot(): Boolean {
        val r = transact(0x9128, intArrayOf(3, 0)).code
        if (r == 0x2005) return transact(0x910F).code == OK
        try { Thread.sleep(250) } catch (_: InterruptedException) {}
        transact(0x9129, intArrayOf(3))
        return r == OK
    }

    fun events(): ByteArray? = transact(0x9116).data

    fun liveFrame(): ByteArray? {
        val r = transact(0x9153, intArrayOf(0x00100000))
        return if (r.code == OK) extractJpeg(r.data) else null
    }

    private fun intList(d: ByteArray?): IntArray {
        if (d == null || d.size < 4) return IntArray(0)
        val b = ByteBuffer.wrap(d).order(LE)
        val n = minOf(b.getInt(0), (d.size - 4) / 4)
        return IntArray(maxOf(n, 0)) { b.getInt(4 + it * 4) }
    }

    fun storageIds(): IntArray = intList(transact(0x1004).data)
    fun handles(storage: Int, parent: Int): IntArray = intList(transact(0x1007, intArrayOf(storage, 0, parent)).data)

    fun objectInfo(h: Int): Info? {
        return try {
            val r = transact(0x1008, intArrayOf(h))
            val d = r.data
            if (r.code != OK || d == null || d.size < 53) return null
            val b = ByteBuffer.wrap(d).order(LE)
            val fmt = b.getShort(4).toInt() and 0xFFFF
            val size = b.getInt(8).toLong() and 0xFFFFFFFFL
            val n = d[52].toInt() and 0xFF
            val sb = StringBuilder()
            var i = 0
            while (i < n - 1 && 53 + i * 2 + 1 < d.size) { sb.append(b.getShort(53 + i * 2).toInt().toChar()); i++ }
            Info(sb.toString(), size, fmt)
        } catch (e: IOException) { throw e } catch (e: Exception) { null }
    }

    fun getObject(h: Int, sink: OutputStream): Boolean = transact(0x1009, intArrayOf(h), sink = sink).code == OK
}
