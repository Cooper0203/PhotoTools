package com.phototools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.ExecutorService
import kotlin.math.max
import kotlin.math.min

/** "Templates" tab: upload a ready-made template or create one with your own size (px, cm, mm, inch). */
class TemplatePane(
    private val act: Activity,
    private val prefs: SharedPreferences,
    private val pool: ExecutorService
) {
    companion object { const val REQ = 201 }

    val view = ScrollView(act)
    var onChanged: (() -> Unit)? = null
    private var list: MutableList<Template> = TemplateStore.load(act)
    private val col = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val listBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

    init {
        view.addView(col)
        col.addView(Ui.label(act, "Templates", 22f, Ui.TEXT, true))
        col.addView(Ui.label(act, "Upload a ready-made template (PNG with transparent photo windows) or create your own size.", 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4, bottom = 10))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.pill(act, "Upload template", Ui.ACCENT) { pickFile() }, Ui.lp(act, 0, -2, 1f, side = 3))
        row.addView(Ui.pill(act, "Create new", Ui.CARD2) { showForm(null, "My template") }, Ui.lp(act, 0, -2, 1f, side = 3))
        col.addView(row)
        val sw = Switch(act).apply {
            text = "Show template on live view (photo booth)"
            textSize = 14f
            setTextColor(Ui.TEXT)
            isChecked = prefs.getBoolean("tpl_live", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("tpl_live", on).apply(); onChanged?.invoke() }
        }
        col.addView(sw, Ui.lp(act, -1, -2, top = 12, bottom = 8))
        col.addView(listBox)
        refresh()
    }

    fun active(): Template? {
        val id = prefs.getString("active_tpl", "") ?: ""
        return list.firstOrNull { it.id == id }
    }

    fun refresh() {
        listBox.removeAllViews()
        if (list.isEmpty()) {
            listBox.addView(Ui.label(act, "No templates yet. Tap Upload template or Create new.", 14f, Ui.MUTED), Ui.lp(act, -2, -2, top = 12))
            return
        }
        val activeId = prefs.getString("active_tpl", "") ?: ""
        for (t in list) {
            val card = Ui.card(act)
            val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Ui.CARD2)
            }
            top.addView(iv, Ui.lp(act, Ui.dp(act, 96), Ui.dp(act, 128)))
            pool.execute {
                try {
                    val bm = TemplateTools.preview(act, t, 400)
                    act.runOnUiThread { iv.setImageBitmap(bm) }
                } catch (_: Exception) {}
            }
            val info = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            info.addView(Ui.label(act, t.name, 16f, Ui.TEXT, true))
            info.addView(Ui.label(act, t.sizeText(), 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
            info.addView(Ui.label(act, "${t.slots.size} photo window(s)  |  " + (if (t.hasOverlay) "uploaded design" else "grid layout"), 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
            if (t.id == activeId) info.addView(Ui.label(act, "IN USE", 12f, Ui.GREEN, true), Ui.lp(act, -2, -2, top = 6))
            top.addView(info, Ui.lp(act, 0, -2, 1f, side = 12))
            card.addView(top)
            val btns = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            btns.addView(Ui.pill(act, if (t.id == activeId) "In use" else "Use this", if (t.id == activeId) Ui.CARD2 else Ui.ACCENT) {
                prefs.edit().putString("active_tpl", t.id).apply()
                refresh()
                onChanged?.invoke()
            }, Ui.lp(act, 0, -2, 1f, side = 3))
            btns.addView(Ui.pill(act, "Delete", Ui.CARD2, Ui.RED) {
                list.remove(t)
                TemplateStore.save(act, list)
                TemplateStore.delete(act, t.id)
                if (prefs.getString("active_tpl", "") == t.id) prefs.edit().putString("active_tpl", "").apply()
                refresh()
                onChanged?.invoke()
            }, Ui.lp(act, 0, -2, 1f, side = 3))
            card.addView(btns, Ui.lp(act, -1, -2, top = 10))
            listBox.addView(card, Ui.lp(act, -1, -2, top = 10))
        }
    }

    private fun pickFile() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        act.startActivityForResult(i, REQ)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?): Boolean {
        if (req != REQ) return false
        val u: Uri? = data?.data
        if (result == Activity.RESULT_OK && u != null) {
            pool.execute {
                try {
                    val bmp = TemplateTools.decodeFit(act, u, 4000, true)
                    act.runOnUiThread { showForm(bmp, "My template") }
                } catch (e: Exception) {
                    act.runOnUiThread { Toast.makeText(act, "Could not open that image: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }
        }
        return true
    }

    private fun num(e: EditText, def: Double): Double = e.text.toString().trim().toDoubleOrNull() ?: def

    private fun field(parent: LinearLayout, label: String, value: String, decimal: Boolean = true): EditText {
        parent.addView(Ui.label(act, label, 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val et = EditText(act).apply {
            setText(value)
            setTextColor(Ui.TEXT)
            inputType = if (decimal) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL else InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            background = Ui.shape(act, Ui.CARD2, 10)
            setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8))
        }
        parent.addView(et, Ui.lp(act, -1, -2, top = 2))
        return et
    }

    /** Form used for both "Create new" (overlay == null) and "Upload template". */
    private fun showForm(overlay: Bitmap?, defName: String) {
        val detected: List<Slot> = if (overlay != null) TemplateTools.detectSlots(overlay) else emptyList()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.CARD)
            setPadding(Ui.dp(act, 18), Ui.dp(act, 12), Ui.dp(act, 18), Ui.dp(act, 12))
        }
        box.addView(Ui.label(act, if (overlay != null) "Upload template" else "Create template", 18f, Ui.TEXT, true))
        if (overlay != null) {
            box.addView(Ui.label(act,
                "Image ${overlay.width} x ${overlay.height} px. " +
                    if (detected.isNotEmpty()) "Found ${detected.size} photo window(s)." else "No transparent windows found - choose a grid below.",
                12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
        }
        val name = field(box, "Name", defName, false)

        var unit = if (overlay != null) "cm" else "inch"
        val dpiEt = field(box, "Print resolution (DPI)", "300")
        val wEt = field(box, if (overlay != null) "Print width" else "Width", "4")
        val hEt = field(box, if (overlay != null) "Print height" else "Height", "6")
        if (overlay != null) {
            val wi = overlay.width / 300.0
            val hi = overlay.height / 300.0
            wEt.setText(String.format(Locale.US, "%.2f", wi * 2.54))
            hEt.setText(String.format(Locale.US, "%.2f", hi * 2.54))
        }

        val unitRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val unitChips = ArrayList<TextView>()
        fun paintUnits() {
            for (c in unitChips) c.background = Ui.shape(act, if (c.tag == unit) Ui.ACCENT else Ui.CARD2, 12)
        }
        for (u in listOf("px", "cm", "mm", "inch")) {
            val chip = Ui.pill(act, u, Ui.CARD2) {
                val dpi = max(50.0, num(dpiEt, 300.0))
                val wi = TemplateTools.toInches(unit, num(wEt, 4.0), dpi)
                val hi = TemplateTools.toInches(unit, num(hEt, 6.0), dpi)
                unit = u
                wEt.setText(String.format(Locale.US, "%.2f", TemplateTools.fromInches(unit, wi, dpi)))
                hEt.setText(String.format(Locale.US, "%.2f", TemplateTools.fromInches(unit, hi, dpi)))
                paintUnits()
            }
            chip.tag = u
            chip.textSize = 13f
            unitChips.add(chip)
            unitRow.addView(chip, Ui.lp(act, 0, -2, 1f, side = 2))
        }
        box.addView(Ui.label(act, "Measurement unit", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        box.addView(unitRow, Ui.lp(act, -1, -2, top = 4))
        paintUnits()

        var rowsEt: EditText? = null
        var colsEt: EditText? = null
        var marginEt: EditText? = null
        var gapEt: EditText? = null
        if (overlay == null || detected.isEmpty()) {
            box.addView(Ui.label(act, "Photo windows (grid)", 14f, Ui.TEXT, true), Ui.lp(act, -2, -2, top = 14))
            rowsEt = field(box, "Rows", "3", false)
            colsEt = field(box, "Columns", "1", false)
            marginEt = field(box, "Outer margin (% of size)", "4")
            gapEt = field(box, "Gap between photos (% of size)", "3")
        }

        var bg = Color.WHITE
        if (overlay == null) {
            val bgRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            val colors = listOf("White" to Color.WHITE, "Black" to Color.BLACK, "Cream" to 0xFFF5ECD7.toInt(), "Navy" to 0xFF14213D.toInt())
            val chips = ArrayList<TextView>()
            for ((label, colr) in colors) {
                val chip = Ui.pill(act, label, Ui.CARD2) {
                    bg = colr
                    for (c in chips) c.background = Ui.shape(act, if (c.tag == bg) Ui.ACCENT else Ui.CARD2, 12)
                }
                chip.tag = colr
                chip.textSize = 12f
                chips.add(chip)
                bgRow.addView(chip, Ui.lp(act, 0, -2, 1f, side = 2))
            }
            for (c in chips) c.background = Ui.shape(act, if (c.tag == bg) Ui.ACCENT else Ui.CARD2, 12)
            box.addView(Ui.label(act, "Background colour", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
            box.addView(bgRow, Ui.lp(act, -1, -2, top = 4))
        }

        val sv = ScrollView(act).apply { addView(box) }
        AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
            .setView(sv)
            .setPositiveButton("Save") { _, _ ->
                val dpi = max(50.0, num(dpiEt, 300.0))
                val id = System.currentTimeMillis().toString()
                val nm = name.text.toString().trim().ifEmpty { "Template" }
                val wIn = max(0.3, TemplateTools.toInches(unit, num(wEt, 4.0), dpi))
                val hIn = max(0.3, TemplateTools.toInches(unit, num(hEt, 6.0), dpi))
                val rows = rowsEt?.text.toString().toIntOrNull() ?: 1
                val cols = colsEt?.text.toString().toIntOrNull() ?: 1
                val marginPct = marginEt?.text.toString().toDoubleOrNull() ?: 4.0
                val gapPct = gapEt?.text.toString().toDoubleOrNull() ?: 3.0
                val bgColor = bg
                pool.execute {
                    try {
                        val t: Template
                        if (overlay != null) {
                            TemplateStore.overlayFile(act, id).outputStream().use { overlay.compress(Bitmap.CompressFormat.PNG, 100, it) }
                            val slots = if (detected.isNotEmpty()) detected else TemplateTools.gridSlots(
                                overlay.width, overlay.height, rows, cols, marginPct, gapPct
                            )
                            t = Template(id, nm, overlay.width, overlay.height, wIn, hIn, Color.WHITE, true, slots)
                        } else {
                            val wPx = min(6000.0, max(200.0, wIn * dpi)).toInt()
                            val hPx = min(6000.0, max(200.0, hIn * dpi)).toInt()
                            val slots = TemplateTools.gridSlots(
                                wPx, hPx, rows, cols, marginPct, gapPct
                            )
                            t = Template(id, nm, wPx, hPx, wPx / dpi, hPx / dpi, bgColor, false, slots)
                        }
                        list.add(t)
                        TemplateStore.save(act, list)
                        if ((prefs.getString("active_tpl", "") ?: "").isEmpty()) prefs.edit().putString("active_tpl", id).apply()
                        act.runOnUiThread { refresh(); onChanged?.invoke() }
                    } catch (e: Exception) {
                        act.runOnUiThread { Toast.makeText(act, "Could not save template: ${e.message}", Toast.LENGTH_LONG).show() }
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
