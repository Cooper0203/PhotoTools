package com.phototools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicBoolean

/** Settings cards for the Facebook Page album and Google Drive. */
class CloudCards(private val act: Activity, private val pool: ExecutorService) {
    private val p = Cloud.prefs(act)

    private fun field(parent: LinearLayout, label: String, key: String, def: String = "", hint: String = ""): EditText {
        parent.addView(Ui.label(act, label, 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val et = Ui.input(act, p.getString(key, def) ?: def, hint)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { p.edit().putString(key, s.toString().trim()).apply() }
        })
        parent.addView(et, Ui.lp(act, -1, -2, top = 3))
        return et
    }

    private fun toggle(text: String, key: String): Switch = Switch(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(Ui.TEXT)
        isChecked = p.getBoolean(key, false)
        setOnCheckedChangeListener { _, on -> p.edit().putBoolean(key, on).apply() }
    }

    fun facebookCard(autoSwitch: Boolean): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Facebook Page", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Uploads automatically to an album on your Page (no 10-photo limit).", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        field(card, "Page ID", "fb_page_id", "", "1234567890")
        field(card, "Page access token", "fb_token", "", "paste token here")
        field(card, "Album name", "fb_album", "Photobooth", "Photobooth")
        val status = Ui.label(act, "", 12f, Ui.MUTED)
        card.addView(Ui.pill(act, "Test connection", Ui.CARD2) {
            val tok = (p.getString("fb_token", "") ?: "").trim()
            if (tok.isEmpty()) { status.text = "Paste the Page access token first."; return@pill }
            status.text = "Checking ..."
            pool.execute {
                val msg = try {
                    val r = FacebookApi.verify(tok)
                    if (r.ok) "Connected as: ${r.text}" else "Facebook says: ${r.text}"
                } catch (e: Exception) { "No connection: ${e.message}" }
                act.runOnUiThread { status.text = msg }
            }
        }, Ui.lp(act, -1, -2, top = 12))
        card.addView(status, Ui.lp(act, -2, -2, top = 6))
        if (autoSwitch) card.addView(toggle("Upload every finished photo to the album", "fb_auto"), Ui.lp(act, -1, -2, top = 10))
        return card
    }

    private var safFolder: TextView? = null

    /** True when someone already set up the old Google Cloud (client id) method. */
    fun apiConfigured(): Boolean = (p.getString("drive_client_id", "") ?: "").isNotBlank()

    fun onActivityResult(req: Int, res: Int, data: Intent?): Boolean {
        if (!SafDrive.onResult(act, req, res, data)) return false
        safFolder?.text = SafDrive.label(act)
        return true
    }

    /** Google Drive without any developer setup: pick a Drive folder with Android's file picker. */
    fun driveSafCard(): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Google Drive  (no setup needed)", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Pick a folder on your Drive with Android's own file picker. No API keys, client IDs or Google Cloud project. Free.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        val folder = Ui.label(act, SafDrive.label(act), 13f, Ui.TEXT)
        safFolder = folder
        card.addView(folder, Ui.lp(act, -2, -2, top = 10))
        card.addView(Ui.pill(act, "Choose Drive folder", Ui.ACCENT) { SafDrive.pick(act) }, Ui.lp(act, -1, -2, top = 8))
        card.addView(Ui.label(act, "In the picker open the menu, choose \"Drive\", open or create a folder, then tap \"Use this folder\". If Drive is not listed, your phone does not offer it - use the options below.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 6))
        card.addView(toggle("Upload every camera photo automatically (JPG and RAW)", "saf_orig"), Ui.lp(act, -1, -2, top = 12))
        card.addView(toggle("Upload finished template pictures", "saf_final"), Ui.lp(act, -1, -2, top = 8))
        card.addView(Switch(act).apply {
            text = "Use sub-folders: Camera photos / Template pictures"
            textSize = 14f
            setTextColor(Ui.TEXT)
            isChecked = p.getBoolean("saf_sub", true)
            setOnCheckedChangeListener { _, on -> p.edit().putBoolean("saf_sub", on).apply() }
        }, Ui.lp(act, -1, -2, top = 8))
        val res = Ui.label(act, "", 12f, Ui.MUTED)
        card.addView(Ui.pill(act, "Test the folder", Ui.CARD2) {
            res.text = "Testing ..."
            pool.execute { val m = SafDrive.test(act); act.runOnUiThread { res.text = m } }
        }, Ui.lp(act, -1, -2, top = 10))
        card.addView(res, Ui.lp(act, -2, -2, top = 4))
        card.addView(Ui.pill(act, "Send waiting files with the Drive app", Ui.CARD2) {
            val jobs = CloudQueue.all(act).filter { it.kind == "saf" }.take(30)
            val ok = SafDrive.shareToDriveApp(act, jobs.map { Uri.parse(it.uri) })
            if (ok) for (j in jobs) CloudQueue.remove(act, j.id)
            res.text = if (jobs.isEmpty()) "Nothing is waiting." else if (ok) "Sent ${jobs.size} file(s) to the Drive app - pick the folder there." else "The Drive app could not be opened."
        }, Ui.lp(act, -1, -2, top = 8))
        card.addView(Ui.pill(act, "Clear upload queue", Ui.CARD2, Ui.RED) {
            CloudQueue.clear(act)
            res.text = "Queue cleared."
        }, Ui.lp(act, -1, -2, top = 8))
        card.addView(Ui.label(act,
            "How it works: every file is copied into that folder by the app, in the background, with retries and no duplicates. " +
            "Whether Drive then uploads it by itself depends on Android and the Drive app. Check the Drive app once to confirm.",
            11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        return card
    }

    /** Other automatic backups that need no developer account. */
    fun driveHelpCard(folderPath: String): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Other automatic Drive / Google backups", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act,
            "1. Google Photos: open Photos > your profile picture > Photos settings > Backup > Back up device folders, then switch on $folderPath. " +
            "Photos are backed up in the background to your Google account (free 15 GB shared with Drive). They appear in Google Photos, not in a Drive folder.\n\n" +
            "2. A free sync app such as Round Sync or FolderSync: connect your Google Drive in that app (it uses its own sign-in) and sync $folderPath to a Drive folder on a schedule.",
            12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 6))
        card.addView(Ui.pill(act, "Open Google Photos", Ui.CARD2) {
            val i = act.packageManager.getLaunchIntentForPackage("com.google.android.apps.photos")
            if (i != null) act.startActivity(i) else android.widget.Toast.makeText(act, "Google Photos is not installed", android.widget.Toast.LENGTH_SHORT).show()
        }, Ui.lp(act, -1, -2, top = 8))
        return card
    }

    fun driveCard(): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Google Drive", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Backs up every single photo (JPG and RAW) to a Drive folder.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        field(card, "Client ID", "drive_client_id", "", "xxxx.apps.googleusercontent.com")
        field(card, "Client secret", "drive_secret", "", "paste secret")
        field(card, "Drive folder name", "drive_folder", "Photobooth", "Photobooth")
        val status = Ui.label(act, if ((p.getString("drive_refresh", "") ?: "").isNotEmpty()) "Connected" else "Not connected", 12f, Ui.MUTED)
        card.addView(Ui.pill(act, "Connect Google Drive", Ui.ACCENT) { connect(status) }, Ui.lp(act, -1, -2, top = 12))
        card.addView(status, Ui.lp(act, -2, -2, top = 6))
        card.addView(toggle("Upload every camera photo (JPG + RAW)", "drive_auto"), Ui.lp(act, -1, -2, top = 10))
        card.addView(toggle("Also upload each finished picture (for the download QR code)", "drive_final"), Ui.lp(act, -1, -2, top = 6))
        return card
    }

    /** Post to a Facebook Page through Make / Zapier / IFTTT / n8n: no Meta developer account and no Graph API. */
    fun webhookCard(autoSwitch: Boolean): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Page via Make / Zapier (no Meta developer account)", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Create a free Make.com (or Zapier) scenario: Webhook \u2192 Facebook Pages. Paste its webhook URL here. The app sends each picture to it and Make posts it to your Page.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        field(card, "Webhook URL", "hook_url", "", "https://hook.eu1.make.com/...")
        field(card, "Album / caption name sent along", "fb_album", "Photobooth", "Photobooth")
        if (autoSwitch) card.addView(toggle("Send every finished picture to the webhook", "hook_auto"), Ui.lp(act, -1, -2, top = 10))
        return card
    }

    private fun connect(status: TextView) {
        val cid = (p.getString("drive_client_id", "") ?: "").trim()
        val sec = (p.getString("drive_secret", "") ?: "").trim()
        if (cid.isEmpty() || sec.isEmpty()) { status.text = "Enter the Client ID and Client secret first."; return }
        status.text = "Contacting Google ..."
        val cancelled = AtomicBoolean(false)
        pool.execute {
            val r = try { DriveApi.startDevice(cid) } catch (e: Exception) { Pair(null, e.message ?: "no connection") }
            val dev = r.first
            if (dev == null) { act.runOnUiThread { status.text = "Google error: ${r.second}" }; return@execute }
            act.runOnUiThread {
                status.text = "Waiting: open ${dev.url} and enter ${dev.userCode}"
                AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Connect Google Drive")
                    .setMessage("1. Tap Open page\n2. Sign in and enter this code:\n\n${dev.userCode}\n\n3. Allow access, then come back.")
                    .setPositiveButton("Open page") { _, _ -> try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(dev.url))) } catch (_: Exception) {} }
                    .setNeutralButton("Copy code") { _, _ ->
                        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", dev.userCode))
                    }
                    .setNegativeButton("Cancel") { _, _ -> cancelled.set(true); status.text = "Cancelled" }
                    .show()
            }
            var interval = maxOf(3, dev.interval)
            val end = System.currentTimeMillis() + dev.expiresIn * 1000L
            while (!cancelled.get() && System.currentTimeMillis() < end) {
                try { Thread.sleep(interval * 1000L) } catch (_: InterruptedException) { return@execute }
                val res = try { DriveApi.pollDevice(act, cid, sec, dev) } catch (e: Exception) { Pair(false, "pending") }
                if (res.first) { act.runOnUiThread { status.text = "Connected" }; return@execute }
                if (res.second == "slow") interval += 5
                else if (res.second != "pending") { act.runOnUiThread { status.text = "Failed: ${res.second}" }; return@execute }
            }
            if (!cancelled.get()) act.runOnUiThread { status.text = "Code expired. Tap Connect again." }
        }
    }
}
