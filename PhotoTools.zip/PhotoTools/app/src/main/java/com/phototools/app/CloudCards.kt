package com.phototools.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.atomic.AtomicBoolean

/** Settings cards for the Facebook Page album and Google Drive. */
class CloudCards(private val act: Activity, private val pool: ExecutorService) {
    private val p = Cloud.prefs(act)

    private fun field(parent: LinearLayout, label: String, key: String, def: String = "", hint: String = ""): EditText {
        parent.addView(Ui.label(act, label, 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val et = Ui.input(act, p.getString(key, def) ?: def, hint)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { p.edit().putString(key, s.toString().trim()).apply() }
        })
        parent.addView(et, Ui.lp(act, -1, -2, top = 3))
        return et
    }

    private fun toggle(text: String, key: String): Switch = Switch(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(Ui.TEXT)
        isChecked = p.getBoolean(key, false)
        setOnCheckedChangeListener { _, on -> p.edit().putBoolean(key, on).apply() }
    }

    fun facebookCard(autoSwitch: Boolean): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Facebook Page", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Uploads automatically to an album on your Page (no 10-photo limit).", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        field(card, "Page ID", "fb_page_id", "", "1234567890")
        field(card, "Page access token", "fb_token", "", "paste token here")
        field(card, "Album name", "fb_album", "Photobooth", "Photobooth")
        val status = Ui.label(act, "", 12f, Ui.MUTED)
        card.addView(Ui.pill(act, "Test connection", Ui.CARD2) {
            val tok = (p.getString("fb_token", "") ?: "").trim()
            if (tok.isEmpty()) { status.text = "Paste the Page access token first."; return@pill }
            status.text = "Checking ..."
            pool.execute {
                val msg = try {
                    val r = FacebookApi.verify(tok)
                    if (r.ok) "Connected as: ${r.text}" else "Facebook says: ${r.text}"
                } catch (e: Exception) { "No connection: ${e.message}" }
                act.runOnUiThread { status.text = msg }
            }
        }, Ui.lp(act, -1, -2, top = 12))
        card.addView(status, Ui.lp(act, -2, -2, top = 6))
        if (autoSwitch) card.addView(toggle("Upload every finished photo to the album", "fb_auto"), Ui.lp(act, -1, -2, top = 10))
        return card
    }

    fun driveCard(): LinearLayout {
        val card = Ui.card(act)
        card.addView(Ui.label(act, "Google Drive", 16f, Ui.TEXT, true))
        card.addView(Ui.label(act, "Backs up every single photo (JPG and RAW) to a Drive folder.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        field(card, "Client ID", "drive_client_id", "", "xxxx.apps.googleusercontent.com")
        field(card, "Client secret", "drive_secret", "", "paste secret")
        field(card, "Drive folder name", "drive_folder", "Photobooth", "Photobooth")
        val status = Ui.label(act, if ((p.getString("drive_refresh", "") ?: "").isNotEmpty()) "Connected" else "Not connected", 12f, Ui.MUTED)
        card.addView(Ui.pill(act, "Connect Google Drive", Ui.ACCENT) { connect(status) }, Ui.lp(act, -1, -2, top = 12))
        card.addView(status, Ui.lp(act, -2, -2, top = 6))
        card.addView(toggle("Upload every camera photo (JPG + RAW)", "drive_auto"), Ui.lp(act, -1, -2, top = 10))
        return card
    }

    private fun connect(status: TextView) {
        val cid = (p.getString("drive_client_id", "") ?: "").trim()
        val sec = (p.getString("drive_secret", "") ?: "").trim()
        if (cid.isEmpty() || sec.isEmpty()) { status.text = "Enter the Client ID and Client secret first."; return }
        status.text = "Contacting Google ..."
        val cancelled = AtomicBoolean(false)
        pool.execute {
            val r = try { DriveApi.startDevice(cid) } catch (e: Exception) { Pair(null, e.message ?: "no connection") }
            val dev = r.first
            if (dev == null) { act.runOnUiThread { status.text = "Google error: ${r.second}" }; return@execute }
            act.runOnUiThread {
                status.text = "Waiting: open ${dev.url} and enter ${dev.userCode}"
                AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("Connect Google Drive")
                    .setMessage("1. Tap Open page\n2. Sign in and enter this code:\n\n${dev.userCode}\n\n3. Allow access, then come back.")
                    .setPositiveButton("Open page") { _, _ -> try { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(dev.url))) } catch (_: Exception) {} }
                    .setNeutralButton("Copy code") { _, _ ->
                        (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", dev.userCode))
                    }
                    .setNegativeButton("Cancel") { _, _ -> cancelled.set(true); status.text = "Cancelled" }
                    .show()
            }
            var interval = maxOf(3, dev.interval)
            val end = System.currentTimeMillis() + dev.expiresIn * 1000L
            while (!cancelled.get() && System.currentTimeMillis() < end) {
                try { Thread.sleep(interval * 1000L) } catch (_: InterruptedException) { return@execute }
                val res = try { DriveApi.pollDevice(act, cid, sec, dev) } catch (e: Exception) { Pair(false, "pending") }
                if (res.first) { act.runOnUiThread { status.text = "Connected" }; return@execute }
                if (res.second == "slow") interval += 5
                else if (res.second != "pending") { act.runOnUiThread { status.text = "Failed: ${res.second}" }; return@execute }
            }
            if (!cancelled.get()) act.runOnUiThread { status.text = "Code expired. Tap Connect again." }
        }
    }
}
