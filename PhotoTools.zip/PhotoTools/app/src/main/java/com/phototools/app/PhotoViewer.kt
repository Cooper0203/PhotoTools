package com.phototools.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.net.Uri
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import java.util.concurrent.ExecutorService
import kotlin.math.abs
import kotlin.math.min

/** Full-screen photo viewer shown on top of the app (pinch to zoom, double-tap, swipe left/right). */
class PhotoViewer(
    private val act: Activity,
    private val items: List<Uri>,
    private var index: Int,
    private val pool: ExecutorService
) {
    private val dialog = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
    private val img = ZoomImageView(act)
    private val counter = Ui.label(act, "", 15f)

    fun show() {
        val root = FrameLayout(act)
        root.setBackgroundColor(Color.BLACK)
        root.addView(img, FrameLayout.LayoutParams(-1, -1))
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(Ui.dp(act, 16), Ui.dp(act, 28), Ui.dp(act, 8), Ui.dp(act, 10))
        }
        bar.addView(counter, Ui.lp(act, 0, -2, 1f))
        bar.addView(Ui.pill(act, "Close", Ui.CARD2) { dialog.dismiss() })
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        img.onSwipe = { d -> go(d) }
        img.onTap = { bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        dialog.setContentView(root)
        dialog.show()
        load()
    }

    private fun go(d: Int) {
        val n = index + d
        if (n in items.indices) { index = n; load() }
    }

    private fun load() {
        val i = index
        counter.text = "${i + 1} / ${items.size}"
        pool.execute {
            try {
                val bm = act.contentResolver.loadThumbnail(items[i], Size(2400, 2400), null)
                act.runOnUiThread { if (i == index) img.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
    }
}

class ZoomImageView(c: Context) : ImageView(c) {
    var onSwipe: ((Int) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    private val m = Matrix()
    private val vals = FloatArray(9)
    private var base = 1f

    private val scaleDetector = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val cur = scaleNow()
            val target = (cur * d.scaleFactor).coerceIn(base, base * 6f)
            val k = target / cur
            m.postScale(k, k, d.focusX, d.focusY)
            keepInside()
            imageMatrix = m
            return true
        }
    })

    private val gestures = GestureDetector(c, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scaleNow() > base * 1.05f) fit() else {
                m.postScale(2.5f, 2.5f, e.x, e.y)
                keepInside()
                imageMatrix = m
            }
            return true
        }
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (scaleNow() > base * 1.05f) {
                m.postTranslate(-dx, -dy)
                keepInside()
                imageMatrix = m
                return true
            }
            return false
        }
        override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
            if (scaleNow() <= base * 1.05f && abs(vx) > 900 && abs(vx) > abs(vy)) {
                onSwipe?.invoke(if (vx < 0) 1 else -1)
                return true
            }
            return false
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
    })

    init {
        scaleType = ScaleType.MATRIX
        setBackgroundColor(Color.BLACK)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    override fun setImageBitmap(bm: android.graphics.Bitmap?) {
        super.setImageBitmap(bm)
        fit()
    }

    private fun scaleNow(): Float { m.getValues(vals); return vals[Matrix.MSCALE_X] }

    private fun fit() {
        val d = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        if (dw <= 0f || dh <= 0f) return
        base = min(width / dw, height / dh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2f, (height - dh * base) / 2f)
        imageMatrix = m
    }

    private fun keepInside() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(r)
        var dx = 0f
        var dy = 0f
        if (r.width() <= width) dx = (width - r.width()) / 2f - r.left
        else if (r.left > 0) dx = -r.left else if (r.right < width) dx = width - r.right
        if (r.height() <= height) dy = (height - r.height()) / 2f - r.top
        else if (r.top > 0) dy = -r.top else if (r.bottom < height) dy = height - r.bottom
        m.postTranslate(dx, dy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        if (!scaleDetector.isInProgress) gestures.onTouchEvent(e)
        return true
    }
}
