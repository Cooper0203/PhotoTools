package com.phototools.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.documentfile.provider.DocumentFile

/** The "pick media -> send to Facebook" screen part. Used by the Facebook app and the combined app. */
class FacebookSection(private val act: Activity) {
    val view = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val prefs = act.getSharedPreferences("fb", Context.MODE_PRIVATE)
    private val statusView = Ui.text(act, "", 15f)

    companion object {
        const val REQ_FILES = 101
        const val REQ_FOLDER = 102
        private const val BATCH = 10
    }

    init {
        view.addView(Ui.text(act, "Facebook Media Uploader", 22f, true))
        view.addView(statusView)
        view.addView(Ui.button(act, "Pick photos / videos") { pickFiles() })
        view.addView(Ui.button(act, "Pick a whole folder") { pickFolder() })
        view.addView(Ui.text(act, "Post to:", 15f, true))
        val rg = RadioGroup(act)
        listOf(
            "My personal profile (Facebook app)",
            "My Page (Meta Business Suite app)",
            "Let me choose the app"
        ).forEachIndexed { idx, label ->
            rg.addView(RadioButton(act).apply { text = label; id = 1000 + idx })
        }
        rg.check(1000 + prefs.getInt("dest", 0))
        rg.setOnCheckedChangeListener { _, id -> prefs.edit().putInt("dest", id - 1000).apply() }
        view.addView(rg)
        view.addView(Ui.button(act, "Send next batch to Facebook") { share() })
        view.addView(Ui.button(act, "Clear list") { UploadQueue.clear(act); refresh("List cleared.") })
        view.addView(Ui.text(act,
            "Facebook does not allow other apps to post for you, so this app opens Facebook with up to 10 " +
            "photos (or videos) ready. Tap Post there, come back here and tap the button again for the next batch. " +
            "Picking works offline; posting needs internet. Your Facebook password is never used by this app.", 13f))
        refresh()
    }

    fun refresh(msg: String? = null) {
        val n = UploadQueue.all(act).size
        statusView.text = (if (msg != null) "$msg\n" else "") + "$n item(s) waiting. Sent 10 at a time."
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        act.startActivityForResult(i, REQ_FILES)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        act.startActivityForResult(i, REQ_FOLDER)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?) {
        if (result != Activity.RESULT_OK || data == null) return
        if (req == REQ_FILES) {
            val found = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) for (k in 0 until clip.itemCount) found.add(clip.getItemAt(k).uri)
            else data.data?.let { found.add(it) }
            for (u in found) {
                try {
                    act.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {}
            }
            UploadQueue.addAll(act, found)
            refresh("Added ${found.size} item(s).")
        } else if (req == REQ_FOLDER) {
            val tree = data.data ?: return
            try {
                act.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            refresh("Reading folder...")
            Thread {
                val found = ArrayList<Uri>()
                DocumentFile.fromTreeUri(act, tree)?.let { collect(it, found, 0) }
                UploadQueue.addAll(act, found)
                act.runOnUiThread { refresh("Added ${found.size} item(s) from the folder.") }
            }.start()
        }
    }

    private fun collect(dir: DocumentFile, out: MutableList<Uri>, depth: Int) {
        for (f in dir.listFiles()) {
            if (f.isDirectory) {
                if (depth < 5) collect(f, out, depth + 1)
            } else {
                val t = f.type ?: ""
                val n = (f.name ?: "").lowercase()
                if (t.startsWith("image/") || t.startsWith("video/") ||
                    listOf(".jpg", ".jpeg", ".png", ".heic", ".webp", ".mp4", ".mov").any { n.endsWith(it) }
                ) out.add(f.uri)
            }
        }
    }

    private fun isVideo(u: Uri): Boolean = (act.contentResolver.getType(u) ?: "").startsWith("video")

    private fun share() {
        val all = UploadQueue.all(act)
        if (all.isEmpty()) { refresh("Nothing selected yet."); return }
        val video = isVideo(all.first())
        val batch = all.filter { isVideo(it) == video }.take(BATCH)
        val mime = if (video) "video/*" else "image/*"
        val i = if (batch.size == 1) {
            Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, batch[0]) }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = mime
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(batch))
            }
        }
        val clip = ClipData.newUri(act.contentResolver, "media", batch[0])
        for (u in batch.drop(1)) clip.addItem(ClipData.Item(u))
        i.clipData = clip
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

        val pkg = when (prefs.getInt("dest", 0)) {
            0 -> "com.facebook.katana"
            1 -> "com.facebook.pages.app"
            else -> null
        }
        var note = ""
        if (pkg != null) {
            try {
                act.startActivity(Intent(i).setPackage(pkg))
                done(batch, "Facebook opened. Finish the post there.")
                return
            } catch (e: ActivityNotFoundException) {
                note = "That app is not installed - choose another app. "
            } catch (e: Exception) {
                note = "Could not open it directly. "
            }
        }
        try {
            act.startActivity(Intent.createChooser(i, "Share to Facebook"))
            done(batch, note + "Pick Facebook in the list, then finish the post.")
        } catch (e: Exception) {
            refresh("Sharing failed: ${e.message}")
        }
    }

    private fun done(batch: List<Uri>, msg: String) {
        UploadQueue.removeAll(act, batch)
        refresh(msg)
    }
}
