package com.phototools.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.documentfile.provider.DocumentFile
import java.util.concurrent.Executors

/** Facebook Auto Upload: pick any number of photos, then send them to a Page album (automatic) or a profile (via the Facebook app). */
class FacebookSection(private val act: Activity) {
    val view = ScrollView(act).apply { setBackgroundColor(Ui.BG) }
    private val prefs = act.getSharedPreferences("fb", Context.MODE_PRIVATE)
    private val pool = Executors.newFixedThreadPool(2)
    private val cloud = CloudCards(act, pool)
    private val col = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 28), Ui.dp(act, 16), Ui.dp(act, 28))
    }
    private val countText = Ui.label(act, "", 15f)
    private val uploadText = Ui.label(act, "", 13f, Ui.MUTED)
    private val profileBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val pageBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val hookBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val fbCard = cloud.facebookCard(false)
    private val hookCard = cloud.webhookCard(false)
    private val segs = ArrayList<TextView>()

    companion object {
        const val REQ_FILES = 101
        const val REQ_FOLDER = 102
        private const val BATCH = 10
    }

    init {
        view.addView(col)
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(act).apply { setImageResource(R.drawable.logo) }, Ui.lp(act, Ui.dp(act, 60), Ui.dp(act, 60)))
        val t = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.label(act, "Facebook Auto Upload", 22f, Ui.TEXT, true))
        t.addView(Ui.label(act, "Photos and videos to your Page or profile", 13f, Ui.MUTED))
        head.addView(t, Ui.lp(act, 0, -2, 1f, side = 12))
        col.addView(head, Ui.lp(act, -1, -2, bottom = 14))

        val pick = Ui.card(act)
        pick.addView(Ui.label(act, "Photos", 16f, Ui.TEXT, true))
        pick.addView(countText, Ui.lp(act, -2, -2, top = 4))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Ui.pill(act, "Pick photos", Ui.ACCENT) { pickFiles() }, Ui.lp(act, 0, -2, 1f, side = 3))
        row.addView(Ui.pill(act, "Pick folder", Ui.CARD2) { pickFolder() }, Ui.lp(act, 0, -2, 1f, side = 3))
        row.addView(Ui.pill(act, "Clear", Ui.CARD2, Ui.RED) { UploadQueue.clear(act); refresh() }, Ui.lp(act, 0, -2, 0.6f, side = 3))
        pick.addView(row, Ui.lp(act, -1, -2, top = 10))
        col.addView(pick, Ui.lp(act, -1, -2, bottom = 12))

        val dest = Ui.card(act)
        dest.addView(Ui.label(act, "Post to", 16f, Ui.TEXT, true))
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.shape(act, Ui.CARD2, 14)
            setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
        }
        listOf("Profile", "Page", "Page (no API)").forEachIndexed { i, n ->
            val s = Ui.pill(act, n, Color.TRANSPARENT, Ui.MUTED) { prefs.edit().putInt("dest", i).apply(); paintSeg() }
            s.textSize = 14f
            segs.add(s)
            bar.addView(s, Ui.lp(act, 0, -2, 1f))
        }
        dest.addView(bar, Ui.lp(act, -1, -2, top = 10))

        profileBox.addView(Ui.label(act, "Facebook does not let apps post to a personal profile by themselves. The photos are sent to the Facebook app in batches of $BATCH: tap Post there, come back and send the next batch. You can pick as many photos as you like.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        profileBox.addView(Ui.pill(act, "Send next batch to Facebook", Ui.ACCENT) { shareProfile() }, Ui.lp(act, -1, -2, top = 10))
        dest.addView(profileBox)

        pageBox.addView(Ui.label(act, "Uploads everything you picked, one after another, with no limit. Set the Page details below once.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        pageBox.addView(Ui.pill(act, "Upload all to Page album", Ui.ACCENT) { uploadToPage() }, Ui.lp(act, -1, -2, top = 10))
        pageBox.addView(uploadText, Ui.lp(act, -2, -2, top = 8))
        pageBox.addView(Ui.pill(act, "Clear upload queue", Ui.CARD2, Ui.RED) { CloudQueue.clear(act); refresh() }, Ui.lp(act, -1, -2, top = 8))
        dest.addView(pageBox)
        hookBox.addView(Ui.label(act, "No Meta developer account needed. Make.com or Zapier already has Facebook's permission: you log in to your Page there once, and this app only sends the pictures to their webhook.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        hookBox.addView(Ui.pill(act, "Send all via webhook", Ui.ACCENT) { sendViaHook() }, Ui.lp(act, -1, -2, top = 10))
        hookBox.addView(Ui.pill(act, "Clear upload queue", Ui.CARD2, Ui.RED) { CloudQueue.clear(act); refresh() }, Ui.lp(act, -1, -2, top = 8))
        dest.addView(hookBox)
        col.addView(dest, Ui.lp(act, -1, -2, bottom = 12))

        col.addView(fbCard)
        col.addView(hookCard)
        Uploader.onChange = { act.runOnUiThread { refresh() } }
        paintSeg()
        refresh()
    }

    private fun paintSeg() {
        val d = prefs.getInt("dest", 0)
        segs.forEachIndexed { i, s ->
            s.background = Ui.shape(act, if (i == d) Ui.ACCENT else Color.TRANSPARENT, 11)
            s.setTextColor(if (i == d) Color.WHITE else Ui.MUTED)
        }
        profileBox.visibility = if (d == 0) View.VISIBLE else View.GONE
        pageBox.visibility = if (d == 1) View.VISIBLE else View.GONE
        hookBox.visibility = if (d == 2) View.VISIBLE else View.GONE
        fbCard.visibility = if (d == 1) View.VISIBLE else View.GONE
        hookCard.visibility = if (d == 2) View.VISIBLE else View.GONE
    }

    fun refresh(msg: String? = null) {
        val n = UploadQueue.all(act).size
        countText.text = (if (msg != null) "$msg\n" else "") + "$n photo(s) ready"
        uploadText.text = "Upload queue: ${CloudQueue.size(act)} waiting  |  ${Uploader.done} sent  |  ${Uploader.failed} failed\n${Uploader.status}"
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        act.startActivityForResult(i, REQ_FILES)
    }

    private fun pickFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        act.startActivityForResult(i, REQ_FOLDER)
    }

    fun onActivityResult(req: Int, result: Int, data: Intent?) {
        if (result != Activity.RESULT_OK || data == null) return
        if (req == REQ_FILES) {
            val found = ArrayList<Uri>()
            val clip = data.clipData
            if (clip != null) for (k in 0 until clip.itemCount) found.add(clip.getItemAt(k).uri)
            else data.data?.let { found.add(it) }
            for (u in found) {
                try { act.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            }
            UploadQueue.addAll(act, found)
            refresh("Added ${found.size} photo(s).")
        } else if (req == REQ_FOLDER) {
            val tree = data.data ?: return
            try { act.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            refresh("Reading folder ...")
            Thread {
                val found = ArrayList<Uri>()
                DocumentFile.fromTreeUri(act, tree)?.let { collect(it, found, 0) }
                UploadQueue.addAll(act, found)
                act.runOnUiThread { refresh("Added ${found.size} photo(s) from the folder.") }
            }.start()
        }
    }

    private fun collect(dir: DocumentFile, out: MutableList<Uri>, depth: Int) {
        for (f in dir.listFiles()) {
            if (f.isDirectory) {
                if (depth < 5) collect(f, out, depth + 1)
            } else {
                val t = f.type ?: ""
                val n = (f.name ?: "").lowercase()
                if (t.startsWith("image/") || t.startsWith("video/") ||
                    listOf(".jpg", ".jpeg", ".png", ".heic", ".webp", ".mp4", ".mov").any { n.endsWith(it) }
                ) out.add(f.uri)
            }
        }
    }

    private fun uploadToPage() {
        val all = UploadQueue.all(act)
        if (all.isEmpty()) { refresh("Pick photos first."); return }
        val p = Cloud.prefs(act)
        if ((p.getString("fb_page_id", "") ?: "").isBlank() || (p.getString("fb_token", "") ?: "").isBlank()) {
            refresh("Fill in the Page ID and Page access token below first.")
            return
        }
        CloudQueue.addAll(act, "fb", all)
        UploadQueue.clear(act)
        Uploader.kick(act)
        refresh("Uploading ${all.size} item(s) to the Page album ...")
    }

    private fun sendViaHook() {
        val all = UploadQueue.all(act)
        if (all.isEmpty()) { refresh("Pick photos first."); return }
        if ((Cloud.prefs(act).getString("hook_url", "") ?: "").isBlank()) { refresh("Paste the webhook URL below first."); return }
        CloudQueue.addAll(act, "hook", all)
        UploadQueue.clear(act)
        Uploader.kick(act)
        refresh("Sending ${all.size} item(s) to the webhook ...")
    }

    private fun isVideo(u: Uri): Boolean = (act.contentResolver.getType(u) ?: "").startsWith("video")

    private fun shareProfile() {
        val all = UploadQueue.all(act)
        if (all.isEmpty()) { refresh("Pick photos first."); return }
        val video = isVideo(all.first())
        val batch = all.filter { isVideo(it) == video }.take(BATCH)
        val mime = if (video) "video/*" else "image/*"
        val i = if (batch.size == 1) {
            Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, batch[0]) }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = mime
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(batch))
            }
        }
        val clip = ClipData.newUri(act.contentResolver, "media", batch[0])
        for (u in batch.drop(1)) clip.addItem(ClipData.Item(u))
        i.clipData = clip
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            act.startActivity(Intent(i).setPackage("com.facebook.katana"))
        } catch (e: ActivityNotFoundException) {
            try { act.startActivity(Intent.createChooser(i, "Share to Facebook")) } catch (e2: Exception) { refresh("Sharing failed: ${e2.message}"); return }
        }
        UploadQueue.removeAll(act, batch)
        refresh("Facebook opened with ${batch.size} item(s). Tap Post, then come back for the next batch.")
    }
}
