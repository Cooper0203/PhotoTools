package com.phototools.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class CloudRes(val ok: Boolean, val text: String, val permanent: Boolean = false)
class CloudJob(val kind: String, val uri: String, val name: String, val attempts: Int, val id: Long = System.nanoTime())

object Cloud {
    class Http(val code: Int, val body: String)

    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("cloud", Context.MODE_PRIVATE)
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun nameOf(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) return it.getString(0)
            }
        } catch (_: Exception) {}
        return "photo_${System.currentTimeMillis()}.jpg"
    }

    fun mimeOf(c: Context, uri: Uri, name: String): String {
        val m = c.contentResolver.getType(uri)
        if (!m.isNullOrEmpty()) return m
        return when (name.substringAfterLast('.', "").lowercase()) {
            "jpg", "jpeg" -> "image/jpeg"
            "png" -> "image/png"
            "mp4" -> "video/mp4"
            "mov" -> "video/quicktime"
            else -> "application/octet-stream"
        }
    }

    private fun read(c: HttpURLConnection): Http {
        val code = c.responseCode
        val st = if (code in 200..299) c.inputStream else c.errorStream
        return Http(code, st?.bufferedReader()?.use { it.readText() } ?: "")
    }

    fun request(url: String, method: String, headers: Map<String, String> = emptyMap(), body: ByteArray? = null): Http {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 20000
            c.readTimeout = 60000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body) } }
            return read(c)
        } finally { c.disconnect() }
    }

    /** multipart/form-data POST (Facebook). */
    fun postForm(url: String, fields: Map<String, String>, fileField: String, fileName: String, mime: String, input: InputStream): Http {
        val b = "----pb${System.currentTimeMillis()}"
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 240000
            c.setChunkedStreamingMode(64 * 1024)
            c.setRequestProperty("Content-Type", "multipart/form-data; boundary=$b")
            c.outputStream.use { out ->
                for ((k, v) in fields) out.write("--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n".toByteArray())
                val fn = fileName.replace("\"", "_")
                out.write("--$b\r\nContent-Disposition: form-data; name=\"$fileField\"; filename=\"$fn\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
                input.copyTo(out, 64 * 1024)
                out.write("\r\n--$b--\r\n".toByteArray())
            }
            return read(c)
        } finally { c.disconnect() }
    }

    /** multipart/related POST (Google Drive: JSON metadata + file). */
    fun postRelated(url: String, token: String, meta: String, mime: String, input: InputStream): Http {
        val b = "----pb${System.currentTimeMillis()}"
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 20000
            c.readTimeout = 240000
            c.setChunkedStreamingMode(64 * 1024)
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "multipart/related; boundary=$b")
            c.outputStream.use { out ->
                out.write("--$b\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n".toByteArray())
                out.write("--$b\r\nContent-Type: $mime\r\n\r\n".toByteArray())
                input.copyTo(out, 64 * 1024)
                out.write("\r\n--$b--\r\n".toByteArray())
            }
            return read(c)
        } finally { c.disconnect() }
    }
}

/** Persistent list of files waiting to be uploaded: "fb" Facebook Page album, "drive" / "drivepub" Google Drive, "hook" webhook. */
object CloudQueue {
    private fun p(c: Context) = Cloud.prefs(c)

    @Synchronized
    fun all(c: Context): MutableList<CloudJob> {
        val out = ArrayList<CloudJob>()
        try {
            val arr = JSONArray(p(c).getString("jobs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(CloudJob(o.getString("k"), o.getString("u"), o.getString("n"), o.optInt("a", 0), o.optLong("i", System.nanoTime() + i)))
            }
        } catch (_: Exception) {}
        return out
    }

    private fun save(c: Context, l: List<CloudJob>) {
        val arr = JSONArray()
        for (j in l) arr.put(JSONObject().put("k", j.kind).put("u", j.uri).put("n", j.name).put("a", j.attempts).put("i", j.id))
        p(c).edit().putString("jobs", arr.toString()).apply()
    }

    /** front = true puts the file before everything else (used for finished booth pictures). */
    @Synchronized fun add(c: Context, kind: String, uri: Uri, name: String, front: Boolean = false) {
        val l = all(c)
        val j = CloudJob(kind, uri.toString(), name, 0)
        if (front) l.add(0, j) else l.add(j)
        save(c, l)
    }

    @Synchronized fun addAll(c: Context, kind: String, uris: List<Uri>) {
        val l = all(c)
        for (u in uris) l.add(CloudJob(kind, u.toString(), Cloud.nameOf(c, u), 0))
        save(c, l)
    }

    @Synchronized fun first(c: Context): CloudJob? = all(c).firstOrNull()
    @Synchronized fun size(c: Context): Int = all(c).size
    @Synchronized fun clear(c: Context) = save(c, emptyList())

    @Synchronized fun remove(c: Context, id: Long) {
        val l = all(c)
        if (l.removeAll { it.id == id }) save(c, l)
    }

    @Synchronized fun requeue(c: Context, id: Long) {
        val l = all(c)
        val k = l.indexOfFirst { it.id == id }
        if (k < 0) return
        val j = l.removeAt(k)
        l.add(CloudJob(j.kind, j.uri, j.name, j.attempts + 1, j.id))
        save(c, l)
    }
}

object FacebookApi {
    private const val GRAPH = "https://graph.facebook.com/v19.0"
    private const val GRAPH_VIDEO = "https://graph-video.facebook.com/v19.0"

    private fun err(h: Cloud.Http): CloudRes {
        var msg = h.body.take(160)
        var perm = false
        try {
            val e = JSONObject(h.body).optJSONObject("error")
            if (e != null) {
                msg = e.optString("message", msg)
                val code = e.optInt("code")
                perm = code == 190 || code == 200 || code == 10 || code == 100 || code == 368
            }
        } catch (_: Exception) {}
        return CloudRes(false, msg, perm)
    }

    fun verify(token: String): CloudRes {
        val h = Cloud.request("$GRAPH/me?fields=id,name&access_token=${Cloud.enc(token)}", "GET")
        return if (h.code in 200..299) CloudRes(true, JSONObject(h.body).optString("name")) else err(h)
    }

    fun albumId(ctx: Context, pageId: String, token: String, name: String): CloudRes {
        val p = Cloud.prefs(ctx)
        val tag = "$name|$pageId"
        if (p.getString("fb_album_for", "") == tag) {
            val id = p.getString("fb_album_id", "") ?: ""
            if (id.isNotEmpty()) return CloudRes(true, id)
        }
        val h = Cloud.request("$GRAPH/$pageId/albums?fields=id,name&limit=100&access_token=${Cloud.enc(token)}", "GET")
        if (h.code !in 200..299) return err(h)
        var found = ""
        val arr = JSONObject(h.body).optJSONArray("data")
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("name").equals(name, true)) { found = o.optString("id"); break }
        }
        if (found.isEmpty()) {
            val body = "name=${Cloud.enc(name)}&access_token=${Cloud.enc(token)}".toByteArray()
            val c = Cloud.request("$GRAPH/$pageId/albums", "POST", mapOf("Content-Type" to "application/x-www-form-urlencoded"), body)
            if (c.code !in 200..299) return err(c)
            found = JSONObject(c.body).optString("id")
        }
        if (found.isEmpty()) return CloudRes(false, "Could not create the album")
        p.edit().putString("fb_album_id", found).putString("fb_album_for", tag).apply()
        return CloudRes(true, found)
    }

    /** target = album id (or page id when no album name is set). */
    fun uploadPhoto(ctx: Context, token: String, target: String, uri: Uri, name: String, mime: String): CloudRes {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return CloudRes(false, "Cannot open $name", true)
        val h = ins.use {
            Cloud.postForm("$GRAPH/$target/photos", mapOf("access_token" to token), "source", name, mime, it)
        }
        if (h.code !in 200..299) return err(h)
        val id = try { JSONObject(h.body).optString("id") } catch (_: Exception) { "" }
        return CloudRes(true, if (id.isNotEmpty()) "https://www.facebook.com/photo.php?fbid=$id" else "ok")
    }

    fun uploadVideo(ctx: Context, token: String, pageId: String, uri: Uri, name: String, mime: String): CloudRes {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return CloudRes(false, "Cannot open $name", true)
        val h = ins.use {
            Cloud.postForm("$GRAPH_VIDEO/$pageId/videos", mapOf("access_token" to token, "description" to name), "source", name, mime, it)
        }
        return if (h.code in 200..299) CloudRes(true, "ok") else err(h)
    }
}

/** Google Drive with the "limited-input device" OAuth flow (needs the user's own Google Cloud client id/secret). */
object DriveApi {
    class Device(val deviceCode: String, val userCode: String, val url: String, val interval: Int, val expiresIn: Int)
    private val FORM = mapOf("Content-Type" to "application/x-www-form-urlencoded")

    private fun errText(h: Cloud.Http): String {
        try {
            val o = JSONObject(h.body)
            val e = o.opt("error")
            if (e is JSONObject) return e.optString("message", h.body.take(160))
            val d = o.optString("error_description")
            return if (d.isNotEmpty()) d else e?.toString() ?: h.body.take(160)
        } catch (_: Exception) { return h.body.take(160) }
    }

    fun startDevice(clientId: String): Pair<Device?, String> {
        val body = "client_id=${Cloud.enc(clientId)}&scope=${Cloud.enc("https://www.googleapis.com/auth/drive.file")}".toByteArray()
        val h = Cloud.request("https://oauth2.googleapis.com/device/code", "POST", FORM, body)
        if (h.code !in 200..299) return Pair(null, errText(h))
        val o = JSONObject(h.body)
        return Pair(Device(o.getString("device_code"), o.getString("user_code"),
            o.optString("verification_url", "https://www.google.com/device"), o.optInt("interval", 5), o.optInt("expires_in", 1800)), "")
    }

    /** Returns (finished, message). message is "pending" / "slow" while the user has not approved yet. */
    fun pollDevice(ctx: Context, clientId: String, secret: String, d: Device): Pair<Boolean, String> {
        val body = ("client_id=${Cloud.enc(clientId)}&client_secret=${Cloud.enc(secret)}&device_code=${Cloud.enc(d.deviceCode)}" +
            "&grant_type=${Cloud.enc("urn:ietf:params:oauth:grant-type:device_code")}").toByteArray()
        val h = Cloud.request("https://oauth2.googleapis.com/token", "POST", FORM, body)
        if (h.code in 200..299) {
            val o = JSONObject(h.body)
            Cloud.prefs(ctx).edit()
                .putString("drive_refresh", o.optString("refresh_token"))
                .putString("drive_access", o.optString("access_token"))
                .putLong("drive_expires", System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000)
                .apply()
            return Pair(true, "ok")
        }
        val e = try { JSONObject(h.body).optString("error") } catch (_: Exception) { "" }
        return when (e) {
            "authorization_pending" -> Pair(false, "pending")
            "slow_down" -> Pair(false, "slow")
            else -> Pair(false, errText(h))
        }
    }

    fun accessToken(ctx: Context): String? {
        val p = Cloud.prefs(ctx)
        val tok = p.getString("drive_access", "") ?: ""
        if (tok.isNotEmpty() && System.currentTimeMillis() < p.getLong("drive_expires", 0) - 60000) return tok
        val refresh = p.getString("drive_refresh", "") ?: ""
        if (refresh.isEmpty()) return null
        val body = ("client_id=${Cloud.enc(p.getString("drive_client_id", "") ?: "")}&client_secret=${Cloud.enc(p.getString("drive_secret", "") ?: "")}" +
            "&refresh_token=${Cloud.enc(refresh)}&grant_type=refresh_token").toByteArray()
        val h = Cloud.request("https://oauth2.googleapis.com/token", "POST", FORM, body)
        if (h.code !in 200..299) return null
        val o = JSONObject(h.body)
        val t = o.optString("access_token")
        p.edit().putString("drive_access", t).putLong("drive_expires", System.currentTimeMillis() + o.optLong("expires_in", 3600) * 1000).apply()
        return t
    }

    private fun folderId(ctx: Context, token: String, name: String): CloudRes {
        val p = Cloud.prefs(ctx)
        if (p.getString("drive_folder_for", "") == name) {
            val id = p.getString("drive_folder_id", "") ?: ""
            if (id.isNotEmpty()) return CloudRes(true, id)
        }
        val auth = mapOf("Authorization" to "Bearer $token")
        val q = Cloud.enc("name='${name.replace("'", "\\'")}' and mimeType='application/vnd.google-apps.folder' and trashed=false")
        val h = Cloud.request("https://www.googleapis.com/drive/v3/files?q=$q&fields=files(id,name)", "GET", auth)
        if (h.code !in 200..299) return CloudRes(false, errText(h), h.code == 400 || h.code == 403)
        var id = ""
        val arr = JSONObject(h.body).optJSONArray("files")
        if (arr != null && arr.length() > 0) id = arr.getJSONObject(0).optString("id")
        if (id.isEmpty()) {
            val meta = JSONObject().put("name", name).put("mimeType", "application/vnd.google-apps.folder").toString()
            val c = Cloud.request("https://www.googleapis.com/drive/v3/files", "POST",
                mapOf("Authorization" to "Bearer $token", "Content-Type" to "application/json"), meta.toByteArray())
            if (c.code !in 200..299) return CloudRes(false, errText(c), c.code == 400 || c.code == 403)
            id = JSONObject(c.body).optString("id")
        }
        p.edit().putString("drive_folder_id", id).putString("drive_folder_for", name).apply()
        return CloudRes(true, id)
    }

    fun upload(ctx: Context, uri: Uri, name: String, mime: String, share: Boolean = false): CloudRes {
        val token = accessToken(ctx) ?: return CloudRes(false, "Google Drive is not connected", true)
        val folder = (Cloud.prefs(ctx).getString("drive_folder", "Photobooth") ?: "Photobooth").ifBlank { "Photobooth" }
        val f = folderId(ctx, token, folder)
        if (!f.ok) return f
        val ins = ctx.contentResolver.openInputStream(uri) ?: return CloudRes(false, "Cannot open $name", true)
        val meta = JSONObject().put("name", name).put("parents", JSONArray().put(f.text)).toString()
        val h = ins.use { Cloud.postRelated("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", token, meta, mime, it) }
        if (h.code in 200..299) {
            val id = try { JSONObject(h.body).optString("id") } catch (_: Exception) { "" }
            if (!share || id.isEmpty()) return CloudRes(true, "ok")
            // make this one file viewable by anyone who has the link (for the download QR code)
            val perm = Cloud.request("https://www.googleapis.com/drive/v3/files/$id/permissions", "POST",
                mapOf("Authorization" to "Bearer $token", "Content-Type" to "application/json"),
                """{"role":"reader","type":"anyone"}""".toByteArray())
            return CloudRes(true, if (perm.code in 200..299) "https://drive.google.com/file/d/$id/view?usp=sharing" else "ok")
        }
        if (h.code == 401) Cloud.prefs(ctx).edit().putString("drive_access", "").apply()
        return CloudRes(false, errText(h), h.code == 400 || h.code == 403 || h.code == 404)
    }
}

/** Sends a file to any webhook (Make, Zapier, n8n, IFTTT ...) - lets those services post to your Facebook Page, no Meta developer account needed. */
object WebhookApi {
    fun send(ctx: Context, url: String, uri: Uri, name: String, mime: String): CloudRes {
        val ins = ctx.contentResolver.openInputStream(uri) ?: return CloudRes(false, "Cannot open $name", true)
        val album = Cloud.prefs(ctx).getString("fb_album", "") ?: ""
        val h = ins.use { Cloud.postForm(url, mapOf("name" to name, "album" to album), "file", name, mime, it) }
        if (h.code in 200..299) {
            val link = try { JSONObject(h.body).let { o -> o.optString("link", o.optString("url", "")) } } catch (_: Exception) { "" }
            return CloudRes(true, if (link.startsWith("http")) link else "ok")
        }
        return CloudRes(false, "Webhook answered ${h.code}", h.code == 404 || h.code == 410)
    }
}

/** Background worker that sends the queued files, retrying when the network is down. */
object Uploader {
    @Volatile var status: String = ""
    @Volatile var done: Int = 0
    @Volatile var failed: Int = 0
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var onLink: ((String, String, String) -> Unit)? = null
    private var thread: Thread? = null

    private fun say(s: String) { status = s; onChange?.invoke() }

    @Synchronized
    fun kick(ctx: Context) {
        if (thread?.isAlive == true) return
        val app = ctx.applicationContext
        thread = Thread { loop(app) }.also { it.start() }
    }

    private fun loop(ctx: Context) {
        while (true) {
            val job = CloudQueue.first(ctx) ?: break
            val u = Uri.parse(job.uri)
            val target = when (job.kind) { "drive", "drivepub" -> "Google Drive"; "hook" -> "webhook"; else -> "Facebook" }
            say("Uploading ${job.name} to $target ...")
            val res: CloudRes = try {
                process(ctx, job, u)
            } catch (e: IOException) {
                CloudRes(false, e.message ?: "network error", false)
            } catch (e: Exception) {
                CloudRes(false, e.message ?: "error", true)
            }
            if (res.ok) {
                CloudQueue.remove(ctx, job.id)
                done++
                if (res.text.startsWith("http")) onLink?.invoke(job.kind, job.uri, res.text)
                say("Uploaded ${job.name}")
            } else if (res.permanent || job.attempts + 1 >= 6) {
                CloudQueue.remove(ctx, job.id)
                failed++
                say("Failed: ${job.name} - ${res.text}")
            } else {
                CloudQueue.requeue(ctx, job.id)
                say("Will retry ${job.name}: ${res.text}")
                try { Thread.sleep(10000) } catch (_: InterruptedException) { return }
            }
        }
        say(if (done + failed == 0) "" else "All done: $done uploaded, $failed failed")
    }

    private fun process(ctx: Context, job: CloudJob, u: Uri): CloudRes {
        val mime = Cloud.mimeOf(ctx, u, job.name)
        if (job.kind == "drive") return DriveApi.upload(ctx, u, job.name, mime, false)
        if (job.kind == "drivepub") return DriveApi.upload(ctx, u, job.name, mime, true)
        if (job.kind == "hook") {
            val hook = (Cloud.prefs(ctx).getString("hook_url", "") ?: "").trim()
            if (hook.isEmpty()) return CloudRes(false, "Webhook URL not set", true)
            return WebhookApi.send(ctx, hook, u, job.name, mime)
        }
        val p = Cloud.prefs(ctx)
        val pageId = (p.getString("fb_page_id", "") ?: "").trim()
        val token = (p.getString("fb_token", "") ?: "").trim()
        val album = (p.getString("fb_album", "") ?: "").trim()
        if (pageId.isEmpty() || token.isEmpty()) return CloudRes(false, "Facebook Page ID / token not set", true)
        if (mime.startsWith("video")) return FacebookApi.uploadVideo(ctx, token, pageId, u, job.name, mime)
        var target = pageId
        if (album.isNotEmpty()) {
            val a = FacebookApi.albumId(ctx, pageId, token, album)
            if (!a.ok) return a
            target = a.text
        }
        return FacebookApi.uploadPhoto(ctx, token, target, u, job.name, mime)
    }
}
