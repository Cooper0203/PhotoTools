package com.phototools.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Draws the template. The window being photographed shows the live camera picture. */
class BoothView(c: Context) : View(c) {
    var template: Template? = null
    var overlay: Bitmap? = null
    var bitmaps: Array<Bitmap?> = arrayOfNulls(0)
    var current = -1
    var live: Bitmap? = null
    var onSlotClick: ((Int) -> Unit)? = null

    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint()
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF94A3B8.toInt()
        textAlign = Paint.Align.CENTER
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Ui.ACCENT
    }
    private val area = RectF()

    private fun fitRect(t: Template): Float {
        val sc = min(width / t.wPx.toFloat(), height / t.hPx.toFloat())
        val w = t.wPx * sc
        val h = t.hPx * sc
        area.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
        return sc
    }

    override fun onDraw(cv: Canvas) {
        val t = template ?: return
        val sc = fitRect(t)
        fill.color = t.bg
        cv.drawRect(area, fill)
        val lv = live
        for ((i, s) in t.slots.withIndex()) {
            val dst = RectF(area.left + s.x * sc, area.top + s.y * sc, area.left + (s.x + s.w) * sc, area.top + (s.y + s.h) * sc)
            val b = bitmaps.getOrNull(i)
            if (b != null) {
                TemplateTools.drawCover(cv, b, dst, p)
            } else if (i == current && lv != null) {
                TemplateTools.drawCover(cv, lv, dst, p)
            } else {
                fill.color = 0xFF222B3F.toInt()
                cv.drawRect(dst, fill)
                txt.textSize = min(dst.width(), dst.height()) * 0.35f
                cv.drawText((i + 1).toString(), dst.centerX(), dst.centerY() + txt.textSize / 3f, txt)
            }
        }
        overlay?.let { cv.drawBitmap(it, null, area, p) }
        if (current in t.slots.indices) {
            val s = t.slots[current]
            stroke.strokeWidth = 3f * resources.displayMetrics.density
            cv.drawRect(area.left + s.x * sc, area.top + s.y * sc, area.left + (s.x + s.w) * sc, area.top + (s.y + s.h) * sc, stroke)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val t = template
            var hit = -1
            if (t != null) {
                val sc = fitRect(t)
                val tx = (e.x - area.left) / sc
                val ty = (e.y - area.top) / sc
                for ((i, s) in t.slots.withIndex()) {
                    if (tx >= s.x && tx <= s.x + s.w && ty >= s.y && ty <= s.y + s.h) { hit = i; break }
                }
            }
            onSlotClick?.invoke(hit)
        }
        return true
    }
}
