package com.phototools.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import java.util.concurrent.Executors

/** Camera cable -> phone screen with 3 tabs: Status, Gallery, Live View. */
class CanonSection(
    private val act: Activity,
    private val showQueueOption: Boolean,
    private val embedded: Boolean = false
) {
    val view = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    var extraChange: (() -> Unit)? = null

    private val prefs = act.getSharedPreferences("canon", Context.MODE_PRIVATE)
    private val usb = act.getSystemService(Context.USB_SERVICE) as UsbManager
    private var receiver: BroadcastReceiver? = null

    private val statusView = Ui.text(act, "", 16f)
    private val statusCol = Ui.column(act)
    private val statusPane = Ui.scroll(act, statusCol)

    private val galleryPane = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val galleryCount = Ui.text(act, "", 14f)
    private val grid = GridView(act)
    private var items: List<Uri> = emptyList()
    private val cache = LruCache<String, Bitmap>(150)
    private val pool = Executors.newFixedThreadPool(3)

    private val livePane = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val liveHint = Ui.text(act, "Shows what the camera sees. Camera must be connected.", 13f)
    private val liveImage = ImageView(act)
    private val liveButton: Button = Ui.button(act, "Start live view") { toggleLive() }

    private var lastCopied = -1

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFFDDDDDD.toInt())
            }
            val size = act.resources.displayMetrics.widthPixels / 3
            iv.layoutParams = AbsListView.LayoutParams(size, size)
            val uri = items[p]
            val key = uri.toString()
            iv.tag = key
            val cached = cache.get(key)
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageDrawable(null)
                pool.execute {
                    try {
                        val bm = act.contentResolver.loadThumbnail(uri, Size(256, 256), null)
                        cache.put(key, bm)
                        act.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
                    } catch (_: Exception) {}
                }
            }
            return iv
        }
    }

    init {
        // ---- Status tab ----
        statusCol.addView(Ui.text(act, "Canon 760D - Auto Copy", 22f, true))
        statusCol.addView(statusView)
        statusCol.addView(CheckBox(act).apply {
            text = "Also copy photos already on the card"
            isChecked = prefs.getBoolean("import_existing", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("import_existing", on).apply() }
        })
        if (showQueueOption) {
            statusCol.addView(CheckBox(act).apply {
                text = "Add new camera photos to the Facebook list"
                isChecked = prefs.getBoolean("auto_queue", false)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("auto_queue", on).apply() }
            })
        }
        statusCol.addView(Ui.button(act, "Connect camera now") { connect(null) })
        statusCol.addView(Ui.text(act,
            "1. Switch the camera ON (menu: Auto power off = Disable).\n" +
            "2. Plug the USB cable: camera -> phone (OTG adapter if needed).\n" +
            "3. Tap Allow / Always open with this app.\n" +
            "4. Take photos with the camera shutter. Each one is copied within seconds to Pictures/Canon760D.\n" +
            "5. See them in the Gallery tab. Watch the camera in the Live View tab.\n" +
            "Works offline. Camera originals are never deleted.", 13f))

        // ---- Gallery tab ----
        grid.numColumns = 3
        grid.horizontalSpacing = 4
        grid.verticalSpacing = 4
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ ->
            try {
                act.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(items[pos], "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (_: Exception) {}
        }
        galleryPane.addView(galleryCount)
        galleryPane.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- Live view tab ----
        liveImage.setBackgroundColor(Color.BLACK)
        liveImage.scaleType = ImageView.ScaleType.FIT_CENTER
        livePane.addView(liveHint)
        livePane.addView(liveButton)
        livePane.addView(liveImage, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- Tabs ----
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Status", "Gallery", "Live View").forEachIndexed { i, t ->
            bar.addView(Ui.button(act, t) { show(i) }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        view.addView(bar)
        val frame = FrameLayout(act)
        frame.addView(statusPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(galleryPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(livePane, FrameLayout.LayoutParams(-1, -1))
        view.addView(frame, if (embedded) LinearLayout.LayoutParams(-1, 1200) else LinearLayout.LayoutParams(-1, 0, 1f))
        show(0)
    }

    private fun show(i: Int) {
        statusPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        galleryPane.visibility = if (i == 1) View.VISIBLE else View.GONE
        livePane.visibility = if (i == 2) View.VISIBLE else View.GONE
        if (i != 2) CanonSyncService.liveWanted = false
        if (i == 1) loadGallery()
        updateLiveButton()
    }

    private fun toggleLive() {
        if (!CanonSyncService.running) {
            liveHint.text = "Connect the camera first (cable + Allow), then start live view."
            return
        }
        CanonSyncService.liveWanted = !CanonSyncService.liveWanted
        liveHint.text = if (CanonSyncService.liveWanted) "Starting live view (takes a few seconds)..." else "Live view stopped."
        updateLiveButton()
    }

    private fun updateLiveButton() {
        liveButton.text = if (CanonSyncService.liveWanted) "Stop live view" else "Start live view"
    }

    private fun loadGallery() {
        Thread {
            val list = ArrayList<Uri>()
            try {
                val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                act.contentResolver.query(
                    base, arrayOf(MediaStore.Images.Media._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("Pictures/Canon760D%"),
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && list.size < 400) list.add(ContentUris.withAppendedId(base, c.getLong(0)))
                }
            } catch (_: Exception) {}
            act.runOnUiThread {
                items = list
                adapter.notifyDataSetChanged()
                galleryCount.text = "${list.size} photo(s) transferred. Tap one to open."
            }
        }.start()
    }

    fun onCreate(intent: Intent?) {
        registerPermissionReceiver()
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        CanonSyncService.onChange = { act.runOnUiThread { refresh(); extraChange?.invoke() } }
        CanonSyncService.onFrame = { bm -> act.runOnUiThread { liveImage.setImageBitmap(bm) } }
        handleIntent(intent)
        refresh()
    }

    fun onNewIntent(intent: Intent?) = handleIntent(intent)

    fun onDestroy() {
        receiver?.let { try { act.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        CanonSyncService.onChange = null
        CanonSyncService.onFrame = null
        CanonSyncService.liveWanted = false
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect(CanonControl.deviceFrom(i))
    }

    fun connect(d: UsbDevice?) {
        val dev = d ?: CanonControl.findCamera(act)
        if (dev == null) {
            CanonSyncService.post("No camera found. Plug it in, switch it ON.")
            return
        }
        if (usb.hasPermission(dev)) {
            CanonControl.start(act, dev)
        } else {
            val pi = PendingIntent.getBroadcast(
                act, 0,
                Intent(CanonControl.ACTION_PERMISSION).setPackage(act.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usb.requestPermission(dev, pi)
        }
    }

    private fun registerPermissionReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val dev = CanonControl.deviceFrom(i)
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                    CanonControl.start(act, dev)
                } else {
                    CanonSyncService.post("USB permission not allowed. Tap Connect and choose Allow.")
                }
            }
        }
        receiver = r
        val f = IntentFilter(CanonControl.ACTION_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else act.registerReceiver(r, f)
    }

    fun refresh() {
        statusView.text = "Status: ${CanonSyncService.status}\n" +
            "Copied this session: ${CanonSyncService.copied}\n" +
            "Saved in: Pictures/Canon760D (videos: Movies/Canon760D, RAW: Download/Canon760D)"
        updateLiveButton()
        if (CanonSyncService.copied != lastCopied) {
            lastCopied = CanonSyncService.copied
            if (galleryPane.visibility == View.VISIBLE) loadGallery()
        }
    }
}
