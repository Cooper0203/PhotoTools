package com.phototools.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

/**
 * Canon Auto Copy (photobooth = false) and Android Photobooth (photobooth = true).
 * Live View covers the whole screen; every button is an icon drawn on top of the picture.
 */
class CanonSection(
    private val act: Activity,
    private val photobooth: Boolean
) {
    companion object {
        const val REQ_EXT = 202
        private const val T_STATUS = 0
        private const val T_GALLERY = 1
        private const val T_LIVE = 2
        private const val T_INFO = 3
        private const val T_TEMPLATES = 4
        private const val T_SETTINGS = 5
    }

    val view = FrameLayout(act).apply { setBackgroundColor(Ui.BG) }

    private val prefs = act.getSharedPreferences("canon", Context.MODE_PRIVATE)
    private val usb = act.getSystemService(Context.USB_SERVICE) as UsbManager
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<String, Bitmap>(200)
    private val cloud: CloudCards? = if (photobooth) CloudCards(act, pool) else null
    private var receiver: BroadcastReceiver? = null
    private var items: List<Uri> = emptyList()
    private var lastCopied = -1
    private var lastSeq = CanonSyncService.lastSavedSeq
    private var tab = T_STATUS
    private var prevTab = T_STATUS

    // ---- status tab
    private val statusDot = View(act).apply { background = Ui.shape(act, Ui.MUTED, 0, true) }
    private val statusText = Ui.label(act, "", 15f)
    private val statsText = Ui.label(act, "", 13f, Ui.MUTED)
    private val cloudText = Ui.label(act, "", 12f, Ui.MUTED)
    private val statusCol = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val statusPane = ScrollView(act).apply { addView(statusCol) }

    // ---- gallery tab
    private val galleryPane = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val galleryCount = Ui.label(act, "", 14f, Ui.MUTED)
    private val grid = GridView(act)
    private val galChips = ArrayList<TextView>()

    // ---- settings tab
    private val settingsCol = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val settingsPane = ScrollView(act).apply { addView(settingsCol) }
    private val printerText = Ui.label(act, "", 12f, Ui.MUTED)
    private val extText = Ui.label(act, "", 12f, Ui.MUTED)

    // ---- templates tab
    private val templatePane = TemplatePane(act, prefs, pool)

    // ---- live view (covers the whole screen, buttons drawn on top)
    private val livePane = FrameLayout(act).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
    private val liveImage = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val boothView = BoothView(act).apply { visibility = View.GONE }
    private val livePlaceholder = Ui.label(act, "Tap  \u25B6  to start live view", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
    private val liveInfo = Ui.label(act, "", 12f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 10)
        setPadding(Ui.dp(act, 10), Ui.dp(act, 4), Ui.dp(act, 10), Ui.dp(act, 4))
        maxLines = 2
    }
    private val countdownView = Ui.label(act, "", 120f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        setShadowLayer(14f, 0f, 0f, Color.BLACK)
        visibility = View.GONE
    }
    private val liveBadge = Ui.label(act, "  LIVE  ", 12f, Color.WHITE, true).apply {
        background = Ui.shape(act, Ui.RED, 8)
        setPadding(Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6))
        visibility = View.GONE
    }
    private lateinit var backBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var templateBtn: TextView
    private lateinit var fullBtn: TextView
    private lateinit var fillBtn: TextView
    private lateinit var pauseBtn: TextView
    private lateinit var liveBtn: TextView
    private lateinit var shootBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var finishBtn: TextView
    private lateinit var restartBtn: TextView
    private val controlsBar = LinearLayout(act).apply { gravity = Gravity.CENTER }
    private val panel = LinearLayout(act).apply {
        background = Ui.shape(act, 0x660B0F17.toInt(), 18)
        setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
    }

    // ---- camera info tab (Canon Auto Copy only)
    private val infoPane = FrameLayout(act).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
    private val infoImage = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val infoPlaceholder = Ui.label(act, "Tap  \u25B6  to start live view", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
    private val infoCount = Ui.label(act, "", 120f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        setShadowLayer(14f, 0f, 0f, Color.BLACK)
        visibility = View.GONE
    }
    private val infoMsg = Ui.label(act, "", 12f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 10)
        setPadding(Ui.dp(act, 10), Ui.dp(act, 4), Ui.dp(act, 10), Ui.dp(act, 4))
        maxLines = 2
    }
    private val infoBadge = Ui.label(act, "  LIVE  ", 12f, Color.WHITE, true).apply {
        background = Ui.shape(act, Ui.RED, 8)
        setPadding(Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6))
        visibility = View.GONE
    }
    private val infoStats = HashMap<String, TextView>()
    private lateinit var infoTimerBtn: TextView
    private lateinit var infoLiveBtn: TextView
    private val infoPanel = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = Ui.shape(act, 0x660B0F17.toInt(), 18)
        setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
    }

    private var infoThumbHolder: LinearLayout? = null

    // ---- finished-picture preview
    private val resultPane = FrameLayout(act).apply { setBackgroundColor(0xF2000000.toInt()); visibility = View.GONE; isClickable = true }
    private val resultImage = ImageView(act).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
    private val resultInfo = Ui.label(act, "", 13f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 12)
        setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8))
    }
    private val resultTimer = Ui.label(act, "", 13f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 12)
        setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8))
    }
    private val qrBox = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE }
    private val qrImages = arrayOfNulls<ImageView>(2)
    private val qrNotes = arrayOfNulls<TextView>(2)
    private var resultUri: Uri? = null
    private var sessionUris: List<Uri> = emptyList()
    private var resultLeft = 0
    private val resultTick = object : Runnable {
        override fun run() {
            if (resultPane.visibility != View.VISIBLE) return
            if (resultLeft <= 0) { dismissResult(); return }
            resultTimer.text = "Next guest in ${resultLeft}s"
            resultLeft--
            ui.postDelayed(this, 1000)
        }
    }

    // ---- photo booth state
    private var boothTpl: Template? = null
    private var slotUris: Array<Uri?> = arrayOfNulls(0)
    private var slotBmps: Array<Bitmap?> = arrayOfNulls(0)
    private var cur = 0
    private var awaiting = false
    private var autoPaused = false
    private val clearAwaiting = Runnable { awaiting = false; updateLiveMode() }
    private val nextRun = Runnable { startNext() }

    private val tabViews = HashMap<Int, TextView>()
    private var counting = false
    private var countLeft = 0
    private val tick = object : Runnable {
        override fun run() {
            if (!counting) return
            if (countLeft <= 0) {
                counting = false
                setCount(null)
                fire()
            } else {
                setCount(countLeft.toString())
                countLeft--
                ui.postDelayed(this, 1000)
            }
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            val size = act.resources.displayMetrics.widthPixels / grid.numColumns - Ui.dp(act, 4)
            iv.layoutParams = AbsListView.LayoutParams(size, size)
            loadThumb(iv, items[p])
            return iv
        }
    }

    init {
        buildStatus()
        buildGallery()
        buildSettings()
        buildLiveParts()
        if (!photobooth) buildInfo()
        buildTabs()
        templatePane.onChanged = { syncBooth(); refresh() }
        buildLive()
        syncBooth()
        show(T_STATUS)
        loadGallery()
    }

    // ================================================================== helpers

    private fun switchRow(text: String, sp: SharedPreferences, key: String, def: Boolean = false, onToggle: (() -> Unit)? = null): Switch = Switch(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(Ui.TEXT)
        isChecked = sp.getBoolean(key, def)
        setOnCheckedChangeListener { _, on -> sp.edit().putBoolean(key, on).apply(); onToggle?.invoke() }
    }

    private fun intChips(parent: LinearLayout, title: String, labels: List<String>, values: List<Int>, key: String, def: Int, after: (() -> Unit)? = null) {
        parent.addView(Ui.label(act, title, 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val list = ArrayList<TextView>()
        fun paint() {
            val c0 = prefs.getInt(key, def)
            for (c in list) c.background = Ui.shape(act, if ((c.tag as Int) == c0) Ui.ACCENT else Ui.CARD2, 14)
        }
        labels.forEachIndexed { i, l ->
            val c = Ui.pill(act, l, Ui.CARD2) { prefs.edit().putInt(key, values[i]).apply(); paint(); after?.invoke() }
            c.tag = values[i]
            c.textSize = 13f
            c.setPadding(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8))
            list.add(c)
            row.addView(c, Ui.lp(act, 0, -2, 1f, side = 2))
        }
        paint()
        parent.addView(row, Ui.lp(act, -1, -2, top = 4))
    }

    private fun textField(parent: LinearLayout, title: String, key: String, def: String, hint: String, onSave: (() -> Unit)? = null) {
        parent.addView(Ui.label(act, title, 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = Ui.input(act, prefs.getString(key, def) ?: def, hint)
        row.addView(et, Ui.lp(act, 0, -2, 1f))
        row.addView(Ui.pill(act, "Save", Ui.ACCENT) {
            prefs.edit().putString(key, et.text.toString().trim()).apply()
            onSave?.invoke()
            refresh()
        }, Ui.lp(act, -2, -2, side = 8))
        parent.addView(row, Ui.lp(act, -1, -2, top = 4))
    }

    private fun isLandscape() = act.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
    private fun icon(glyph: String, bg: Int = 0x99000000.toInt(), fg: Int = Color.WHITE, sp: Float = 18f, onClick: () -> Unit) =
        Ui.icon(act, glyph, bg, fg, sp, onClick)

    private fun folder() = CanonSyncService.folderOf(prefs)
    private fun tplFolder() = CanonSyncService.tplFolderOf(prefs)

    // ================================================================== build UI

    private fun buildStatus() {
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(act).apply { setImageResource(R.drawable.logo) }, Ui.lp(act, Ui.dp(act, 60), Ui.dp(act, 60)))
        val t = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.label(act, if (photobooth) "Android Photobooth" else "Canon Auto Copy", 22f, Ui.TEXT, true))
        t.addView(Ui.label(act, if (photobooth) "Canon EOS live booth, templates, print & cloud" else "EOS 760D  -  real-time USB transfer", 13f, Ui.MUTED))
        head.addView(t, Ui.lp(act, 0, -2, 1f, side = 12))
        statusCol.addView(head, Ui.lp(act, -1, -2, bottom = 12))

        val st = Ui.card(act)
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(statusDot, Ui.lp(act, Ui.dp(act, 12), Ui.dp(act, 12)))
        row.addView(statusText, Ui.lp(act, 0, -2, 1f, side = 10))
        st.addView(row)
        st.addView(statsText, Ui.lp(act, -2, -2, top = 6))
        if (photobooth) st.addView(cloudText, Ui.lp(act, -2, -2, top = 4))
        st.addView(Ui.pill(act, "Connect camera now", Ui.ACCENT) { connect(null) }, Ui.lp(act, -1, -2, top = 12))
        st.addView(Ui.pill(act, "Open Live View", Ui.CARD2) { show(T_LIVE) }, Ui.lp(act, -1, -2, top = 8))
        statusCol.addView(st, Ui.lp(act, -1, -2, bottom = 12))

        val help = Ui.card(act)
        help.addView(Ui.label(act, "How to use", 16f, Ui.TEXT, true))
        help.addView(Ui.label(act,
            "1. Switch the camera ON (menu: Auto power off = Disable).\n" +
            "2. Plug the USB cable, camera to phone (OTG adapter if needed).\n" +
            "3. Tap Allow / Always open with this app.\n" +
            "4. Take photos with the shutter, or open Live View and tap the screen.\n" +
            "5. Every photo is copied within seconds. Originals on the card are never deleted.\n" +
            "Timer, folders, printing, QR codes, external drive and more are in the Settings tab.",
            13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        statusCol.addView(help)
    }

    private fun buildSettings() {
        settingsCol.addView(Ui.label(act, "Settings", 22f, Ui.TEXT, true), Ui.lp(act, -2, -2, bottom = 10))

        val timer = Ui.card(act)
        timer.addView(Ui.label(act, "Countdown timer", 16f, Ui.TEXT, true))
        intChips(timer, "Seconds before the photo is taken", listOf("Off", "3s", "5s", "10s", "15s"), listOf(0, 3, 5, 10, 15), "timer", 0) { refresh() }
        timer.addView(switchRow("Template: start the next countdown automatically", prefs, "auto_next", true), Ui.lp(act, -1, -2, top = 10))
        intChips(timer, "Wait before the next countdown starts", listOf("0s", "2s", "5s", "10s"), listOf(0, 2, 5, 10), "next_delay", 2)
        timer.addView(Ui.label(act, "In Live View tap the pause button to hold the automatic countdown for a while, tap it again to continue.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 6))
        settingsCol.addView(timer, Ui.lp(act, -1, -2, bottom = 12))

        val live = Ui.card(act)
        live.addView(Ui.label(act, "Live view", 16f, Ui.TEXT, true))
        live.addView(switchRow("Full screen (hide status and navigation bars)", prefs, "live_full", true) { if (tab == T_LIVE) applyFullscreen(prefs.getBoolean("live_full", true)); refresh() }, Ui.lp(act, -1, -2, top = 10))
        live.addView(switchRow("Fill the screen (crops the edges)", prefs, "live_fill", true) { refresh() }, Ui.lp(act, -1, -2, top = 8))
        settingsCol.addView(live, Ui.lp(act, -1, -2, bottom = 12))

        val booth = Ui.card(act)
        booth.addView(Ui.label(act, "Template & printing", 16f, Ui.TEXT, true))
        booth.addView(switchRow("Use the template for photos (photo booth)", prefs, "tpl_use") { syncBooth(); refresh() }, Ui.lp(act, -1, -2, top = 10))
        booth.addView(switchRow("Show the template on the live view", prefs, "tpl_show", true) { updateLiveMode(); refresh() }, Ui.lp(act, -1, -2, top = 8))
        booth.addView(switchRow("Show the template first, camera view only during the countdown", prefs, "tpl_first") { updateLiveMode(); refresh() }, Ui.lp(act, -1, -2, top = 8))
        booth.addView(Ui.label(act, "If the template is hidden you see only the camera, but every photo still goes into the template.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
        booth.addView(switchRow("Print automatically when I tap Finish", prefs, "auto_print"), Ui.lp(act, -1, -2, top = 12))
        booth.addView(switchRow("Start a new session after the preview", prefs, "auto_reset", true), Ui.lp(act, -1, -2, top = 8))
        intChips(booth, "Show the finished picture for", listOf("3s", "5s", "8s", "15s"), listOf(3, 5, 8, 15), "preview_secs", 5)
        booth.addView(Ui.label(act, "Printer", 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 12))
        booth.addView(printerText, Ui.lp(act, -2, -2, top = 2))
        val prow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        prow.addView(Ui.pill(act, "Select printer", Ui.ACCENT) { Printing.selectPrinter(act, prefs) { refresh() } }, Ui.lp(act, 0, -2, 1f, side = 3))
        prow.addView(Ui.pill(act, "Print settings", Ui.CARD2) { Printing.settings(act, prefs) }, Ui.lp(act, 0, -2, 1f, side = 3))
        booth.addView(prow, Ui.lp(act, -1, -2, top = 6))
        settingsCol.addView(booth, Ui.lp(act, -1, -2, bottom = 12))

        val qr = Ui.card(act)
        qr.addView(Ui.label(act, "QR codes & sharing", 16f, Ui.TEXT, true))
        qr.addView(Ui.label(act, "Shown on the finished-picture screen, also while it prints. The client scans them to open or download the picture.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        qr.addView(switchRow("Show Facebook QR / link", prefs, "qr_fb"), Ui.lp(act, -1, -2, top = 10))
        qr.addView(switchRow("Show Google Drive download QR / link", prefs, "qr_drive"), Ui.lp(act, -1, -2, top = 8))
        textField(qr, "Fixed Facebook link (your Page or album, used when no photo link is available)", "qr_fb_link", "", "https://facebook.com/yourpage")
        textField(qr, "Fixed Google Drive link (shared folder, optional)", "qr_drive_link", "", "https://drive.google.com/...")
        intChips(qr, "Keep the screen open while a QR code shows", listOf("10s", "20s", "30s", "60s"), listOf(10, 20, 30, 60), "qr_secs", 20)
        qr.addView(Ui.label(act, "The finished-picture screen also has Messenger and Share buttons.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        settingsCol.addView(qr, Ui.lp(act, -1, -2, bottom = 12))

        val cam = Ui.card(act)
        cam.addView(Ui.label(act, "Folders", 16f, Ui.TEXT, true))
        textField(cam, "Camera pictures (originals) folder", "folder", "Canon760D", "Canon760D") { prefs.edit().putString("folder", folder()).apply(); loadGallery() }
        textField(cam, "Template pictures folder", "tpl_folder", "Photobooth", "Photobooth") { prefs.edit().putString("tpl_folder", tplFolder()).apply(); loadGallery() }
        cam.addView(Ui.label(act, "Saved in Pictures/<name>. Letters, numbers, space, - _ . only.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
        cam.addView(switchRow("Also copy photos already on the card", prefs, "import_existing"), Ui.lp(act, -1, -2, top = 12))
        settingsCol.addView(cam, Ui.lp(act, -1, -2, bottom = 12))

        val ext = Ui.card(act)
        ext.addView(Ui.label(act, "Copy for the client (flash drive, hard drive, memory card)", 16f, Ui.TEXT, true))
        ext.addView(Ui.label(act, "Plug the drive into the phone (a USB hub is needed to use it together with the camera), then choose a folder on it.", 12f, Ui.MUTED), Ui.lp(act, -2, -2, top = 2))
        ext.addView(extText, Ui.lp(act, -2, -2, top = 6))
        val erow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        erow.addView(Ui.pill(act, "Choose drive / folder", Ui.ACCENT) { pickExternal() }, Ui.lp(act, 0, -2, 1f, side = 3))
        erow.addView(Ui.pill(act, "Copy gallery now", Ui.CARD2) { copyGalleryToDrive() }, Ui.lp(act, 0, -2, 1f, side = 3))
        ext.addView(erow, Ui.lp(act, -1, -2, top = 8))
        ext.addView(switchRow("Copy every camera photo to the drive as it is taken", prefs, "ext_auto"), Ui.lp(act, -1, -2, top = 10))
        ext.addView(switchRow("Copy each finished session (picture + its photos) into its own folder", prefs, "ext_session"), Ui.lp(act, -1, -2, top = 8))
        settingsCol.addView(ext, Ui.lp(act, -1, -2, bottom = 12))

        if (cloud != null) {
            settingsCol.addView(cloud.facebookCard(true), Ui.lp(act, -1, -2, bottom = 12))
            settingsCol.addView(cloud.webhookCard(true), Ui.lp(act, -1, -2, bottom = 12))
            settingsCol.addView(cloud.driveCard())
        }
    }

    private fun buildGallery() {
        grid.numColumns = if (isLandscape()) 5 else 3
        grid.horizontalSpacing = Ui.dp(act, 3)
        grid.verticalSpacing = Ui.dp(act, 3)
        grid.setPadding(Ui.dp(act, 4), 0, Ui.dp(act, 4), Ui.dp(act, 8))
        grid.clipToPadding = false
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> PhotoViewer(act, items, pos, pool).show() }
        val chips = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Originals", "Templated").forEachIndexed { i, n ->
            val c = Ui.pill(act, n, Ui.CARD2) { prefs.edit().putInt("gal_mode", i).apply(); paintGal(); loadGallery() }
            c.textSize = 13f
            galChips.add(c)
            chips.addView(c, Ui.lp(act, 0, -2, 1f, side = 3))
        }
        galleryPane.addView(chips, Ui.lp(act, -1, -2, top = 4, side = 12))
        galleryPane.addView(galleryCount, Ui.lp(act, -2, -2, top = 6, bottom = 6, side = 16))
        galleryPane.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        paintGal()
    }

    private fun paintGal() {
        val m = prefs.getInt("gal_mode", 0)
        galChips.forEachIndexed { i, c -> c.background = Ui.shape(act, if (i == m) Ui.ACCENT else Ui.CARD2, 14) }
    }

    private fun buildLiveParts() {
        livePane.addView(liveImage, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(boothView, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(livePlaceholder, FrameLayout.LayoutParams(-1, -1))
        liveImage.setOnClickListener { capture() }
        boothView.onSlotClick = { i -> onSlotTap(i) }

        val s = Ui.dp(act, 42)
        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        backBtn = icon("\u2190") { leaveLive() }
        timerBtn = icon("\u23F1", sp = 14f) { cycleTimer() }
        pauseBtn = icon("\u23F8") { togglePause() }
        templateBtn = icon("\uD83D\uDDBC") { prefs.edit().putBoolean("tpl_show", !prefs.getBoolean("tpl_show", true)).apply(); updateLiveMode(); refresh() }
        fullBtn = icon("\u26F6") { prefs.edit().putBoolean("live_full", !prefs.getBoolean("live_full", true)).apply(); applyFullscreen(prefs.getBoolean("live_full", true)); refresh() }
        fillBtn = icon("\u2922") { prefs.edit().putBoolean("live_fill", !prefs.getBoolean("live_fill", true)).apply(); refresh() }
        top.addView(backBtn, Ui.lp(act, s, s, side = 3))
        top.addView(timerBtn, Ui.lp(act, Ui.dp(act, 62), s, side = 3))
        top.addView(pauseBtn, Ui.lp(act, s, s, side = 3))
        top.addView(templateBtn, Ui.lp(act, s, s, side = 3))
        top.addView(fullBtn, Ui.lp(act, s, s, side = 3))
        top.addView(fillBtn, Ui.lp(act, s, s, side = 3))
        top.addView(View(act), Ui.lp(act, 0, 1, 1f))
        top.addView(liveBadge, Ui.lp(act, -2, -2, side = 6))
        livePane.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), 0) })
        livePane.addView(liveInfo, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = Ui.dp(act, 58) })
        livePane.addView(countdownView, FrameLayout.LayoutParams(-1, -1))

        liveBtn = icon("\u25B6", 0x66FFFFFF, Color.WHITE, 18f) { toggleLive() }
        shootBtn = icon("\uD83D\uDCF7", Color.WHITE, Color.BLACK, 26f) { capture() }
        addBtn = icon("\uFF0B", 0x66FFFFFF, Color.WHITE, 18f) { addPhotoToBooth() }
        finishBtn = icon("\u2714", Ui.ACCENT, Color.WHITE, 18f) { finishBooth() }
        restartBtn = icon("\u21BA", 0x66FFFFFF, Color.WHITE, 18f) { restartBooth() }

        // finished-picture preview
        resultPane.addView(resultImage, FrameLayout.LayoutParams(-1, -1))
        resultImage.setOnClickListener { dismissResult() }
        resultPane.addView(resultTimer, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(Ui.dp(act, 12), Ui.dp(act, 16), 0, 0) })
        resultPane.addView(icon("\u2715") { dismissResult() }, FrameLayout.LayoutParams(s, s, Gravity.TOP or Gravity.END).apply { setMargins(0, Ui.dp(act, 12), Ui.dp(act, 12), 0) })
        val side = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        for ((g, act2) in listOf<Pair<String, () -> Unit>>(
            "\uD83D\uDCAC" to { sharePicture(true) },
            "\u2197" to { sharePicture(false) },
            "\uD83D\uDCBE" to { copySessionToDrive() },
            "\uD83D\uDDA8" to { printResult() }
        )) side.addView(icon(g) { act2() }, Ui.lp(act, s, s, top = 4, bottom = 4))
        resultPane.addView(side, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = Ui.dp(act, 12) })
        for (k in 0..1) {
            val card = LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = Ui.shape(act, Color.WHITE, 14)
                setPadding(Ui.dp(act, 8), Ui.dp(act, 8), Ui.dp(act, 8), Ui.dp(act, 6))
                visibility = View.GONE
            }
            val iv = ImageView(act)
            val note = Ui.label(act, if (k == 0) "Facebook" else "Google Drive", 11f, Color.BLACK, true).apply { gravity = Gravity.CENTER }
            card.addView(iv, Ui.lp(act, Ui.dp(act, 120), Ui.dp(act, 120)))
            card.addView(note, Ui.lp(act, -2, -2, top = 2))
            qrImages[k] = iv
            qrNotes[k] = note
            card.tag = "qr$k"
            qrBox.addView(card, Ui.lp(act, -2, -2, side = 8))
        }
        resultPane.addView(qrBox, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = Ui.dp(act, 70) })
        resultPane.addView(resultInfo, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(Ui.dp(act, 12), 0, Ui.dp(act, 64), Ui.dp(act, 16)) })
    }

    private fun stat(title: String): LinearLayout {
        val b = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        b.addView(Ui.label(act, title, 10f, Ui.MUTED))
        val v = Ui.label(act, "-", 16f, Color.WHITE, true)
        infoStats[title] = v
        b.addView(v)
        return b
    }

    /** Canon Auto Copy only: live view with the camera's settings shown as read-only data. */
    private fun buildInfo() {
        infoPane.addView(infoImage, FrameLayout.LayoutParams(-1, -1))
        infoPane.addView(infoPlaceholder, FrameLayout.LayoutParams(-1, -1))
        infoImage.setOnClickListener { capture() }
        val s = Ui.dp(act, 42)
        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(icon("\u2190") { show(if (prevTab == T_INFO) T_STATUS else prevTab) }, Ui.lp(act, s, s, side = 3))
        infoTimerBtn = icon("\u23F1", sp = 14f) { cycleTimer() }
        top.addView(infoTimerBtn, Ui.lp(act, Ui.dp(act, 62), s, side = 3))
        top.addView(View(act), Ui.lp(act, 0, 1, 1f))
        top.addView(infoBadge, Ui.lp(act, -2, -2, side = 6))
        infoPane.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), 0) })

        val hud = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.shape(act, 0x99000000.toInt(), 16)
            setPadding(Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6))
        }
        val r1 = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in listOf("MODE", "APERTURE", "SHUTTER", "ISO")) r1.addView(stat(n), Ui.lp(act, 0, -2, 1f))
        val r2 = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in listOf("WB", "EXPOSURE", "SHOTS LEFT")) r2.addView(stat(n), Ui.lp(act, 0, -2, 1f))
        hud.addView(r1)
        hud.addView(r2, Ui.lp(act, -1, -2, top = 6))
        infoPane.addView(hud, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(Ui.dp(act, 10), Ui.dp(act, 58), Ui.dp(act, 10), 0) })
        infoPane.addView(infoMsg, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = Ui.dp(act, 158) })
        infoPane.addView(infoCount, FrameLayout.LayoutParams(-1, -1))

        infoLiveBtn = icon("\u25B6", 0x66FFFFFF, Color.WHITE, 18f) { toggleLive() }
        val shoot = icon("\uD83D\uDCF7", Color.WHITE, Color.BLACK, 26f) { capture() }
        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(infoLiveBtn, Ui.lp(act, Ui.dp(act, 44), Ui.dp(act, 44), side = 6))
        bar.addView(shoot, Ui.lp(act, Ui.dp(act, 64), Ui.dp(act, 64), side = 6))
        infoPanel.addView(infoThumbs(), Ui.lp(act, -1, Ui.dp(act, 62)))
        infoPanel.addView(bar, Ui.lp(act, -1, -2, top = 2))
        infoPane.addView(infoPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(Ui.dp(act, 8), 0, Ui.dp(act, 8), Ui.dp(act, 8)) })
    }

    private fun infoThumbs(): View {
        val holder = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        infoThumbHolder = holder
        fillThumbs(holder, 56)
        return HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(holder) }
    }

    private fun fillThumbs(holder: LinearLayout, dpSize: Int) {
        holder.removeAllViews()
        val px = Ui.dp(act, dpSize)
        if (items.isEmpty()) holder.addView(Ui.label(act, "New photos appear here", 12f, Ui.MUTED), Ui.lp(act, -2, -2, side = 8, top = 8))
        for ((i, u) in items.take(40).withIndex()) {
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setOnClickListener { PhotoViewer(act, items, i, pool).show() }
            }
            loadThumb(iv, u)
            holder.addView(iv, Ui.lp(act, px, px, side = 3, top = 2, bottom = 2))
        }
    }

    private fun buildTabs() {
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.shape(act, Ui.CARD, 16)
            setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
        }
        val defs = ArrayList<Pair<String, Int>>()
        defs.add("Status" to T_STATUS)
        defs.add("Gallery" to T_GALLERY)
        defs.add("Live View" to T_LIVE)
        if (!photobooth) defs.add("Camera Info" to T_INFO)
        defs.add("Templates" to T_TEMPLATES)
        defs.add("Settings" to T_SETTINGS)
        for ((name, id) in defs) {
            val tv = Ui.pill(act, name, Color.TRANSPARENT, Ui.MUTED) { show(id) }
            tv.textSize = 13f
            tv.setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            tabViews[id] = tv
            bar.addView(tv, Ui.lp(act, -2, -2))
        }
        val barScroll = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(bar) }
        val content = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        content.addView(barScroll, Ui.lp(act, -1, -2, top = 8, bottom = 8, side = 12))
        val frame = FrameLayout(act)
        frame.addView(statusPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(galleryPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(templatePane.view, FrameLayout.LayoutParams(-1, -1))
        frame.addView(settingsPane, FrameLayout.LayoutParams(-1, -1))
        content.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        view.addView(content, FrameLayout.LayoutParams(-1, -1))
        view.addView(livePane, FrameLayout.LayoutParams(-1, -1))
        view.addView(infoPane, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(resultPane, FrameLayout.LayoutParams(-1, -1))
    }

    /** Portrait: small photo strip along the bottom. Landscape: strip down the right edge. Both float over the picture. */
    private fun buildLive() {
        val land = isLandscape()
        Ui.detach(panel)
        Ui.detach(controlsBar)
        Ui.detach(resultPane)
        panel.removeAllViews()
        controlsBar.removeAllViews()
        panel.orientation = LinearLayout.VERTICAL
        controlsBar.orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        val holder = LinearLayout(act).apply { orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
        fillThumbs(holder, 56)
        val scroller: View = if (land) ScrollView(act).apply { isVerticalScrollBarEnabled = false; addView(holder) }
        else HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(holder) }

        val b = Ui.dp(act, 44)
        val big = Ui.dp(act, 64)
        for (v in listOf(liveBtn, addBtn, finishBtn, restartBtn, shootBtn)) Ui.detach(v)
        controlsBar.addView(liveBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(shootBtn, Ui.lp(act, big, big, side = 4, top = 3, bottom = 3))
        controlsBar.addView(addBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(finishBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(restartBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))

        if (land) {
            panel.addView(scroller, Ui.lp(act, -1, 0, 1f))
            panel.addView(controlsBar, Ui.lp(act, -1, -2, top = 4))
            livePane.addView(panel, FrameLayout.LayoutParams(Ui.dp(act, 76), -1, Gravity.END).apply { setMargins(0, Ui.dp(act, 56), Ui.dp(act, 6), Ui.dp(act, 6)) })
        } else {
            panel.addView(scroller, Ui.lp(act, -1, Ui.dp(act, 62)))
            panel.addView(controlsBar, Ui.lp(act, -1, -2, top = 2))
            livePane.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(Ui.dp(act, 8), 0, Ui.dp(act, 8), Ui.dp(act, 8)) })
        }
        livePane.addView(resultPane, FrameLayout.LayoutParams(-1, -1))
    }

    // ================================================================== behaviour

    @Suppress("DEPRECATION")
    private fun applyFullscreen(on: Boolean) {
        val w = act.window
        // the window's decor view does not exist yet while the screen is still being built
        if (w.peekDecorView() == null) return
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val c = w.insetsController
                if (c != null) {
                    if (on) {
                        c.hide(WindowInsets.Type.systemBars())
                        c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    } else c.show(WindowInsets.Type.systemBars())
                }
            } else {
                w.decorView.systemUiVisibility = if (on)
                    View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                else 0
            }
            if (Build.VERSION.SDK_INT >= 28) {
                val a = w.attributes
                a.layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                w.attributes = a
            }
        } catch (_: Exception) {}
    }

    fun onConfigChanged() {
        grid.numColumns = if (isLandscape()) 5 else 3
        adapter.notifyDataSetChanged()
        buildLive()
    }

    fun onBack(): Boolean {
        if (resultPane.visibility == View.VISIBLE) { dismissResult(); return true }
        if (tab == T_LIVE || tab == T_INFO) { leaveLive(); return true }
        if (tab != T_STATUS) { show(T_STATUS); return true }
        return false
    }

    private fun leaveLive() { show(if (prevTab == T_LIVE || prevTab == T_INFO) T_STATUS else prevTab) }

    private fun show(id: Int) {
        if ((id == T_LIVE || id == T_INFO) && tab != T_LIVE && tab != T_INFO) prevTab = tab
        tab = id
        statusPane.visibility = if (id == T_STATUS) View.VISIBLE else View.GONE
        galleryPane.visibility = if (id == T_GALLERY) View.VISIBLE else View.GONE
        templatePane.view.visibility = if (id == T_TEMPLATES) View.VISIBLE else View.GONE
        settingsPane.visibility = if (id == T_SETTINGS) View.VISIBLE else View.GONE
        livePane.visibility = if (id == T_LIVE) View.VISIBLE else View.GONE
        infoPane.visibility = if (id == T_INFO) View.VISIBLE else View.GONE
        for ((k, tv) in tabViews) {
            tv.background = Ui.shape(act, if (k == id) Ui.ACCENT else Color.TRANSPARENT, 12)
            tv.setTextColor(if (k == id) Color.WHITE else Ui.MUTED)
        }
        applyFullscreen((id == T_LIVE && prefs.getBoolean("live_full", true)) || id == T_INFO)
        if (id != T_LIVE && id != T_INFO) { stopLive(); cancelCountdown(); cancelNext(); dismissResult(false) }
        if (id == T_LIVE) syncBooth()
        if (id == T_GALLERY) loadGallery()
        refresh()
    }

    private fun toggleLive() {
        if (!CanonSyncService.running) { say("Connect the camera first (cable + Allow)."); return }
        if (CanonSyncService.liveWanted) stopLive() else {
            CanonSyncService.liveWanted = true
            say("Starting live view (a few seconds)...")
        }
        refresh()
    }

    private fun say(s: String) { liveInfo.text = s; infoMsg.text = s }

    private fun stopLive() {
        CanonSyncService.liveWanted = false
        liveImage.setImageDrawable(null)
        infoImage.setImageDrawable(null)
        boothView.live = null
        boothView.invalidate()
    }

    private fun cycleTimer() {
        val opts = listOf(0, 3, 5, 10, 15)
        val n = opts[(opts.indexOf(prefs.getInt("timer", 0)) + 1) % opts.size]
        prefs.edit().putInt("timer", n).apply()
        refresh()
    }

    private fun setCount(s: String?) {
        countdownView.text = s ?: ""
        infoCount.text = s ?: ""
        val v = if (s == null) View.GONE else View.VISIBLE
        countdownView.visibility = v
        infoCount.visibility = v
        updateLiveMode()
    }

    private fun startCountdown(secs: Int) {
        cancelCountdown()
        counting = true
        countLeft = secs
        ui.post(tick)
        updateLiveMode()
    }

    private fun capture() {
        if (counting) { cancelCountdown(); say("Timer cancelled."); return }
        if (!CanonSyncService.running) { say("Connect the camera first (cable + Allow)."); return }
        if (tab == T_LIVE && boothTpl != null && cur < 0) {
            say("All windows are filled. Tap a photo to retake it, or tap \u2714.")
            return
        }
        cancelNext()
        val secs = prefs.getInt("timer", 0)
        if (secs <= 0) fire() else startCountdown(secs)
    }

    private fun fire() {
        CanonSyncService.shootRequested = true
        awaiting = true
        ui.removeCallbacks(clearAwaiting)
        ui.postDelayed(clearAwaiting, 12000)
        say("Taking photo...")
        updateLiveMode()
    }

    private fun cancelCountdown() {
        counting = false
        ui.removeCallbacks(tick)
        setCount(null)
    }

    // ---- automatic countdown for the next template photo
    private fun cancelNext() { ui.removeCallbacks(nextRun) }

    private fun scheduleNext() {
        cancelNext()
        if (boothTpl == null || cur < 0 || autoPaused || tab != T_LIVE || !prefs.getBoolean("auto_next", true)) return
        ui.postDelayed(nextRun, prefs.getInt("next_delay", 2) * 1000L)
    }

    private fun startNext() {
        if (boothTpl == null || cur < 0 || autoPaused || tab != T_LIVE || counting) return
        if (!CanonSyncService.running) return
        startCountdown(maxOf(prefs.getInt("timer", 0), 3))
    }

    private fun togglePause() {
        autoPaused = !autoPaused
        if (autoPaused) { cancelNext(); if (counting) cancelCountdown(); say("Automatic countdown paused.") }
        else { say("Automatic countdown resumed."); scheduleNext() }
        refresh()
    }

    /** Decides what the live screen shows: the camera, or the template with the camera inside the current window. */
    private fun updateLiveMode() {
        val t = boothTpl
        val first = prefs.getBoolean("tpl_first", false)
        val cameraNow = counting || awaiting
        val showTpl = t != null && prefs.getBoolean("tpl_show", true) &&
            !(first && cameraNow && CanonSyncService.liveWanted)
        boothView.visibility = if (showTpl) View.VISIBLE else View.GONE
        liveImage.visibility = if (showTpl) View.GONE else View.VISIBLE
    }

    private fun loadThumb(iv: ImageView, uri: Uri) {
        val key = uri.toString()
        iv.tag = key
        iv.setBackgroundColor(Ui.CARD2)
        val cached = cache.get(key)
        if (cached != null) { iv.setImageBitmap(cached); return }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val bm = act.contentResolver.loadThumbnail(uri, Size(512, 512), null)
                cache.put(key, bm)
                act.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
    }

    private fun loadGallery() {
        val mode = prefs.getInt("gal_mode", 0)
        val name = if (mode == 1) tplFolder() else folder()
        Thread {
            val list = ArrayList<Uri>()
            try {
                val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                act.contentResolver.query(
                    base, arrayOf(MediaStore.Images.Media._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("Pictures/$name/%"),
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && list.size < 400) list.add(ContentUris.withAppendedId(base, c.getLong(0)))
                }
            } catch (_: Exception) {}
            act.runOnUiThread {
                items = list
                adapter.notifyDataSetChanged()
                galleryCount.text = "${list.size} picture(s) in Pictures/$name  -  tap to enlarge"
                buildLive()
                infoThumbHolder?.let { fillThumbs(it, 56) }
            }
        }.start()
    }

    // ================================================================== photo booth

    private fun boothOn() = prefs.getBoolean("tpl_use", false) && templatePane.active() != null

    private fun syncBooth() {
        val t = if (boothOn()) templatePane.active() else null
        if (t == null) {
            boothTpl = null
            updateLiveMode()
            return
        }
        if (boothTpl?.id != t.id) {
            boothTpl = t
            resetSlots(t)
            boothView.overlay = null
            if (t.hasOverlay) pool.execute {
                try {
                    val o = BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(t.wPx, t.hPx) / 1600) }
                    val bm = BitmapFactory.decodeFile(TemplateStore.overlayFile(act, t.id).path, o)
                    act.runOnUiThread { boothView.overlay = bm; boothView.invalidate() }
                } catch (_: Exception) {}
            }
        }
        boothView.template = t
        pushBooth()
        updateLiveMode()
    }

    private fun resetSlots(t: Template) {
        slotUris = arrayOfNulls(t.slots.size)
        slotBmps = arrayOfNulls(t.slots.size)
        cur = 0
        autoPaused = false
        cancelNext()
        pushBooth()
    }

    private fun pushBooth() {
        boothView.bitmaps = slotBmps
        boothView.current = cur
        boothView.invalidate()
    }

    private fun nextEmpty(from: Int): Int {
        val n = slotUris.size
        for (k in 0 until n) { val i = (from + k) % n; if (slotUris[i] == null) return i }
        return -1
    }

    private fun fillSlot(i: Int, uri: Uri) {
        if (i !in slotUris.indices) return
        val uris = slotUris
        val bmps = slotBmps
        uris[i] = uri
        cur = nextEmpty(i + 1)
        pushBooth()
        val total = slotUris.size
        say(if (cur < 0) "All $total photos taken. Tap \u2714 to finish, or tap a photo to change it." else "Photo ${i + 1} of $total saved. Next: window ${cur + 1}")
        pool.execute {
            val bm = try { TemplateTools.decodeCover(act, uri, 900, 900) } catch (_: Exception) { null }
            act.runOnUiThread { bmps[i] = bm; boothView.invalidate() }
        }
        scheduleNext()
    }

    private fun onNewPhoto(u: Uri) {
        awaiting = false
        ui.removeCallbacks(clearAwaiting)
        updateLiveMode()
        if (boothTpl == null || cur < 0) return
        fillSlot(cur, u)
    }

    private fun onSlotTap(i: Int) {
        if (i < 0) { capture(); return }
        if (slotUris.getOrNull(i) != null) { slotMenu(i); return }
        cur = i
        pushBooth()
        capture()
    }

    private fun darkDialog() = AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)

    private fun slotMenu(i: Int) {
        cancelNext()
        darkDialog().setTitle("Photo ${i + 1}")
            .setItems(arrayOf("Retake with camera", "Replace from transferred photos", "Remove photo")) { _, which ->
                when (which) {
                    0 -> { slotUris[i] = null; slotBmps[i] = null; cur = i; pushBooth(); say("Tap the screen to retake photo ${i + 1}.") }
                    1 -> pickTransferred { u -> slotUris[i] = null; slotBmps[i] = null; fillSlot(i, u) }
                    else -> { slotUris[i] = null; slotBmps[i] = null; if (cur < 0) cur = i; pushBooth() }
                }
            }.show()
    }

    private fun addPhotoToBooth() {
        if (boothTpl == null) { say("Turn on \"Use the template for photos\" in Settings first."); return }
        if (cur < 0) { say("All windows are filled. Tap a photo to replace it."); return }
        cancelNext()
        pickTransferred { u -> fillSlot(cur.coerceAtLeast(0), u) }
    }

    private fun restartBooth() {
        val t = boothTpl ?: return
        resetSlots(t)
        say("New session. Tap the screen to take photo 1.")
    }

    /** Pick one of the photos already transferred from the camera. */
    private fun pickTransferred(onPick: (Uri) -> Unit) {
        val d = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        box.addView(Ui.label(act, "Choose a photo", 18f, Ui.TEXT, true), Ui.lp(act, -2, -2, top = 28, bottom = 8, side = 16))
        val g = GridView(act).apply { numColumns = 3; horizontalSpacing = Ui.dp(act, 3); verticalSpacing = Ui.dp(act, 3) }
        g.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val iv = (cv as? ImageView) ?: ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                val size = act.resources.displayMetrics.widthPixels / 3 - Ui.dp(act, 3)
                iv.layoutParams = AbsListView.LayoutParams(size, size)
                loadThumb(iv, items[p])
                return iv
            }
        }
        g.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onPick(items[pos]) }
        box.addView(g, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(Ui.pill(act, "Cancel", Ui.CARD2) { d.dismiss() }, Ui.lp(act, -1, -2, top = 6, bottom = 10, side = 12))
        d.setContentView(box)
        d.show()
    }

    private fun finishBooth() {
        val t = boothTpl ?: run { say("Turn on \"Use the template for photos\" in Settings first."); return }
        if (slotUris.all { it == null }) { say("Take at least one photo first."); return }
        cancelNext()
        cancelCountdown()
        say("Creating your photo...")
        val uris = slotUris.toList()
        val folder = tplFolder()
        Thread {
            try {
                val bmp = TemplateTools.compose(act, t, uris)
                val uri = saveBooth(bmp, folder)
                bmp.recycle()
                act.runOnUiThread { boothDone(uri, t, uris.filterNotNull()) }
            } catch (e: Exception) {
                act.runOnUiThread { say("Could not create the photo: ${e.message}") }
            }
        }.start()
    }

    private fun saveBooth(bmp: Bitmap, folder: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Booth_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/$folder")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = act.contentResolver.insert(coll, v) ?: throw IllegalStateException("Cannot create file")
        val out = act.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot write file")
        out.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        act.contentResolver.update(uri, done, null, null)
        return uri
    }

    /** Show the finished picture, print it, show the QR codes, queue the uploads, copy to the external drive. */
    private fun boothDone(uri: Uri, t: Template, originals: List<Uri>) {
        loadGallery()
        resultUri = uri
        sessionUris = originals
        resultImage.setImageDrawable(null)
        resultInfo.text = "Saved in Pictures/${tplFolder()}"
        resultPane.visibility = View.VISIBLE
        pool.execute {
            try {
                val bm = TemplateTools.decodeFit(act, uri, 2048, false)
                act.runOnUiThread { resultImage.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
        if (prefs.getBoolean("auto_print", false)) printPicture(uri)

        // QR codes
        for (k in 0..1) { qrBox.getChildAt(k).visibility = View.GONE }
        qrBox.visibility = View.GONE
        resultLeft = prefs.getInt("preview_secs", 5)
        val staticFb = prefs.getString("qr_fb_link", "") ?: ""
        val staticDr = prefs.getString("qr_drive_link", "") ?: ""
        if (prefs.getBoolean("qr_fb", false) && staticFb.startsWith("http")) setQr(0, staticFb)
        if (prefs.getBoolean("qr_drive", false) && staticDr.startsWith("http")) setQr(1, staticDr)

        // cloud
        if (photobooth) {
            val cp = Cloud.prefs(act)
            val name = Cloud.nameOf(act, uri)
            if (cp.getBoolean("fb_auto", false)) CloudQueue.add(act, "fb", uri, name, true)
            if (cp.getBoolean("hook_auto", false)) CloudQueue.add(act, "hook", uri, name, true)
            val driveOn = (cp.getString("drive_refresh", "") ?: "").isNotEmpty()
            if (driveOn && (cp.getBoolean("drive_final", false) || prefs.getBoolean("qr_drive", false))) CloudQueue.add(act, "drivepub", uri, name, true)
            Uploader.kick(act)
        }
        // external drive
        if (prefs.getBoolean("ext_session", false) && ExternalCopy.tree(prefs) != null) copySessionToDrive()

        ui.removeCallbacks(resultTick)
        ui.post(resultTick)
    }

    private fun setQr(slot: Int, link: String) {
        val iv = qrImages[slot] ?: return
        pool.execute {
            try {
                val bm = Qr.make(link, 400)
                act.runOnUiThread {
                    iv.setImageBitmap(bm)
                    (qrBox.getChildAt(slot) as View).visibility = View.VISIBLE
                    qrBox.visibility = View.VISIBLE
                    resultLeft = maxOf(resultLeft, prefs.getInt("qr_secs", 20))
                    if (resultPane.visibility == View.VISIBLE) { ui.removeCallbacks(resultTick); ui.post(resultTick) }
                }
            } catch (_: Exception) {}
        }
    }

    private fun onLink(kind: String, uriStr: String, link: String) {
        if (uriStr != resultUri?.toString() || resultPane.visibility != View.VISIBLE) return
        if (kind == "fb" && prefs.getBoolean("qr_fb", false)) setQr(0, link)
        if (kind == "drivepub" && prefs.getBoolean("qr_drive", false)) setQr(1, link)
    }

    private fun printResult() { resultUri?.let { printPicture(it) } }

    private fun printPicture(uri: Uri) {
        val t = boothTpl
        Printing.print(act, prefs, uri, t == null || t.hPx >= t.wPx) { s -> resultInfo.text = s; say(s) }
    }

    private fun sharePicture(messenger: Boolean) {
        val u = resultUri ?: return
        resultLeft = maxOf(resultLeft, 120)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "image/jpeg"
            putExtra(Intent.EXTRA_STREAM, u)
            clipData = ClipData.newUri(act.contentResolver, "picture", u)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            if (messenger) act.startActivity(Intent(i).setPackage("com.facebook.orca"))
            else act.startActivity(Intent.createChooser(i, "Share picture"))
        } catch (e: ActivityNotFoundException) {
            try { act.startActivity(Intent.createChooser(i, "Share picture")) } catch (_: Exception) { resultInfo.text = "Cannot share: no app found" }
        }
    }

    private fun dismissResult(reset: Boolean = true) {
        ui.removeCallbacks(resultTick)
        val wasShown = resultPane.visibility == View.VISIBLE
        resultPane.visibility = View.GONE
        resultImage.setImageDrawable(null)
        if (wasShown && reset && prefs.getBoolean("auto_reset", true)) boothTpl?.let { resetSlots(it) }
    }

    // ================================================================== external drive

    private fun pickExternal() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        act.startActivityForResult(i, REQ_EXT)
    }

    private fun mimeFor(u: Uri) = Cloud.mimeOf(act, u, Cloud.nameOf(act, u))

    private fun copySessionToDrive() {
        val u = resultUri ?: return
        if (ExternalCopy.tree(prefs) == null) { resultInfo.text = "Choose a drive in Settings first."; return }
        val originals = sessionUris
        resultLeft = maxOf(resultLeft, 20)
        resultInfo.text = "Copying to the drive ..."
        Thread {
            val dir = if (prefs.getBoolean("ext_sub", true)) ExternalCopy.newFolder(act, prefs) else null
            var ok = ExternalCopy.copy(act, prefs, u, Cloud.nameOf(act, u), "image/jpeg", dir)
            for (o in originals) ok = ExternalCopy.copy(act, prefs, o, Cloud.nameOf(act, o), mimeFor(o), dir) && ok
            act.runOnUiThread { resultInfo.text = if (ok) "Copied to the drive" else "Could not copy to the drive. Is it plugged in?" }
        }.start()
    }

    private fun copyGalleryToDrive() {
        if (ExternalCopy.tree(prefs) == null) { extText.text = "Choose a drive first."; return }
        val list = items
        extText.text = "Copying ${list.size} picture(s) ..."
        Thread {
            val dir = if (prefs.getBoolean("ext_sub", true)) ExternalCopy.newFolder(act, prefs) else null
            var n = 0
            for (u in list) if (ExternalCopy.copy(act, prefs, u, Cloud.nameOf(act, u), mimeFor(u), dir)) n++
            act.runOnUiThread { extText.text = "Copied $n of ${list.size} picture(s) to ${ExternalCopy.label(prefs)}" }
        }.start()
    }

    // ================================================================== lifecycle / USB

    fun onActivityResult(req: Int, res: Int, data: Intent?): Boolean {
        if (req == REQ_EXT) {
            val u = data?.data
            if (res == Activity.RESULT_OK && u != null) {
                try {
                    act.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                } catch (_: Exception) {}
                prefs.edit().putString("ext_tree", u.toString()).apply()
                refresh()
            }
            return true
        }
        return templatePane.onActivityResult(req, res, data)
    }

    fun onCreate(intent: Intent?) {
        registerPermissionReceiver()
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        CanonSyncService.onChange = { act.runOnUiThread { refresh() } }
        CanonSyncService.onProps = { act.runOnUiThread { refreshInfo() } }
        CanonSyncService.onFrame = { bm ->
            act.runOnUiThread {
                if (CanonSyncService.liveWanted) {
                    if (tab == T_INFO) infoImage.setImageBitmap(bm) else liveImage.setImageBitmap(bm)
                    if (boothTpl != null) { boothView.live = bm; boothView.invalidate() }
                    livePlaceholder.visibility = View.GONE
                    infoPlaceholder.visibility = View.GONE
                }
            }
        }
        if (photobooth) {
            Uploader.onChange = { act.runOnUiThread { refresh() } }
            Uploader.onLink = { kind, u, link -> act.runOnUiThread { onLink(kind, u, link) } }
        }
        handleIntent(intent)
        refresh()
        refreshInfo()
    }

    fun onNewIntent(intent: Intent?) = handleIntent(intent)

    fun onDestroy() {
        cancelCountdown()
        cancelNext()
        ui.removeCallbacks(resultTick)
        applyFullscreen(false)
        receiver?.let { try { act.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        CanonSyncService.onChange = null
        CanonSyncService.onProps = null
        CanonSyncService.onFrame = null
        CanonSyncService.liveWanted = false
        Uploader.onChange = null
        Uploader.onLink = null
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect(CanonControl.deviceFrom(i))
    }

    fun connect(d: UsbDevice?) {
        val dev = d ?: CanonControl.findCamera(act)
        if (dev == null) {
            CanonSyncService.post("No camera found. Plug it in and switch it ON.")
            return
        }
        if (usb.hasPermission(dev)) {
            CanonControl.start(act, dev)
        } else {
            val pi = PendingIntent.getBroadcast(
                act, 0,
                Intent(CanonControl.ACTION_PERMISSION).setPackage(act.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usb.requestPermission(dev, pi)
        }
    }

    private fun registerPermissionReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val dev = CanonControl.deviceFrom(i)
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                    CanonControl.start(act, dev)
                } else {
                    CanonSyncService.post("USB permission not allowed. Tap Connect and choose Allow.")
                }
            }
        }
        receiver = r
        val f = IntentFilter(CanonControl.ACTION_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else act.registerReceiver(r, f)
    }

    private fun refreshInfo() {
        if (photobooth) return
        val p = CanonSyncService.props
        infoStats["MODE"]?.text = CamInfo.mode(p[CamInfo.MODE])
        infoStats["APERTURE"]?.text = CamInfo.aperture(p[CamInfo.APERTURE])
        infoStats["SHUTTER"]?.text = CamInfo.shutter(p[CamInfo.SHUTTER])
        infoStats["ISO"]?.text = CamInfo.iso(p[CamInfo.ISO])
        infoStats["WB"]?.text = CamInfo.wb(p[CamInfo.WB])
        infoStats["EXPOSURE"]?.text = CamInfo.ev(p[CamInfo.EV])
        infoStats["SHOTS LEFT"]?.text = CamInfo.shots(p[CamInfo.SHOTS])
    }

    fun refresh() {
        val s = CanonSyncService.status
        statusText.text = s
        val bad = s.startsWith("Error") || s.startsWith("Lost") || s.startsWith("Failed") ||
            s.startsWith("Cannot") || s.contains("not allowed") || s.startsWith("Camera could not")
        statusDot.background = Ui.shape(act, when {
            bad -> Ui.RED
            CanonSyncService.running -> Ui.GREEN
            else -> Ui.MUTED
        }, 0, true)
        statsText.text = "Copied this session: ${CanonSyncService.copied}   |   Folder: Pictures/${folder()}"
        if (photobooth) cloudText.text = "Cloud: ${CloudQueue.size(act)} waiting  |  ${Uploader.done} uploaded  |  ${Uploader.failed} failed" +
            (if (Uploader.status.isNotEmpty()) "\n${Uploader.status}" else "")
        printerText.text = Printing.label(prefs)
        extText.text = "Drive folder: " + ExternalCopy.label(prefs)
        if ((tab == T_LIVE || tab == T_INFO) && !counting && !s.startsWith("Copying") && !s.startsWith("Saved") && resultPane.visibility != View.VISIBLE) say(s)

        val live = CanonSyncService.liveWanted
        for (b in listOf(liveBtn) + (if (photobooth) emptyList() else listOf(infoLiveBtn))) {
            b.text = if (live) "\u25A0" else "\u25B6"
            b.background = Ui.shape(act, if (live) Ui.RED else 0x66FFFFFF, 0, true)
        }
        liveBadge.visibility = if (live) View.VISIBLE else View.GONE
        infoBadge.visibility = if (live) View.VISIBLE else View.GONE
        if (!live) {
            livePlaceholder.visibility = if (boothTpl != null && prefs.getBoolean("tpl_show", true)) View.GONE else View.VISIBLE
            infoPlaceholder.visibility = View.VISIBLE
        }
        val secs = prefs.getInt("timer", 0)
        val tt = if (secs > 0) "\u23F1 ${secs}s" else "\u23F1 off"
        val tbg = Ui.shape(act, if (secs > 0) Ui.ACCENT else 0x99000000.toInt(), 22)
        timerBtn.text = tt
        timerBtn.background = tbg
        if (!photobooth) { infoTimerBtn.text = tt; infoTimerBtn.background = Ui.shape(act, if (secs > 0) Ui.ACCENT else 0x99000000.toInt(), 22) }
        val booth = boothTpl != null
        templateBtn.visibility = if (booth) View.VISIBLE else View.GONE
        pauseBtn.visibility = if (booth) View.VISIBLE else View.GONE
        pauseBtn.text = if (autoPaused) "\u25B7" else "\u23F8"
        pauseBtn.background = Ui.shape(act, if (autoPaused) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        templateBtn.background = Ui.shape(act, if (prefs.getBoolean("tpl_show", true)) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        addBtn.visibility = if (booth) View.VISIBLE else View.GONE
        finishBtn.visibility = if (booth) View.VISIBLE else View.GONE
        restartBtn.visibility = if (booth) View.VISIBLE else View.GONE
        val full = prefs.getBoolean("live_full", true)
        fullBtn.background = Ui.shape(act, if (full) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        val fill = prefs.getBoolean("live_fill", true)
        fillBtn.background = Ui.shape(act, if (fill) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        liveImage.scaleType = if (fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER

        val seq = CanonSyncService.lastSavedSeq
        if (seq != lastSeq) {
            lastSeq = seq
            CanonSyncService.lastSavedUri?.let { onNewPhoto(it) }
        }
        if (CanonSyncService.copied != lastCopied) {
            lastCopied = CanonSyncService.copied
            loadGallery()
        }
    }
}
