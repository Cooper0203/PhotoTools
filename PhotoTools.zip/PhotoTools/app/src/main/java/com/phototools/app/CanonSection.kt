package com.phototools.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

/** Camera cable -> phone screen with 3 tabs: Status, Gallery, Live View. */
class CanonSection(
    private val act: Activity,
    private val showQueueOption: Boolean,
    private val embedded: Boolean = false
) {
    val view = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Ui.BG)
    }
    var extraChange: (() -> Unit)? = null

    private val prefs = act.getSharedPreferences("canon", Context.MODE_PRIVATE)
    private val usb = act.getSystemService(Context.USB_SERVICE) as UsbManager
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<String, Bitmap>(200)
    private var receiver: BroadcastReceiver? = null
    private var items: List<Uri> = emptyList()
    private var lastCopied = -1
    private var tab = 0

    // status tab
    private val statusDot = View(act).apply { background = Ui.shape(act, Ui.MUTED, 0, true) }
    private val statusText = Ui.label(act, "", 15f)
    private val statsText = Ui.label(act, "", 13f, Ui.MUTED)
    private val statusCol = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val statusPane = ScrollView(act).apply { addView(statusCol) }

    // gallery tab
    private val galleryPane = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val galleryCount = Ui.label(act, "", 14f, Ui.MUTED)
    private val grid = GridView(act)

    // live tab
    private val livePane = LinearLayout(act)
    private val liveImage = ImageView(act).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
    private val livePlaceholder = Ui.label(act, "Live view is off\nTap  Start live view", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
    private val liveBadge = Ui.label(act, "  LIVE  ", 12f, Color.WHITE, true).apply {
        background = Ui.shape(act, Ui.RED, 8)
        visibility = View.GONE
    }
    private val tapHint = Ui.label(act, "Tap the screen to take a photo", 12f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 10)
        setPadding(Ui.dp(act, 10), Ui.dp(act, 4), Ui.dp(act, 10), Ui.dp(act, 4))
    }
    private val countdownView = Ui.label(act, "", 96f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        setShadowLayer(12f, 0f, 0f, Color.BLACK)
        visibility = View.GONE
    }
    private val liveBox = FrameLayout(act).apply { setBackgroundColor(Color.BLACK) }
    private val controls = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 4))
    }
    private val liveInfo = Ui.label(act, "", 12f, Ui.MUTED)
    private val chips = ArrayList<TextView>()
    private lateinit var liveButton: TextView

    private val tabViews = ArrayList<TextView>()

    // countdown
    private var counting = false
    private var countLeft = 0
    private val tick = object : Runnable {
        override fun run() {
            if (!counting) return
            if (countLeft <= 0) {
                counting = false
                countdownView.visibility = View.GONE
                fire()
            } else {
                countdownView.text = countLeft.toString()
                countdownView.visibility = View.VISIBLE
                countLeft--
                ui.postDelayed(this, 1000)
            }
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            val size = act.resources.displayMetrics.widthPixels / grid.numColumns - Ui.dp(act, 4)
            iv.layoutParams = AbsListView.LayoutParams(size, size)
            loadThumb(iv, items[p])
            return iv
        }
    }

    init {
        buildStatus()
        buildGallery()
        buildLiveParts()
        buildTabs()
        buildLive()
        show(0)
        loadGallery()
    }

    // ------------------------------------------------------------------ build UI

    private fun buildStatus() {
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(act).apply { setImageResource(R.drawable.logo) }, Ui.lp(act, Ui.dp(act, 60), Ui.dp(act, 60)))
        val t = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.label(act, "Canon Auto Copy", 22f, Ui.TEXT, true))
        t.addView(Ui.label(act, "EOS 760D  -  real-time USB transfer", 13f, Ui.MUTED))
        head.addView(t, Ui.lp(act, 0, -2, 1f, side = 12))
        statusCol.addView(head, Ui.lp(act, -1, -2, bottom = 12))

        val st = Ui.card(act)
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(statusDot, Ui.lp(act, Ui.dp(act, 12), Ui.dp(act, 12)))
        row.addView(statusText, Ui.lp(act, 0, -2, 1f, side = 10))
        st.addView(row)
        st.addView(statsText, Ui.lp(act, -2, -2, top = 6))
        st.addView(Ui.pill(act, "Connect camera now", Ui.ACCENT) { connect(null) }, Ui.lp(act, -1, -2, top = 12))
        statusCol.addView(st, Ui.lp(act, -1, -2, bottom = 12))

        val set = Ui.card(act)
        set.addView(Ui.label(act, "Settings", 16f, Ui.TEXT, true))
        set.addView(Ui.label(act, "Folder name for transferred media", 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 10))
        val frow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = EditText(act).apply {
            setText(CanonSyncService.folderOf(prefs))
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            hint = "Canon760D"
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
            background = Ui.shape(act, Ui.CARD2, 12)
            setPadding(Ui.dp(act, 12), Ui.dp(act, 10), Ui.dp(act, 12), Ui.dp(act, 10))
        }
        frow.addView(et, Ui.lp(act, 0, -2, 1f))
        frow.addView(Ui.pill(act, "Save", Ui.ACCENT) {
            prefs.edit().putString("folder", et.text.toString()).apply()
            val f = CanonSyncService.folderOf(prefs)
            et.setText(f)
            CanonSyncService.post("Folder set to \"$f\". New photos go to Pictures/$f")
            loadGallery()
        }, Ui.lp(act, -2, -2, side = 8))
        set.addView(frow, Ui.lp(act, -1, -2, top = 6))
        set.addView(Ui.label(act, "Letters, numbers, space, - _ . only. Gallery shows this folder.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
        set.addView(switchRow("Also copy photos already on the card", "import_existing"), Ui.lp(act, -1, -2, top = 12))
        if (showQueueOption) set.addView(switchRow("Add new camera photos to the Facebook list", "auto_queue"), Ui.lp(act, -1, -2, top = 6))
        statusCol.addView(set, Ui.lp(act, -1, -2, bottom = 12))

        val help = Ui.card(act)
        help.addView(Ui.label(act, "How to use", 16f, Ui.TEXT, true))
        help.addView(Ui.label(act,
            "1. Switch the camera ON (menu: Auto power off = Disable).\n" +
            "2. Plug the USB cable, camera to phone (OTG adapter if needed).\n" +
            "3. Tap Allow / Always open with this app.\n" +
            "4. Take photos with the shutter or from the Live View tab.\n" +
            "5. Every photo is copied within seconds. Originals on the card are never deleted. Works offline.",
            13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        statusCol.addView(help)
    }

    private fun switchRow(text: String, key: String): Switch = Switch(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(Ui.TEXT)
        isChecked = prefs.getBoolean(key, false)
        setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean(key, on).apply() }
    }

    private fun buildGallery() {
        grid.numColumns = if (isLandscape()) 5 else 3
        grid.horizontalSpacing = Ui.dp(act, 3)
        grid.verticalSpacing = Ui.dp(act, 3)
        grid.setPadding(Ui.dp(act, 4), 0, Ui.dp(act, 4), Ui.dp(act, 8))
        grid.clipToPadding = false
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> PhotoViewer(act, items, pos, pool).show() }
        galleryPane.addView(galleryCount, Ui.lp(act, -2, -2, top = 4, bottom = 6, side = 16))
        galleryPane.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun buildLiveParts() {
        liveBox.addView(liveImage, FrameLayout.LayoutParams(-1, -1))
        liveBox.addView(livePlaceholder, FrameLayout.LayoutParams(-1, -1))
        liveBox.addView(liveBadge, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(Ui.dp(act, 10), Ui.dp(act, 10), 0, 0) })
        liveBox.addView(tapHint, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = Ui.dp(act, 10) })
        liveBox.addView(countdownView, FrameLayout.LayoutParams(-1, -1))
        liveBox.setOnClickListener { capture() }

        val trow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        trow.addView(Ui.label(act, "Timer", 13f, Ui.MUTED), Ui.lp(act, -2, -2, side = 4))
        for ((txt, secs) in listOf("Off" to 0, "3s" to 3, "5s" to 5, "10s" to 10)) {
            val chip = Ui.pill(act, txt, Ui.CARD2) { prefs.edit().putInt("timer", secs).apply(); updateChips() }
            chip.tag = secs
            chip.textSize = 13f
            chip.setPadding(Ui.dp(act, 12), Ui.dp(act, 7), Ui.dp(act, 12), Ui.dp(act, 7))
            chips.add(chip)
            trow.addView(chip, Ui.lp(act, -2, -2, side = 4))
        }
        controls.addView(trow)

        val brow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        liveButton = Ui.pill(act, "Start live view", Ui.CARD2) { toggleLive() }
        brow.addView(liveButton, Ui.lp(act, 0, -2, 1f, side = 4))
        brow.addView(Ui.pill(act, "Take photo", Ui.RED) { capture() }, Ui.lp(act, 0, -2, 1f, side = 4))
        controls.addView(brow, Ui.lp(act, -1, -2, top = 8))
        controls.addView(liveInfo, Ui.lp(act, -2, -2, top = 6, side = 4))
        updateChips()
    }

    private fun buildTabs() {
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.shape(act, Ui.CARD, 16)
            setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
        }
        listOf("Status", "Gallery", "Live View").forEachIndexed { i, name ->
            val tv = Ui.pill(act, name, Color.TRANSPARENT, Ui.MUTED) { show(i) }
            tv.textSize = 14f
            tabViews.add(tv)
            bar.addView(tv, Ui.lp(act, 0, -2, 1f))
        }
        view.addView(bar, Ui.lp(act, -1, -2, top = 8, bottom = 8, side = 12))
        val frame = FrameLayout(act)
        frame.addView(statusPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(galleryPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(livePane, FrameLayout.LayoutParams(-1, -1))
        view.addView(frame, if (embedded) LinearLayout.LayoutParams(-1, Ui.dp(act, 760)) else LinearLayout.LayoutParams(-1, 0, 1f))
    }

    /** Portrait: live screen on top, photos below. Landscape: live screen left, photos on the side. */
    private fun buildLive() {
        val land = isLandscape()
        Ui.detach(liveBox)
        Ui.detach(controls)
        livePane.removeAllViews()
        livePane.orientation = if (land) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL

        val holder = LinearLayout(act).apply { orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
        val px = Ui.dp(act, 92)
        if (items.isEmpty()) {
            holder.addView(Ui.label(act, "Photos you take will appear here", 13f, Ui.MUTED), Ui.lp(act, -2, -2, side = 8, top = 8))
        }
        for ((i, u) in items.take(40).withIndex()) {
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setOnClickListener { PhotoViewer(act, items, i, pool).show() }
            }
            loadThumb(iv, u)
            holder.addView(iv, Ui.lp(act, px, px, side = 3, top = 3, bottom = 3))
        }
        val scroller: View = if (land) ScrollView(act).apply { addView(holder) } else HorizontalScrollView(act).apply { addView(holder) }

        if (land) {
            livePane.addView(liveBox, Ui.lp(act, 0, -1, 3f, top = 4, bottom = 8, side = 8))
            val right = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
            right.addView(controls, Ui.lp(act, -1, -2))
            right.addView(scroller, Ui.lp(act, -1, 0, 1f))
            livePane.addView(right, Ui.lp(act, 0, -1, 2f))
        } else {
            val w = act.resources.displayMetrics.widthPixels - Ui.dp(act, 24)
            livePane.addView(liveBox, Ui.lp(act, -1, w * 2 / 3, side = 12))
            livePane.addView(controls, Ui.lp(act, -1, -2, top = 4))
            livePane.addView(scroller, Ui.lp(act, -1, Ui.dp(act, 104), top = 4, side = 8))
        }
    }

    // ------------------------------------------------------------------ behaviour

    private fun isLandscape() = act.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    fun onConfigChanged() {
        grid.numColumns = if (isLandscape()) 5 else 3
        adapter.notifyDataSetChanged()
        buildLive()
    }

    private fun show(i: Int) {
        tab = i
        statusPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        galleryPane.visibility = if (i == 1) View.VISIBLE else View.GONE
        livePane.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabViews.forEachIndexed { k, tv ->
            tv.background = Ui.shape(act, if (k == i) Ui.ACCENT else Color.TRANSPARENT, 12)
            tv.setTextColor(if (k == i) Color.WHITE else Ui.MUTED)
        }
        if (i != 2) { stopLive(); cancelCountdown() }
        if (i == 1) loadGallery()
        refresh()
    }

    private fun toggleLive() {
        if (!CanonSyncService.running) { liveInfo.text = "Connect the camera first (cable + Allow)."; return }
        if (CanonSyncService.liveWanted) stopLive() else {
            CanonSyncService.liveWanted = true
            liveInfo.text = "Starting live view (a few seconds)..."
        }
        refresh()
    }

    private fun stopLive() {
        CanonSyncService.liveWanted = false
        liveImage.setImageDrawable(null)
    }

    private fun capture() {
        if (counting) { cancelCountdown(); liveInfo.text = "Timer cancelled."; return }
        if (!CanonSyncService.running) { liveInfo.text = "Connect the camera first (cable + Allow)."; return }
        val secs = prefs.getInt("timer", 0)
        if (secs <= 0) fire() else { counting = true; countLeft = secs; ui.post(tick) }
    }

    private fun fire() {
        CanonSyncService.shootRequested = true
        liveInfo.text = "Taking photo..."
    }

    private fun cancelCountdown() {
        counting = false
        ui.removeCallbacks(tick)
        countdownView.visibility = View.GONE
    }

    private fun updateChips() {
        val cur = prefs.getInt("timer", 0)
        for (c in chips) {
            val sel = (c.tag as Int) == cur
            c.background = Ui.shape(act, if (sel) Ui.ACCENT else Ui.CARD2, 14)
        }
    }

    private fun loadThumb(iv: ImageView, uri: Uri) {
        val key = uri.toString()
        iv.tag = key
        iv.setBackgroundColor(Ui.CARD2)
        val cached = cache.get(key)
        if (cached != null) { iv.setImageBitmap(cached); return }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val bm = act.contentResolver.loadThumbnail(uri, Size(256, 256), null)
                cache.put(key, bm)
                act.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
    }

    private fun loadGallery() {
        val folder = CanonSyncService.folderOf(prefs)
        Thread {
            val list = ArrayList<Uri>()
            try {
                val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                act.contentResolver.query(
                    base, arrayOf(MediaStore.Images.Media._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("Pictures/$folder%"),
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && list.size < 400) list.add(ContentUris.withAppendedId(base, c.getLong(0)))
                }
            } catch (_: Exception) {}
            act.runOnUiThread {
                items = list
                adapter.notifyDataSetChanged()
                galleryCount.text = "${list.size} photo(s) in Pictures/$folder  -  tap to enlarge"
                buildLive()
            }
        }.start()
    }

    // ------------------------------------------------------------------ lifecycle / USB

    fun onCreate(intent: Intent?) {
        registerPermissionReceiver()
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        CanonSyncService.onChange = { act.runOnUiThread { refresh(); extraChange?.invoke() } }
        CanonSyncService.onFrame = { bm ->
            act.runOnUiThread {
                if (CanonSyncService.liveWanted) {
                    liveImage.setImageBitmap(bm)
                    livePlaceholder.visibility = View.GONE
                }
            }
        }
        handleIntent(intent)
        refresh()
    }

    fun onNewIntent(intent: Intent?) = handleIntent(intent)

    fun onDestroy() {
        cancelCountdown()
        receiver?.let { try { act.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        CanonSyncService.onChange = null
        CanonSyncService.onFrame = null
        CanonSyncService.liveWanted = false
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect(CanonControl.deviceFrom(i))
    }

    fun connect(d: UsbDevice?) {
        val dev = d ?: CanonControl.findCamera(act)
        if (dev == null) {
            CanonSyncService.post("No camera found. Plug it in and switch it ON.")
            return
        }
        if (usb.hasPermission(dev)) {
            CanonControl.start(act, dev)
        } else {
            val pi = PendingIntent.getBroadcast(
                act, 0,
                Intent(CanonControl.ACTION_PERMISSION).setPackage(act.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usb.requestPermission(dev, pi)
        }
    }

    private fun registerPermissionReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val dev = CanonControl.deviceFrom(i)
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                    CanonControl.start(act, dev)
                } else {
                    CanonSyncService.post("USB permission not allowed. Tap Connect and choose Allow.")
                }
            }
        }
        receiver = r
        val f = IntentFilter(CanonControl.ACTION_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else act.registerReceiver(r, f)
    }

    fun refresh() {
        val s = CanonSyncService.status
        statusText.text = s
        statusText.setTextColor(Ui.TEXT)
        val bad = s.startsWith("Error") || s.startsWith("Lost") || s.startsWith("Failed") ||
            s.startsWith("Cannot") || s.contains("not allowed") || s.startsWith("Camera could not")
        statusDot.background = Ui.shape(act, when {
            bad -> Ui.RED
            CanonSyncService.running -> Ui.GREEN
            else -> Ui.MUTED
        }, 0, true)
        statsText.text = "Copied this session: ${CanonSyncService.copied}   |   Folder: Pictures/${CanonSyncService.folderOf(prefs)}"
        liveInfo.text = if (tab == 2 && !counting) s else liveInfo.text
        val live = CanonSyncService.liveWanted
        liveButton.text = if (live) "Stop live view" else "Start live view"
        liveBadge.visibility = if (live) View.VISIBLE else View.GONE
        if (!live) livePlaceholder.visibility = View.VISIBLE
        if (CanonSyncService.copied != lastCopied) {
            lastCopied = CanonSyncService.copied
            loadGallery()
        }
    }
}
