package com.phototools.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.concurrent.Executors

/**
 * Canon Auto Copy (photobooth = false) and Android Photobooth (photobooth = true).
 * Tabs: Status, Gallery, Live View (full screen), Templates, Settings.
 */
class CanonSection(
    private val act: Activity,
    private val photobooth: Boolean
) {
    val view = FrameLayout(act).apply { setBackgroundColor(Ui.BG) }

    private val prefs = act.getSharedPreferences("canon", Context.MODE_PRIVATE)
    private val usb = act.getSystemService(Context.USB_SERVICE) as UsbManager
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val cache = LruCache<String, Bitmap>(200)
    private val cloud: CloudCards? = if (photobooth) CloudCards(act, pool) else null
    private var receiver: BroadcastReceiver? = null
    private var items: List<Uri> = emptyList()
    private var lastCopied = -1
    private var lastSeq = CanonSyncService.lastSavedSeq
    private var tab = 0
    private var prevTab = 0

    // ---- status tab
    private val statusDot = View(act).apply { background = Ui.shape(act, Ui.MUTED, 0, true) }
    private val statusText = Ui.label(act, "", 15f)
    private val statsText = Ui.label(act, "", 13f, Ui.MUTED)
    private val cloudText = Ui.label(act, "", 12f, Ui.MUTED)
    private val statusCol = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val statusPane = ScrollView(act).apply { addView(statusCol) }

    // ---- gallery tab
    private val galleryPane = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    private val galleryCount = Ui.label(act, "", 14f, Ui.MUTED)
    private val grid = GridView(act)

    // ---- settings tab
    private val settingsCol = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(Ui.dp(act, 16), Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 24))
    }
    private val settingsPane = ScrollView(act).apply { addView(settingsCol) }
    private val printerText = Ui.label(act, "", 12f, Ui.MUTED)

    // ---- templates tab
    private val templatePane = TemplatePane(act, prefs, pool)

    // ---- live view (full screen overlay)
    private val livePane = FrameLayout(act).apply { setBackgroundColor(Color.BLACK); visibility = View.GONE }
    private val liveImage = ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val boothView = BoothView(act).apply { visibility = View.GONE }
    private val livePlaceholder = Ui.label(act, "Tap  \u25B6  to start live view", 15f, Ui.MUTED).apply { gravity = Gravity.CENTER }
    private val liveInfo = Ui.label(act, "", 12f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 10)
        setPadding(Ui.dp(act, 10), Ui.dp(act, 4), Ui.dp(act, 10), Ui.dp(act, 4))
        maxLines = 2
    }
    private val countdownView = Ui.label(act, "", 120f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER
        setShadowLayer(14f, 0f, 0f, Color.BLACK)
        visibility = View.GONE
    }
    private val liveBadge = Ui.label(act, "  LIVE  ", 12f, Color.WHITE, true).apply {
        background = Ui.shape(act, Ui.RED, 8)
        setPadding(Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6))
        visibility = View.GONE
    }
    private lateinit var backBtn: TextView
    private lateinit var timerBtn: TextView
    private lateinit var templateBtn: TextView
    private lateinit var fullBtn: TextView
    private lateinit var fillBtn: TextView
    private lateinit var liveBtn: TextView
    private lateinit var shootBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var finishBtn: TextView
    private lateinit var restartBtn: TextView
    private val controlsBar = LinearLayout(act).apply { gravity = Gravity.CENTER }
    private val panel = LinearLayout(act).apply {
        background = Ui.shape(act, 0x990B0F17.toInt(), 18)
        setPadding(Ui.dp(act, 6), Ui.dp(act, 6), Ui.dp(act, 6), Ui.dp(act, 6))
    }

    // ---- finished-photo preview
    private val resultPane = FrameLayout(act).apply { setBackgroundColor(0xF2000000.toInt()); visibility = View.GONE; isClickable = true }
    private val resultImage = ImageView(act).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
    private val resultInfo = Ui.label(act, "", 14f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 12)
        setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8))
    }
    private var resultUri: Uri? = null
    private var resultLeft = 0
    private val resultTick = object : Runnable {
        override fun run() {
            if (resultPane.visibility != View.VISIBLE) return
            if (resultLeft <= 0) { dismissResult(); return }
            resultTimer.text = "Next guest in ${resultLeft}s"
            resultLeft--
            ui.postDelayed(this, 1000)
        }
    }
    private val resultTimer = Ui.label(act, "", 13f, Color.WHITE).apply {
        background = Ui.shape(act, 0x99000000.toInt(), 12)
        setPadding(Ui.dp(act, 12), Ui.dp(act, 8), Ui.dp(act, 12), Ui.dp(act, 8))
    }

    // ---- photo booth state
    private var boothTpl: Template? = null
    private var slotUris: Array<Uri?> = arrayOfNulls(0)
    private var slotBmps: Array<Bitmap?> = arrayOfNulls(0)
    private var cur = 0

    private val tabViews = ArrayList<TextView>()
    private var counting = false
    private var countLeft = 0
    private val tick = object : Runnable {
        override fun run() {
            if (!counting) return
            if (countLeft <= 0) {
                counting = false
                countdownView.visibility = View.GONE
                fire()
            } else {
                countdownView.text = countLeft.toString()
                countdownView.visibility = View.VISIBLE
                countLeft--
                ui.postDelayed(this, 1000)
            }
        }
    }

    private val adapter = object : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val iv = (cv as? ImageView) ?: ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            val size = act.resources.displayMetrics.widthPixels / grid.numColumns - Ui.dp(act, 4)
            iv.layoutParams = AbsListView.LayoutParams(size, size)
            loadThumb(iv, items[p])
            return iv
        }
    }

    init {
        buildStatus()
        buildGallery()
        buildSettings()
        buildLiveParts()
        buildTabs()
        templatePane.onChanged = { syncBooth(); refresh() }
        buildLive()
        syncBooth()
        show(0)
        loadGallery()
    }

    // ================================================================== helpers

    private fun switchRow(text: String, sp: SharedPreferences, key: String, def: Boolean = false, onToggle: (() -> Unit)? = null): Switch = Switch(act).apply {
        this.text = text
        textSize = 14f
        setTextColor(Ui.TEXT)
        isChecked = sp.getBoolean(key, def)
        setOnCheckedChangeListener { _, on -> sp.edit().putBoolean(key, on).apply(); onToggle?.invoke() }
    }

    private fun intChips(parent: LinearLayout, title: String, labels: List<String>, values: List<Int>, key: String, def: Int, after: (() -> Unit)? = null) {
        parent.addView(Ui.label(act, title, 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val list = ArrayList<TextView>()
        fun paint() {
            val c0 = prefs.getInt(key, def)
            for (c in list) c.background = Ui.shape(act, if ((c.tag as Int) == c0) Ui.ACCENT else Ui.CARD2, 14)
        }
        labels.forEachIndexed { i, l ->
            val c = Ui.pill(act, l, Ui.CARD2) { prefs.edit().putInt(key, values[i]).apply(); paint(); after?.invoke() }
            c.tag = values[i]
            c.textSize = 13f
            c.setPadding(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), Ui.dp(act, 8))
            list.add(c)
            row.addView(c, Ui.lp(act, 0, -2, 1f, side = 2))
        }
        paint()
        parent.addView(row, Ui.lp(act, -1, -2, top = 4))
    }

    private fun isLandscape() = act.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    // ================================================================== build UI

    private fun buildStatus() {
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(act).apply { setImageResource(R.drawable.logo) }, Ui.lp(act, Ui.dp(act, 60), Ui.dp(act, 60)))
        val t = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.label(act, if (photobooth) "Android Photobooth" else "Canon Auto Copy", 22f, Ui.TEXT, true))
        t.addView(Ui.label(act, if (photobooth) "Canon EOS live booth, templates, print & cloud" else "EOS 760D  -  real-time USB transfer", 13f, Ui.MUTED))
        head.addView(t, Ui.lp(act, 0, -2, 1f, side = 12))
        statusCol.addView(head, Ui.lp(act, -1, -2, bottom = 12))

        val st = Ui.card(act)
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(statusDot, Ui.lp(act, Ui.dp(act, 12), Ui.dp(act, 12)))
        row.addView(statusText, Ui.lp(act, 0, -2, 1f, side = 10))
        st.addView(row)
        st.addView(statsText, Ui.lp(act, -2, -2, top = 6))
        if (photobooth) st.addView(cloudText, Ui.lp(act, -2, -2, top = 4))
        st.addView(Ui.pill(act, "Connect camera now", Ui.ACCENT) { connect(null) }, Ui.lp(act, -1, -2, top = 12))
        st.addView(Ui.pill(act, "Open Live View", Ui.CARD2) { show(2) }, Ui.lp(act, -1, -2, top = 8))
        statusCol.addView(st, Ui.lp(act, -1, -2, bottom = 12))

        val help = Ui.card(act)
        help.addView(Ui.label(act, "How to use", 16f, Ui.TEXT, true))
        help.addView(Ui.label(act,
            "1. Switch the camera ON (menu: Auto power off = Disable).\n" +
            "2. Plug the USB cable, camera to phone (OTG adapter if needed).\n" +
            "3. Tap Allow / Always open with this app.\n" +
            "4. Take photos with the shutter, or open Live View and tap the screen.\n" +
            "5. Every photo is copied within seconds. Originals on the card are never deleted.\n" +
            "Timer, folder, printing and more are in the Settings tab.",
            13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        statusCol.addView(help)
    }

    private fun buildSettings() {
        settingsCol.addView(Ui.label(act, "Settings", 22f, Ui.TEXT, true), Ui.lp(act, -2, -2, bottom = 10))

        val timer = Ui.card(act)
        timer.addView(Ui.label(act, "Countdown timer", 16f, Ui.TEXT, true))
        intChips(timer, "Seconds before the photo is taken", listOf("Off", "3s", "5s", "10s", "15s"), listOf(0, 3, 5, 10, 15), "timer", 0) { refresh() }
        settingsCol.addView(timer, Ui.lp(act, -1, -2, bottom = 12))

        val live = Ui.card(act)
        live.addView(Ui.label(act, "Live view", 16f, Ui.TEXT, true))
        live.addView(switchRow("Full screen (hide status and navigation bars)", prefs, "live_full", true) { if (tab == 2) applyFullscreen(prefs.getBoolean("live_full", true)); refresh() }, Ui.lp(act, -1, -2, top = 10))
        live.addView(switchRow("Fill the screen (crops the edges)", prefs, "live_fill", true) { refresh() }, Ui.lp(act, -1, -2, top = 8))
        settingsCol.addView(live, Ui.lp(act, -1, -2, bottom = 12))

        val booth = Ui.card(act)
        booth.addView(Ui.label(act, "Photo booth & printing", 16f, Ui.TEXT, true))
        booth.addView(switchRow("Show template on live view", prefs, "tpl_live") { syncBooth(); refresh() }, Ui.lp(act, -1, -2, top = 10))
        booth.addView(switchRow("Print automatically when I tap Finish", prefs, "auto_print") , Ui.lp(act, -1, -2, top = 8))
        booth.addView(switchRow("Start a new session after the preview", prefs, "auto_reset", true), Ui.lp(act, -1, -2, top = 8))
        intChips(booth, "Show the finished picture for", listOf("3s", "5s", "8s", "15s"), listOf(3, 5, 8, 15), "preview_secs", 5)
        booth.addView(Ui.label(act, "Printer", 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 12))
        booth.addView(printerText, Ui.lp(act, -2, -2, top = 2))
        val prow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        prow.addView(Ui.pill(act, "Select printer", Ui.ACCENT) { Printing.selectPrinter(act, prefs) { refresh() } }, Ui.lp(act, 0, -2, 1f, side = 3))
        prow.addView(Ui.pill(act, "Print settings", Ui.CARD2) { Printing.settings(act, prefs) }, Ui.lp(act, 0, -2, 1f, side = 3))
        booth.addView(prow, Ui.lp(act, -1, -2, top = 6))
        booth.addView(Ui.label(act, "Wi-Fi printers print directly with no pop-up (AirPrint / Mopria printers, same Wi-Fi). Otherwise the Android print screen opens.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        settingsCol.addView(booth, Ui.lp(act, -1, -2, bottom = 12))

        val cam = Ui.card(act)
        cam.addView(Ui.label(act, "Transfer", 16f, Ui.TEXT, true))
        cam.addView(Ui.label(act, "Folder name for transferred media", 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 8))
        val frow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val et = Ui.input(act, CanonSyncService.folderOf(prefs), "Canon760D")
        frow.addView(et, Ui.lp(act, 0, -2, 1f))
        frow.addView(Ui.pill(act, "Save", Ui.ACCENT) {
            prefs.edit().putString("folder", et.text.toString()).apply()
            val f = CanonSyncService.folderOf(prefs)
            et.setText(f)
            CanonSyncService.post("Folder set to \"$f\". New photos go to Pictures/$f")
            loadGallery()
        }, Ui.lp(act, -2, -2, side = 8))
        cam.addView(frow, Ui.lp(act, -1, -2, top = 6))
        cam.addView(Ui.label(act, "Letters, numbers, space, - _ . only.", 11f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
        cam.addView(switchRow("Also copy photos already on the card", prefs, "import_existing"), Ui.lp(act, -1, -2, top = 12))
        settingsCol.addView(cam, Ui.lp(act, -1, -2, bottom = 12))

        if (cloud != null) {
            settingsCol.addView(cloud.facebookCard(true), Ui.lp(act, -1, -2, bottom = 12))
            settingsCol.addView(cloud.driveCard())
        }
    }

    private fun buildGallery() {
        grid.numColumns = if (isLandscape()) 5 else 3
        grid.horizontalSpacing = Ui.dp(act, 3)
        grid.verticalSpacing = Ui.dp(act, 3)
        grid.setPadding(Ui.dp(act, 4), 0, Ui.dp(act, 4), Ui.dp(act, 8))
        grid.clipToPadding = false
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> PhotoViewer(act, items, pos, pool).show() }
        galleryPane.addView(galleryCount, Ui.lp(act, -2, -2, top = 4, bottom = 6, side = 16))
        galleryPane.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun icon(glyph: String, bg: Int = 0x99000000.toInt(), fg: Int = Color.WHITE, sp: Float = 18f, onClick: () -> Unit) =
        Ui.icon(act, glyph, bg, fg, sp, onClick)

    private fun buildLiveParts() {
        livePane.addView(liveImage, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(boothView, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(livePlaceholder, FrameLayout.LayoutParams(-1, -1))
        liveImage.setOnClickListener { capture() }
        boothView.onSlotClick = { i -> onSlotTap(i) }

        val s = Ui.dp(act, 42)
        val top = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        backBtn = icon("\u2190") { leaveLive() }
        timerBtn = icon("\u23F1", sp = 14f) { cycleTimer() }
        templateBtn = icon("\uD83D\uDDBC") { prefs.edit().putBoolean("tpl_live", !prefs.getBoolean("tpl_live", false)).apply(); syncBooth(); refresh() }
        fullBtn = icon("\u26F6") { prefs.edit().putBoolean("live_full", !prefs.getBoolean("live_full", true)).apply(); applyFullscreen(prefs.getBoolean("live_full", true)); refresh() }
        fillBtn = icon("\u2922") { prefs.edit().putBoolean("live_fill", !prefs.getBoolean("live_fill", true)).apply(); refresh() }
        top.addView(backBtn, Ui.lp(act, s, s, side = 3))
        top.addView(timerBtn, Ui.lp(act, Ui.dp(act, 62), s, side = 3))
        top.addView(templateBtn, Ui.lp(act, s, s, side = 3))
        top.addView(fullBtn, Ui.lp(act, s, s, side = 3))
        top.addView(fillBtn, Ui.lp(act, s, s, side = 3))
        top.addView(View(act), Ui.lp(act, 0, 1, 1f))
        top.addView(liveBadge, Ui.lp(act, -2, -2, side = 6))
        livePane.addView(top, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { setMargins(Ui.dp(act, 6), Ui.dp(act, 8), Ui.dp(act, 6), 0) })
        livePane.addView(liveInfo, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = Ui.dp(act, 58) })
        livePane.addView(countdownView, FrameLayout.LayoutParams(-1, -1))

        liveBtn = icon("\u25B6", 0x66FFFFFF, Color.WHITE, 18f) { toggleLive() }
        shootBtn = icon("\uD83D\uDCF7", Color.WHITE, Color.BLACK, 26f) { capture() }
        addBtn = icon("\uFF0B", 0x66FFFFFF, Color.WHITE, 18f) { addPhotoToBooth() }
        finishBtn = icon("\u2714", Ui.ACCENT, Color.WHITE, 18f) { finishBooth() }
        restartBtn = icon("\u21BA", 0x66FFFFFF, Color.WHITE, 18f) { restartBooth() }

        // result preview (shown after Finish)
        resultPane.addView(resultImage, FrameLayout.LayoutParams(-1, -1))
        resultImage.setOnClickListener { dismissResult() }
        resultPane.addView(resultTimer, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { setMargins(Ui.dp(act, 12), Ui.dp(act, 16), 0, 0) })
        resultPane.addView(icon("\u2715") { dismissResult() }, FrameLayout.LayoutParams(s, s, Gravity.TOP or Gravity.END).apply { setMargins(0, Ui.dp(act, 12), Ui.dp(act, 12), 0) })
        resultPane.addView(icon("\uD83D\uDDA8") { resultUri?.let { printPicture(it) } }, FrameLayout.LayoutParams(s, s, Gravity.BOTTOM or Gravity.END).apply { setMargins(0, 0, Ui.dp(act, 12), Ui.dp(act, 16)) })
        resultPane.addView(resultInfo, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START).apply { setMargins(Ui.dp(act, 12), 0, Ui.dp(act, 64), Ui.dp(act, 16)) })
    }

    private fun buildTabs() {
        val bar = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.shape(act, Ui.CARD, 16)
            setPadding(Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4), Ui.dp(act, 4))
        }
        listOf("Status", "Gallery", "Live View", "Templates", "Settings").forEachIndexed { i, name ->
            val tv = Ui.pill(act, name, Color.TRANSPARENT, Ui.MUTED) { show(i) }
            tv.textSize = 13f
            tv.setPadding(Ui.dp(act, 14), Ui.dp(act, 10), Ui.dp(act, 14), Ui.dp(act, 10))
            tabViews.add(tv)
            bar.addView(tv, Ui.lp(act, -2, -2))
        }
        val barScroll = HorizontalScrollView(act).apply { isHorizontalScrollBarEnabled = false; addView(bar) }
        val content = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        content.addView(barScroll, Ui.lp(act, -1, -2, top = 8, bottom = 8, side = 12))
        val frame = FrameLayout(act)
        frame.addView(statusPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(galleryPane, FrameLayout.LayoutParams(-1, -1))
        frame.addView(templatePane.view, FrameLayout.LayoutParams(-1, -1))
        frame.addView(settingsPane, FrameLayout.LayoutParams(-1, -1))
        content.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        view.addView(content, FrameLayout.LayoutParams(-1, -1))
        view.addView(livePane, FrameLayout.LayoutParams(-1, -1))
        livePane.addView(resultPane, FrameLayout.LayoutParams(-1, -1))
    }

    /** Portrait: photo previews along the bottom. Landscape: previews in a column on the right. */
    private fun buildLive() {
        val land = isLandscape()
        Ui.detach(panel)
        Ui.detach(controlsBar)
        Ui.detach(resultPane)
        panel.removeAllViews()
        controlsBar.removeAllViews()
        panel.orientation = LinearLayout.VERTICAL
        controlsBar.orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL

        val holder = LinearLayout(act).apply { orientation = if (land) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL }
        val px = Ui.dp(act, 64)
        if (items.isEmpty()) holder.addView(Ui.label(act, "New photos appear here", 12f, Ui.MUTED), Ui.lp(act, -2, -2, side = 8, top = 8))
        for ((i, u) in items.take(40).withIndex()) {
            val iv = ImageView(act).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setOnClickListener { PhotoViewer(act, items, i, pool).show() }
            }
            loadThumb(iv, u)
            holder.addView(iv, Ui.lp(act, px, px, side = 3, top = 2, bottom = 2))
        }
        val scroller: View = if (land) ScrollView(act).apply { addView(holder) } else HorizontalScrollView(act).apply { addView(holder) }

        val b = Ui.dp(act, 44)
        val big = Ui.dp(act, 64)
        for (v in listOf(liveBtn, addBtn, finishBtn, restartBtn, shootBtn)) Ui.detach(v)
        controlsBar.addView(liveBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(shootBtn, Ui.lp(act, big, big, side = 4, top = 3, bottom = 3))
        controlsBar.addView(addBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(finishBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))
        controlsBar.addView(restartBtn, Ui.lp(act, b, b, side = 4, top = 3, bottom = 3))

        val boothLp = boothView.layoutParams as FrameLayout.LayoutParams
        if (land) {
            panel.addView(scroller, Ui.lp(act, -1, 0, 1f))
            panel.addView(controlsBar, Ui.lp(act, -1, -2, top = 4))
            livePane.addView(panel, FrameLayout.LayoutParams(Ui.dp(act, 88), -1, Gravity.END).apply { setMargins(0, Ui.dp(act, 8), Ui.dp(act, 8), Ui.dp(act, 8)) })
            boothLp.setMargins(0, Ui.dp(act, 56), Ui.dp(act, 104), Ui.dp(act, 8))
        } else {
            panel.addView(scroller, Ui.lp(act, -1, Ui.dp(act, 70)))
            panel.addView(controlsBar, Ui.lp(act, -1, -2, top = 4))
            livePane.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(Ui.dp(act, 8), 0, Ui.dp(act, 8), Ui.dp(act, 8)) })
            boothLp.setMargins(0, Ui.dp(act, 62), 0, Ui.dp(act, 190))
        }
        boothView.layoutParams = boothLp
        livePane.addView(resultPane, FrameLayout.LayoutParams(-1, -1))
    }

    // ================================================================== behaviour

    @Suppress("DEPRECATION")
    private fun applyFullscreen(on: Boolean) {
        val w = act.window
        // the window's decor view does not exist yet while the screen is still being built
        if (w.peekDecorView() == null) return
        try { applyFullscreenNow(w, on) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun applyFullscreenNow(w: android.view.Window, on: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            val c = w.insetsController
            if (c != null) {
                if (on) {
                    c.hide(WindowInsets.Type.systemBars())
                    c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                } else c.show(WindowInsets.Type.systemBars())
            }
        } else {
            w.decorView.systemUiVisibility = if (on)
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            else 0
        }
        if (Build.VERSION.SDK_INT >= 28) {
            val a = w.attributes
            a.layoutInDisplayCutoutMode = if (on) WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            w.attributes = a
        }
    }

    fun onConfigChanged() {
        grid.numColumns = if (isLandscape()) 5 else 3
        adapter.notifyDataSetChanged()
        buildLive()
    }

    fun onBack(): Boolean {
        if (resultPane.visibility == View.VISIBLE) { dismissResult(); return true }
        if (tab == 2) { leaveLive(); return true }
        if (tab != 0) { show(0); return true }
        return false
    }

    private fun leaveLive() { show(if (prevTab == 2) 0 else prevTab) }

    private fun show(i: Int) {
        if (i == 2 && tab != 2) prevTab = tab
        tab = i
        statusPane.visibility = if (i == 0) View.VISIBLE else View.GONE
        galleryPane.visibility = if (i == 1) View.VISIBLE else View.GONE
        templatePane.view.visibility = if (i == 3) View.VISIBLE else View.GONE
        settingsPane.visibility = if (i == 4) View.VISIBLE else View.GONE
        livePane.visibility = if (i == 2) View.VISIBLE else View.GONE
        tabViews.forEachIndexed { k, tv ->
            tv.background = Ui.shape(act, if (k == i) Ui.ACCENT else Color.TRANSPARENT, 12)
            tv.setTextColor(if (k == i) Color.WHITE else Ui.MUTED)
        }
        applyFullscreen(i == 2 && prefs.getBoolean("live_full", true))
        if (i != 2) { stopLive(); cancelCountdown(); dismissResult(false) } else syncBooth()
        if (i == 1) loadGallery()
        refresh()
    }

    private fun toggleLive() {
        if (!CanonSyncService.running) { liveInfo.text = "Connect the camera first (cable + Allow)."; return }
        if (CanonSyncService.liveWanted) stopLive() else {
            CanonSyncService.liveWanted = true
            liveInfo.text = "Starting live view (a few seconds)..."
        }
        refresh()
    }

    private fun stopLive() {
        CanonSyncService.liveWanted = false
        liveImage.setImageDrawable(null)
        boothView.live = null
        boothView.invalidate()
    }

    private fun cycleTimer() {
        val opts = listOf(0, 3, 5, 10, 15)
        val c0 = prefs.getInt("timer", 0)
        val n = opts[(opts.indexOf(c0) + 1) % opts.size]
        prefs.edit().putInt("timer", n).apply()
        refresh()
    }

    private fun capture() {
        if (counting) { cancelCountdown(); liveInfo.text = "Timer cancelled."; return }
        if (!CanonSyncService.running) { liveInfo.text = "Connect the camera first (cable + Allow)."; return }
        if (boothTpl != null && cur < 0) {
            liveInfo.text = "All windows are filled. Tap a photo to retake it, or tap \u2714."
            return
        }
        val secs = prefs.getInt("timer", 0)
        if (secs <= 0) fire() else { counting = true; countLeft = secs; ui.post(tick) }
    }

    private fun fire() {
        CanonSyncService.shootRequested = true
        liveInfo.text = "Taking photo..."
    }

    private fun cancelCountdown() {
        counting = false
        ui.removeCallbacks(tick)
        countdownView.visibility = View.GONE
    }

    private fun loadThumb(iv: ImageView, uri: Uri) {
        val key = uri.toString()
        iv.tag = key
        iv.setBackgroundColor(Ui.CARD2)
        val cached = cache.get(key)
        if (cached != null) { iv.setImageBitmap(cached); return }
        iv.setImageDrawable(null)
        pool.execute {
            try {
                val bm = act.contentResolver.loadThumbnail(uri, Size(512, 512), null)
                cache.put(key, bm)
                act.runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
    }

    private fun loadGallery() {
        val folder = CanonSyncService.folderOf(prefs)
        Thread {
            val list = ArrayList<Uri>()
            try {
                val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                act.contentResolver.query(
                    base, arrayOf(MediaStore.Images.Media._ID),
                    "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("Pictures/$folder%"),
                    "${MediaStore.MediaColumns.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && list.size < 400) list.add(ContentUris.withAppendedId(base, c.getLong(0)))
                }
            } catch (_: Exception) {}
            act.runOnUiThread {
                items = list
                adapter.notifyDataSetChanged()
                galleryCount.text = "${list.size} photo(s) in Pictures/$folder  -  tap to enlarge"
                buildLive()
            }
        }.start()
    }

    // ================================================================== photo booth

    private fun boothOn() = prefs.getBoolean("tpl_live", false) && templatePane.active() != null

    private fun syncBooth() {
        val t = if (boothOn()) templatePane.active() else null
        if (t == null) {
            boothTpl = null
            boothView.visibility = View.GONE
            liveImage.visibility = View.VISIBLE
            return
        }
        if (boothTpl?.id != t.id) {
            boothTpl = t
            resetSlots(t)
            boothView.overlay = null
            if (t.hasOverlay) pool.execute {
                try {
                    val o = BitmapFactory.Options().apply { inSampleSize = maxOf(1, maxOf(t.wPx, t.hPx) / 1600) }
                    val bm = BitmapFactory.decodeFile(TemplateStore.overlayFile(act, t.id).path, o)
                    act.runOnUiThread { boothView.overlay = bm; boothView.invalidate() }
                } catch (_: Exception) {}
            }
        }
        boothView.template = t
        boothView.visibility = View.VISIBLE
        liveImage.visibility = View.GONE
        pushBooth()
    }

    private fun resetSlots(t: Template) {
        slotUris = arrayOfNulls(t.slots.size)
        slotBmps = arrayOfNulls(t.slots.size)
        cur = 0
        pushBooth()
    }

    private fun pushBooth() {
        boothView.bitmaps = slotBmps
        boothView.current = cur
        boothView.invalidate()
    }

    private fun nextEmpty(from: Int): Int {
        val n = slotUris.size
        for (k in 0 until n) { val i = (from + k) % n; if (slotUris[i] == null) return i }
        return -1
    }

    private fun fillSlot(i: Int, uri: Uri) {
        if (i !in slotUris.indices) return
        val uris = slotUris
        val bmps = slotBmps
        uris[i] = uri
        cur = nextEmpty(i + 1)
        pushBooth()
        liveInfo.text = if (cur < 0) "All photos taken. Tap \u2714 to finish, or tap a photo to change it." else "Photo ${i + 1} saved. Next: window ${cur + 1}"
        pool.execute {
            val bm = try { TemplateTools.decodeCover(act, uri, 900, 900) } catch (_: Exception) { null }
            act.runOnUiThread { bmps[i] = bm; boothView.invalidate() }
        }
    }

    private fun onNewPhoto(u: Uri) {
        if (boothTpl == null || cur < 0) return
        fillSlot(cur, u)
    }

    private fun onSlotTap(i: Int) {
        if (i < 0) { capture(); return }
        if (slotUris.getOrNull(i) != null) { slotMenu(i); return }
        cur = i
        pushBooth()
        capture()
    }

    private fun darkDialog() = AlertDialog.Builder(act, android.R.style.Theme_Material_Dialog_Alert)

    private fun slotMenu(i: Int) {
        darkDialog().setTitle("Photo ${i + 1}")
            .setItems(arrayOf("Retake with camera", "Replace from transferred photos", "Remove photo")) { _, which ->
                when (which) {
                    0 -> { slotUris[i] = null; slotBmps[i] = null; cur = i; pushBooth(); liveInfo.text = "Tap the screen to retake photo ${i + 1}." }
                    1 -> pickTransferred { u -> slotUris[i] = null; slotBmps[i] = null; fillSlot(i, u) }
                    else -> { slotUris[i] = null; slotBmps[i] = null; if (cur < 0) cur = i; pushBooth() }
                }
            }.show()
    }

    private fun addPhotoToBooth() {
        if (boothTpl == null) { liveInfo.text = "Turn on the template (\uD83D\uDDBC) first."; return }
        if (cur < 0) { liveInfo.text = "All windows are filled. Tap a photo to replace it."; return }
        pickTransferred { u -> fillSlot(cur.coerceAtLeast(0), u) }
    }

    private fun restartBooth() {
        val t = boothTpl ?: return
        resetSlots(t)
        liveInfo.text = "New session. Tap the screen to take photo 1."
    }

    /** Pick one of the photos already transferred from the camera. */
    private fun pickTransferred(onPick: (Uri) -> Unit) {
        val d = Dialog(act, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG) }
        box.addView(Ui.label(act, "Choose a photo", 18f, Ui.TEXT, true), Ui.lp(act, -2, -2, top = 28, bottom = 8, side = 16))
        val g = GridView(act).apply { numColumns = 3; horizontalSpacing = Ui.dp(act, 3); verticalSpacing = Ui.dp(act, 3) }
        g.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int): Any = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
                val iv = (cv as? ImageView) ?: ImageView(act).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                val size = act.resources.displayMetrics.widthPixels / 3 - Ui.dp(act, 3)
                iv.layoutParams = AbsListView.LayoutParams(size, size)
                loadThumb(iv, items[p])
                return iv
            }
        }
        g.setOnItemClickListener { _, _, pos, _ -> d.dismiss(); onPick(items[pos]) }
        box.addView(g, LinearLayout.LayoutParams(-1, 0, 1f))
        box.addView(Ui.pill(act, "Cancel", Ui.CARD2) { d.dismiss() }, Ui.lp(act, -1, -2, top = 6, bottom = 10, side = 12))
        d.setContentView(box)
        d.show()
    }

    private fun finishBooth() {
        val t = boothTpl ?: run { liveInfo.text = "Turn on the template (\uD83D\uDDBC) first."; return }
        if (slotUris.all { it == null }) { liveInfo.text = "Take at least one photo first."; return }
        liveInfo.text = "Creating your photo..."
        val uris = slotUris.toList()
        val folder = CanonSyncService.folderOf(prefs)
        Thread {
            try {
                val bmp = TemplateTools.compose(act, t, uris)
                val uri = saveBooth(bmp, folder)
                bmp.recycle()
                act.runOnUiThread { boothDone(uri, t, folder) }
            } catch (e: Exception) {
                act.runOnUiThread { liveInfo.text = "Could not create the photo: ${e.message}" }
            }
        }.start()
    }

    private fun saveBooth(bmp: Bitmap, folder: String): Uri {
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Booth_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/$folder/Booth")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val coll = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = act.contentResolver.insert(coll, v) ?: throw IllegalStateException("Cannot create file")
        val out = act.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot write file")
        out.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        act.contentResolver.update(uri, done, null, null)
        return uri
    }

    /** Show the finished picture for the chosen time, print it, queue the Facebook upload. */
    private fun boothDone(uri: Uri, t: Template, folder: String) {
        loadGallery()
        resultUri = uri
        resultImage.setImageDrawable(null)
        resultInfo.text = "Saved in Pictures/$folder/Booth"
        resultPane.visibility = View.VISIBLE
        pool.execute {
            try {
                val bm = TemplateTools.decodeFit(act, uri, 2048, false)
                act.runOnUiThread { resultImage.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }
        if (prefs.getBoolean("auto_print", false)) printPicture(uri)
        if (photobooth && Cloud.prefs(act).getBoolean("fb_auto", false)) {
            CloudQueue.add(act, "fb", uri, Cloud.nameOf(act, uri))
            Uploader.kick(act)
        }
        resultLeft = prefs.getInt("preview_secs", 5)
        ui.removeCallbacks(resultTick)
        ui.post(resultTick)
    }

    private fun printPicture(uri: Uri) {
        val t = boothTpl
        Printing.print(act, prefs, uri, t == null || t.hPx >= t.wPx) { s -> resultInfo.text = s; liveInfo.text = s }
    }

    private fun dismissResult(reset: Boolean = true) {
        ui.removeCallbacks(resultTick)
        val wasShown = resultPane.visibility == View.VISIBLE
        resultPane.visibility = View.GONE
        resultImage.setImageDrawable(null)
        if (wasShown && reset && prefs.getBoolean("auto_reset", true)) boothTpl?.let { resetSlots(it) }
    }

    // ================================================================== lifecycle / USB

    fun onActivityResult(req: Int, res: Int, data: Intent?): Boolean = templatePane.onActivityResult(req, res, data)

    fun onCreate(intent: Intent?) {
        registerPermissionReceiver()
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        CanonSyncService.onChange = { act.runOnUiThread { refresh() } }
        CanonSyncService.onFrame = { bm ->
            act.runOnUiThread {
                if (CanonSyncService.liveWanted) {
                    if (boothTpl != null) { boothView.live = bm; boothView.invalidate() } else liveImage.setImageBitmap(bm)
                    livePlaceholder.visibility = View.GONE
                }
            }
        }
        if (photobooth) Uploader.onChange = { act.runOnUiThread { refresh() } }
        handleIntent(intent)
        refresh()
    }

    fun onNewIntent(intent: Intent?) = handleIntent(intent)

    fun onDestroy() {
        cancelCountdown()
        ui.removeCallbacks(resultTick)
        applyFullscreen(false)
        receiver?.let { try { act.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        CanonSyncService.onChange = null
        CanonSyncService.onFrame = null
        CanonSyncService.liveWanted = false
        Uploader.onChange = null
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect(CanonControl.deviceFrom(i))
    }

    fun connect(d: UsbDevice?) {
        val dev = d ?: CanonControl.findCamera(act)
        if (dev == null) {
            CanonSyncService.post("No camera found. Plug it in and switch it ON.")
            return
        }
        if (usb.hasPermission(dev)) {
            CanonControl.start(act, dev)
        } else {
            val pi = PendingIntent.getBroadcast(
                act, 0,
                Intent(CanonControl.ACTION_PERMISSION).setPackage(act.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usb.requestPermission(dev, pi)
        }
    }

    private fun registerPermissionReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val dev = CanonControl.deviceFrom(i)
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                    CanonControl.start(act, dev)
                } else {
                    CanonSyncService.post("USB permission not allowed. Tap Connect and choose Allow.")
                }
            }
        }
        receiver = r
        val f = IntentFilter(CanonControl.ACTION_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else act.registerReceiver(r, f)
    }

    fun refresh() {
        val s = CanonSyncService.status
        statusText.text = s
        val bad = s.startsWith("Error") || s.startsWith("Lost") || s.startsWith("Failed") ||
            s.startsWith("Cannot") || s.contains("not allowed") || s.startsWith("Camera could not")
        statusDot.background = Ui.shape(act, when {
            bad -> Ui.RED
            CanonSyncService.running -> Ui.GREEN
            else -> Ui.MUTED
        }, 0, true)
        statsText.text = "Copied this session: ${CanonSyncService.copied}   |   Folder: Pictures/${CanonSyncService.folderOf(prefs)}"
        if (photobooth) cloudText.text = "Cloud: ${CloudQueue.size(act)} waiting  |  ${Uploader.done} uploaded  |  ${Uploader.failed} failed" +
            (if (Uploader.status.isNotEmpty()) "\n${Uploader.status}" else "")
        printerText.text = Printing.label(prefs)
        if (tab == 2 && !counting && !s.startsWith("Copying") && !s.startsWith("Saved") && resultPane.visibility != View.VISIBLE) liveInfo.text = s

        val live = CanonSyncService.liveWanted
        liveBtn.text = if (live) "\u25A0" else "\u25B6"
        liveBtn.background = Ui.shape(act, if (live) Ui.RED else 0x66FFFFFF, 0, true)
        liveBadge.visibility = if (live) View.VISIBLE else View.GONE
        if (!live) livePlaceholder.visibility = if (boothTpl != null) View.GONE else View.VISIBLE
        val secs = prefs.getInt("timer", 0)
        timerBtn.text = if (secs > 0) "\u23F1 ${secs}s" else "\u23F1 off"
        timerBtn.background = Ui.shape(act, if (secs > 0) Ui.ACCENT else 0x99000000.toInt(), 22)
        val hasTpl = templatePane.active() != null
        templateBtn.visibility = if (hasTpl) View.VISIBLE else View.GONE
        templateBtn.background = Ui.shape(act, if (boothTpl != null) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        val booth = boothTpl != null
        addBtn.visibility = if (booth) View.VISIBLE else View.GONE
        finishBtn.visibility = if (booth) View.VISIBLE else View.GONE
        restartBtn.visibility = if (booth) View.VISIBLE else View.GONE
        val full = prefs.getBoolean("live_full", true)
        fullBtn.background = Ui.shape(act, if (full) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        val fill = prefs.getBoolean("live_fill", true)
        fillBtn.background = Ui.shape(act, if (fill) Ui.ACCENT else 0x99000000.toInt(), 0, true)
        liveImage.scaleType = if (fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER

        val seq = CanonSyncService.lastSavedSeq
        if (seq != lastSeq) {
            lastSeq = seq
            CanonSyncService.lastSavedUri?.let { onNewPhoto(it) }
        }
        if (CanonSyncService.copied != lastCopied) {
            lastCopied = CanonSyncService.copied
            loadGallery()
        }
    }
}
