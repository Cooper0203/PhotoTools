package com.phototools.app

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.widget.CheckBox
import android.widget.LinearLayout

/** The "camera cable -> phone" screen part. Used by the Canon app and the combined app. */
class CanonSection(private val act: Activity, private val showQueueOption: Boolean) {
    val view = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
    var extraChange: (() -> Unit)? = null
    private val prefs = act.getSharedPreferences("canon", Context.MODE_PRIVATE)
    private val usb = act.getSystemService(Context.USB_SERVICE) as UsbManager
    private val statusView = Ui.text(act, "", 16f)
    private var receiver: BroadcastReceiver? = null

    init {
        view.addView(Ui.text(act, "Canon 760D - Auto Copy", 22f, true))
        view.addView(statusView)
        view.addView(CheckBox(act).apply {
            text = "Also copy photos already on the card"
            isChecked = prefs.getBoolean("import_existing", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("import_existing", on).apply() }
        })
        if (showQueueOption) {
            view.addView(CheckBox(act).apply {
                text = "Add new camera photos to the Facebook list"
                isChecked = prefs.getBoolean("auto_queue", false)
                setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("auto_queue", on).apply() }
            })
        }
        view.addView(Ui.button(act, "Connect camera now") { connect(null) })
        view.addView(Ui.text(act,
            "1. Switch the camera ON (turn Auto power off to Disable in camera menu).\n" +
            "2. Plug the USB cable: camera -> phone (use an OTG adapter if needed).\n" +
            "3. Tap Allow / Always open with this app.\n" +
            "4. Take photos. Each one is copied within a few seconds to Pictures/Canon760D.\n" +
            "Works offline. Camera originals are never deleted.", 13f))
    }

    fun onCreate(intent: Intent?) {
        registerPermissionReceiver()
        if (Build.VERSION.SDK_INT >= 33 &&
            act.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) act.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        CanonSyncService.onChange = { act.runOnUiThread { refresh(); extraChange?.invoke() } }
        handleIntent(intent)
        refresh()
    }

    fun onNewIntent(intent: Intent?) = handleIntent(intent)

    fun onDestroy() {
        receiver?.let { try { act.unregisterReceiver(it) } catch (_: Exception) {} }
        receiver = null
        CanonSyncService.onChange = null
    }

    private fun handleIntent(i: Intent?) {
        if (i != null && i.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) connect(CanonControl.deviceFrom(i))
    }

    fun connect(d: UsbDevice?) {
        val dev = d ?: CanonControl.findCamera(act)
        if (dev == null) {
            CanonSyncService.post("No camera found. Plug it in, switch it ON, set USB to PTP.")
            return
        }
        if (usb.hasPermission(dev)) {
            CanonControl.start(act, dev)
        } else {
            val pi = PendingIntent.getBroadcast(
                act, 0,
                Intent(CanonControl.ACTION_PERMISSION).setPackage(act.packageName),
                PendingIntent.FLAG_MUTABLE
            )
            usb.requestPermission(dev, pi)
        }
    }

    private fun registerPermissionReceiver() {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                if (i == null) return
                val dev = CanonControl.deviceFrom(i)
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && dev != null) {
                    CanonControl.start(act, dev)
                } else {
                    CanonSyncService.post("USB permission not allowed. Tap Connect and choose Allow.")
                }
            }
        }
        receiver = r
        val f = IntentFilter(CanonControl.ACTION_PERMISSION)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED)
        else act.registerReceiver(r, f)
    }

    fun refresh() {
        statusView.text = "Status: ${CanonSyncService.status}\n" +
            "Copied this session: ${CanonSyncService.copied}\n" +
            "Saved in: Pictures/Canon760D (videos: Movies/Canon760D, RAW: Download/Canon760D)"
    }
}
