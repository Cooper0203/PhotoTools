package com.phototools.app

import android.app.Activity
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView

/** First screen: what should this device do? */
object RoleScreen {
    fun build(act: Activity, title: String, onPick: (Int, Boolean) -> Unit): View {
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(act, 20), Ui.dp(act, 40), Ui.dp(act, 20), Ui.dp(act, 24))
        }
        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(ImageView(act).apply { setImageResource(R.drawable.logo) }, Ui.lp(act, Ui.dp(act, 56), Ui.dp(act, 56)))
        val t = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        t.addView(Ui.label(act, title, 22f, Ui.TEXT, true))
        t.addView(Ui.label(act, "What should this device do?", 14f, Ui.MUTED))
        head.addView(t, Ui.lp(act, 0, -2, 1f, side = 12))
        col.addView(head, Ui.lp(act, -1, -2, bottom = 16))

        val remember = CheckBox(act).apply {
            text = "Remember my choice (change it later in Settings)"
            setTextColor(Ui.TEXT)
            textSize = 13f
            isChecked = Roles.app(act).getBoolean("role_remember", false)
        }
        val options = listOf(
            Triple(Roles.FULL, "\uD83C\uDF9B  Full operation", "Camera, live view, templates, printing and uploads on this device. Works on its own."),
            Triple(Roles.OPERATOR, "\uD83D\uDCF7  Camera operator only", "Operate the camera: live view, countdown, templates and gallery. Photos are sent to a server device over Wi-Fi or hotspot."),
            Triple(Roles.SERVER, "\uD83D\uDDA5  Server device only", "Receives files from operators, keeps them, prints and uploads. No camera controls.")
        )
        for ((role, name, desc) in options) {
            val card = Ui.card(act)
            card.isClickable = true
            card.addView(Ui.label(act, name, 17f, Ui.TEXT, true))
            card.addView(Ui.label(act, desc, 13f, Ui.MUTED), Ui.lp(act, -2, -2, top = 4))
            card.setOnClickListener { onPick(role, remember.isChecked) }
            col.addView(card, Ui.lp(act, -1, -2, bottom = 12))
        }
        col.addView(remember, Ui.lp(act, -1, -2, top = 4))
        return ScrollView(act).apply { setBackgroundColor(Ui.BG); addView(col); setBackgroundColor(Color.parseColor("#0B0F17")) }
    }
}
