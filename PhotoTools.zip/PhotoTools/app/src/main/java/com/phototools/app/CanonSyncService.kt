package com.phototools.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.mtp.MtpConstants
import android.mtp.MtpDevice
import android.mtp.MtpObjectInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import android.provider.MediaStore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Talks to the camera (PTP/MTP over USB), watches for NEW pictures every ~1.5 s
 * and copies each one to the phone right after it is taken. Works fully offline.
 */
class CanonSyncService : Service() {

    companion object {
        private const val CHANNEL = "canon_sync"
        @Volatile var status: String = "Camera not connected."
        @Volatile var copied: Int = 0
        @Volatile var running: Boolean = false
        @Volatile var onChange: (() -> Unit)? = null
        @Volatile var liveWanted: Boolean = false
        @Volatile var shootRequested: Boolean = false
        @Volatile var lastSavedUri: Uri? = null
        @Volatile var lastSavedSeq: Int = 0
        @Volatile var onSaved: ((Uri, String) -> Unit)? = null

        /** Folder name chosen by the user (letters, digits, space, - _ . only). */
        fun folderOf(p: SharedPreferences): String {
            val raw = (p.getString("folder", "Canon760D") ?: "").replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().take(40)
            return if (raw.isEmpty()) "Canon760D" else raw
        }
        @Volatile var onFrame: ((Bitmap) -> Unit)? = null
        fun post(s: String) { status = s; onChange?.invoke() }
    }

    private val usb by lazy { getSystemService(Context.USB_SERVICE) as UsbManager }
    private val prefs by lazy { getSharedPreferences("canon", Context.MODE_PRIVATE) }
    private var worker: Thread? = null
    private var detachReceiver: BroadcastReceiver? = null
    @Volatile private var stopFlag = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel(CHANNEL, "Camera sync", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, notif("Starting..."), ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        val device = intent?.let { CanonControl.deviceFrom(it) } ?: CanonControl.findCamera(this)
        if (device == null) {
            post("No camera found. Plug it in, switch it ON, set USB to PTP.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (worker?.isAlive == true) return START_NOT_STICKY
        registerDetach()
        stopFlag = false
        worker = Thread { sync(device) }.also { it.start() }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopFlag = true
        worker?.interrupt()
        detachReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        detachReceiver = null
        super.onDestroy()
    }

    private fun registerDetach() {
        if (detachReceiver != null) return
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                post("Camera unplugged. Plug it in again to continue.")
                stopFlag = true
                worker?.interrupt()
            }
        }
        detachReceiver = r
        val f = IntentFilter(UsbManager.ACTION_USB_DEVICE_DETACHED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(r, f)
    }

    private fun sync(device: UsbDevice) {
        val wl = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "phototools:canon")
        wl.acquire()
        var opened: MtpDevice? = null
        try {
            val conn = usb.openDevice(device)
            if (conn == null) {
                post("Cannot open the camera. Allow USB access, set camera USB to PTP, then replug.")
                return
            }
            val ptp = PtpClient.open(conn, device)
            if (ptp != null) {
                val handled = try { runCanonEos(ptp, device) } catch (e: Exception) {
                    post("Camera link error: ${e.message}"); true
                }
                if (handled) return
                ptp.release()
            }
            val mtp = MtpDevice(device)
            if (!mtp.open(conn)) {
                conn.close()
                post("Camera did not answer. Switch it on and replug the cable.")
                return
            }
            opened = mtp
            val storages = mtp.storageIds
            if (storages == null || storages.isEmpty()) {
                post("Camera has no memory card (or is not in PTP mode).")
                return
            }
            running = true
            post("Connected: ${device.productName ?: "camera"}. Take a photo!")
            updateNote("Connected - waiting for new photos")

            val seen = HashSet<Int>()
            val pending = HashMap<Int, Long>()
            val folders = ArrayList<Pair<Int, Int>>()
            for (s in storages) folders.add(Pair(s, -1))

            // First pass: either import everything already on the card, or just remember it.
            scan(mtp, folders, seen, pending, true, prefs.getBoolean("import_existing", false))

            var failures = 0
            while (!stopFlag) {
                try { Thread.sleep(1500) } catch (e: InterruptedException) { break }
                try {
                    if (mtp.storageIds == null) throw IllegalStateException("camera gone")
                    scan(mtp, folders, seen, pending, false, true)
                    failures = 0
                } catch (e: Exception) {
                    failures++
                    if (failures >= 6) { post("Lost the camera. Replug the cable."); break }
                }
            }
        } catch (e: Exception) {
            post("Error: ${e.message}")
        } finally {
            running = false
            liveWanted = false
            shootRequested = false
            try { opened?.close() } catch (_: Exception) {}
            if (wl.isHeld) wl.release()
            stopSelf()
        }
    }

    private fun scan(
        m: MtpDevice,
        folders: ArrayList<Pair<Int, Int>>,
        seen: HashSet<Int>,
        pending: HashMap<Int, Long>,
        first: Boolean,
        copyExisting: Boolean
    ) {
        var i = 0
        while (i < folders.size) {
            val storage = folders[i].first
            val parent = folders[i].second
            i++
            var handles = m.getObjectHandles(storage, 0, parent)
            if (handles == null && parent == -1) handles = m.getObjectHandles(storage, 0, 0)
            if (handles == null) continue
            for (h in handles) {
                if (h in seen) continue
                val info = m.getObjectInfo(h) ?: continue
                if (info.format == MtpConstants.FORMAT_ASSOCIATION) {
                    seen.add(h)
                    folders.add(Pair(storage, h))
                    continue
                }
                if (first && !copyExisting) { seen.add(h); continue }
                val size = info.compressedSizeLong
                // A new file is copied once its size stopped changing (camera finished writing it).
                if (first || pending[h] == size) {
                    copyOne(m, info)
                    seen.add(h)
                    pending.remove(h)
                } else {
                    pending[h] = size
                }
            }
        }
    }

    private fun isWanted(name: String): Boolean =
        name.substringAfterLast('.', "").lowercase() in listOf("jpg", "jpeg", "png", "heic", "cr2", "cr3", "mp4", "mov")

    private fun copyOne(m: MtpDevice, info: MtpObjectInfo): Boolean {
        val name = info.name ?: "IMG_${info.objectHandle}.JPG"
        if (!isWanted(name)) return true
        val key = "$name|${info.compressedSizeLong}|${info.dateCreated}"
        if (alreadyCopied(key)) return true
        val tmp = File(cacheDir, "mtp_${info.objectHandle}.tmp")
        try {
            post("Copying $name ...")
            updateNote("Copying $name")
            if (!m.importFile(info.objectHandle, tmp.absolutePath)) {
                post("Could not read $name from the camera.")
                return false
            }
            return commit(name, key, tmp, info.dateCreated)
        } catch (e: Exception) {
            post("Failed: $name - ${e.message}")
            return false
        } finally {
            tmp.delete()
        }
    }

    private fun alreadyCopied(key: String): Boolean =
        key in (prefs.getStringSet("copied", emptySet()) ?: emptySet())

    private fun commit(name: String, key: String, tmp: File, takenMs: Long): Boolean {
        val done = prefs.getStringSet("copied", emptySet()) ?: emptySet()
        val saved = save(name, tmp, takenMs)
        prefs.edit().putStringSet("copied", HashSet(done).apply { add(key) }).apply()
        copied++
        if (saved.second.startsWith("image/")) { lastSavedUri = saved.first; lastSavedSeq++ }
        if (prefs.getBoolean("auto_queue", false) &&
            (saved.second.startsWith("image/") || saved.second.startsWith("video/"))
        ) UploadQueue.addAll(this, listOf(saved.first))
        post("Saved $name  (copied this session: $copied)")
        updateNote("Saved $name")
        onSaved?.invoke(saved.first, saved.second)
        return true
    }

    // ---------- Canon EOS real-time mode (camera shutter works, new photos are announced by the camera) ----------

    private fun runCanonEos(p: PtpClient, device: UsbDevice): Boolean {
        if (!p.openSession()) return false
        if (!p.ok(0x9114, 1)) { p.closeSession(); return false }   // SetRemoteMode
        p.ok(0x9115, 1)                                              // SetEventMode
        running = true
        post("Connected (Canon mode): ${device.productName ?: "camera"}. Take a photo with the camera!")
        updateNote("Connected - waiting for new photos")
        try { p.events() } catch (e: java.io.IOException) { throw e } catch (_: Exception) {}
        if (prefs.getBoolean("import_existing", false)) importAll(p)

        var liveOn = false
        var lastEv = 0L
        var failures = 0
        try {
            while (!stopFlag) {
                try {
                    if (shootRequested) {
                        shootRequested = false
                        post(if (p.shoot()) "Photo taken - transferring..." else "Camera could not take the photo (no focus, busy or card full).")
                    }
                    if (CanonSyncService.liveWanted) {
                        if (!liveOn) {
                            p.setProp(0xD1B3, 1)
                            liveOn = p.setProp(0xD1B0, 2)
                            if (!liveOn) { post("Live view not available right now."); liveWanted = false }
                            else Thread.sleep(600)
                        } else {
                            val jpg = p.liveFrame()
                            if (jpg != null) {
                                val bm = BitmapFactory.decodeByteArray(jpg, 0, jpg.size)
                                if (bm != null) onFrame?.invoke(bm)
                            }
                        }
                    } else if (liveOn) {
                        p.setProp(0xD1B0, 0)
                        liveOn = false
                    }
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastEv >= (if (liveOn) 800 else 400)) {
                        lastEv = now
                        val ev = p.events()
                        if (ev != null) for (h in PtpClient.objectEvents(ev)) downloadEos(p, h)
                    }
                    failures = 0
                    Thread.sleep(if (liveOn) 40 else 100)
                } catch (e: InterruptedException) {
                    break
                } catch (e: Exception) {
                    failures++
                    if (failures >= 8) { post("Lost the camera: ${e.message}. Replug the cable."); break }
                    try { Thread.sleep(300) } catch (_: InterruptedException) { break }
                }
            }
        } finally {
            try { if (liveOn) p.setProp(0xD1B0, 0) } catch (_: Exception) {}
            try { p.ok(0x9114, 0) } catch (_: Exception) {}
            p.closeSession()
            p.release()
        }
        return true
    }

    private fun importAll(p: PtpClient) {
        post("Importing photos already on the card ...")
        val stack = ArrayList<Pair<Int, Int>>()
        for (s in p.storageIds()) stack.add(Pair(s, -1))
        var i = 0
        while (i < stack.size && !stopFlag) {
            val st = stack[i].first
            val parent = stack[i].second
            i++
            for (h in p.handles(st, parent)) {
                if (stopFlag) return
                val info = p.objectInfo(h) ?: continue
                if (info.format == 0x3001) stack.add(Pair(st, h)) else downloadEos(p, h)
            }
        }
        post("Existing photos done. Take a photo!")
    }

    private fun downloadEos(p: PtpClient, h: Int) {
        var info: PtpClient.Info? = null
        for (t in 0 until 5) {
            info = p.objectInfo(h)
            if (info != null) break
            Thread.sleep(300)
        }
        val name = info?.name?.takeIf { it.isNotBlank() } ?: "IMG_$h.JPG"
        if (!isWanted(name)) return
        val key = "$name|${info?.size ?: 0}"
        if (alreadyCopied(key)) return
        val tmp = File(cacheDir, "eos_$h.tmp")
        try {
            post("Copying $name ...")
            updateNote("Copying $name")
            var ok = false
            for (t in 0 until 4) {
                tmp.delete()
                ok = FileOutputStream(tmp).use { p.getObject(h, it) }
                if (ok) break
                Thread.sleep(600)
            }
            if (!ok) { post("Could not download $name"); return }
            commit(name, key, tmp, System.currentTimeMillis())
        } catch (e: InterruptedException) {
            throw e
        } catch (e: java.io.IOException) {
            throw e
        } catch (e: Exception) {
            post("Failed: $name - ${e.message}")
        } finally {
            tmp.delete()
        }
    }

    /** Saves into Pictures/Canon760D, Movies/Canon760D or Download/Canon760D. No storage permission needed. */
    private fun save(name: String, file: File, takenMs: Long): Pair<Uri, String> {
        val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
        val folder = folderOf(prefs)
        val ext = name.substringAfterLast('.', "").lowercase()
        val target: Triple<Uri, String, String> = when (ext) {
            "jpg", "jpeg" -> Triple(MediaStore.Images.Media.getContentUri(vol), "image/jpeg", "Pictures/$folder")
            "png" -> Triple(MediaStore.Images.Media.getContentUri(vol), "image/png", "Pictures/$folder")
            "heic" -> Triple(MediaStore.Images.Media.getContentUri(vol), "image/heic", "Pictures/$folder")
            "mp4" -> Triple(MediaStore.Video.Media.getContentUri(vol), "video/mp4", "Movies/$folder")
            "mov" -> Triple(MediaStore.Video.Media.getContentUri(vol), "video/quicktime", "Movies/$folder")
            else -> Triple(MediaStore.Downloads.getContentUri(vol), "application/octet-stream", "Download/$folder")
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, target.second)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.third)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
            if (takenMs > 0) put(MediaStore.MediaColumns.DATE_TAKEN, takenMs)
        }
        val uri = contentResolver.insert(target.first, v) ?: throw IllegalStateException("Cannot create file")
        val out = contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Cannot write file")
        out.use { o -> FileInputStream(file).use { it.copyTo(o) } }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return Pair(uri, target.second)
    }

    private fun notif(text: String): Notification =
        Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Canon Auto Copy")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNote(t: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, notif(t))
    }
}
