package com.phototools.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.Looper
import android.os.IBinder

/** Keeps the upload queue running when the app is in the background or the screen is off. */
class UploadService : Service() {
    companion object {
        @Volatile private var running = false
        @Volatile private var starting = false

        fun start(c: Context) {
            try { starting = true; c.startForegroundService(Intent(c, UploadService::class.java)) } catch (_: Exception) { starting = false }
        }

        /** Stops the service only once it has really started (stopping too early crashes the app). */
        fun stop(c: Context) {
            val h = Handler(Looper.getMainLooper())
            var tries = 0
            val r = object : Runnable {
                override fun run() {
                    if (running) {
                        try { c.stopService(Intent(c, UploadService::class.java)) } catch (_: Exception) {}
                        starting = false
                    } else if (starting && ++tries < 30) {
                        h.postDelayed(this, 500)
                    }
                }
            }
            h.post(r)
        }

        fun note(c: Context, text: String) {
            if (!running) return
            try { (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(3, build(c, text)) } catch (_: Exception) {}
        }

        private fun build(c: Context, text: String): Notification =
            Notification.Builder(c, "uploads")
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle("Uploading photos")
                .setContentText(text)
                .setOngoing(true)
                .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("uploads", "Uploads", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        running = true
        startForeground(3, build(this, "Working through the upload queue"), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }
}
