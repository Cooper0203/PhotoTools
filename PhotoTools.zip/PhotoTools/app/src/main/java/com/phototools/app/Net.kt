package com.phototools.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.net.URLDecoder
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Collections
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Which job this device does: everything, only the camera, or only receiving / printing / uploading. */
object Roles {
    const val FULL = 0
    const val OPERATOR = 1
    const val SERVER = 2
    fun app(c: Context): SharedPreferences = c.getSharedPreferences("app", Context.MODE_PRIVATE)
    fun get(c: Context): Int = app(c).getInt("role", -1)
    fun remembered(c: Context): Boolean = app(c).getBoolean("role_remember", false) && get(c) >= 0
    fun set(c: Context, role: Int, remember: Boolean) {
        app(c).edit().putInt("role", role).putBoolean("role_remember", remember).apply()
    }
}

object NetPrefs {
    const val DEFAULT_PORT = 8765
    fun p(c: Context): SharedPreferences = c.getSharedPreferences("net", Context.MODE_PRIVATE)

    fun clean(raw: String, def: String): String {
        val r = raw.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().take(30)
        return if (r.isEmpty()) def else r
    }

    fun deviceId(c: Context): String {
        var s = p(c).getString("dev_id", "") ?: ""
        if (s.isEmpty()) { s = java.util.UUID.randomUUID().toString().take(8); p(c).edit().putString("dev_id", s).apply() }
        return s
    }

    fun code(c: Context): String {
        var s = p(c).getString("srv_code", "") ?: ""
        if (s.isEmpty()) { s = (1000 + java.util.Random().nextInt(9000)).toString(); p(c).edit().putString("srv_code", s).apply() }
        return s
    }

    /** Name shown to the other device (operator name, or server name). */
    fun deviceName(c: Context): String = clean(p(c).getString("dev_name", "") ?: "", clean(Build.MODEL ?: "", "Device"))
    fun srvFolder(c: Context): String = clean(p(c).getString("srv_folder", "") ?: "", "Photobooth Server")
}

object NetInfo {
    fun addresses(): List<String> {
        val out = ArrayList<String>()
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) out.add("${a.hostAddress}  (${ni.name})")
                }
            }
        } catch (_: Exception) {}
        return out
    }
}

class OperatorInfo(val id: String, var name: String, var ip: String, var lastSeen: Long, var files: Int, var last: String)

object ServerState {
    val ops = ConcurrentHashMap<String, OperatorInfo>()
    val log = ArrayDeque<String>()
    @Volatile var running = false
    @Volatile var error = ""
    @Volatile var onChange: (() -> Unit)? = null

    fun online(o: OperatorInfo) = System.currentTimeMillis() - o.lastSeen < 12000

    @Synchronized
    fun event(s: String) {
        log.addFirst(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + s)
        while (log.size > 12) log.removeLast()
        onChange?.invoke()
    }

    @Synchronized
    fun lines(): List<String> = log.toList()

    fun load(c: Context) {
        if (ops.isNotEmpty()) return
        try {
            val arr = JSONArray(NetPrefs.p(c).getString("ops", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                ops[o.getString("id")] = OperatorInfo(o.getString("id"), o.getString("name"), "", 0L, o.optInt("files", 0), "")
            }
        } catch (_: Exception) {}
    }

    private fun save(c: Context) {
        val arr = JSONArray()
        for (o in ops.values) arr.put(JSONObject().put("id", o.id).put("name", o.name).put("files", o.files))
        NetPrefs.p(c).edit().putString("ops", arr.toString()).apply()
    }

    fun touch(c: Context, id: String, name: String, ip: String) {
        val o = ops.getOrPut(id) { OperatorInfo(id, name, ip, 0L, 0, "") }
        val was = online(o)
        val renamed = o.name != name
        o.name = name
        o.ip = ip
        o.lastSeen = System.currentTimeMillis()
        if (!was) { event("$name connected"); save(c) } else if (renamed) save(c)
    }

    fun received(c: Context, id: String, name: String, file: String) {
        val o = ops[id] ?: return
        o.files++
        o.last = file
        save(c)
        event("$name: $file")
    }
}

/** Tiny HTTP server: operators send photos here. */
class PhotoServer(private val ctx: Context, private val port: Int) {
    private var ss: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var stopped = false

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(java.net.InetSocketAddress(port))
        ss = s
        Thread {
            while (!stopped) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (_: IOException) { if (stopped) break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        stopped = true
        try { ss?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    private fun readLine(ins: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = ins.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == 10) break
            if (b != 13) sb.append(b.toChar())
            if (sb.length > 8192) throw IOException("line too long")
        }
        return sb.toString()
    }

    private fun reply(out: OutputStream, status: Int, body: String) = replyBytes(out, status, "application/json", body.toByteArray())

    private fun replyBytes(out: OutputStream, status: Int, type: String, body: ByteArray) {
        val text = when (status) { 200 -> "OK"; 403 -> "Forbidden"; 404 -> "Not Found"; else -> "Error" }
        out.write("HTTP/1.1 $status $text\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(body)
        out.flush()
    }

    private fun handle(s: Socket) {
        try {
            s.soTimeout = 60000
            val ins = BufferedInputStream(s.getInputStream(), 64 * 1024)
            val out = s.getOutputStream()
            val first = readLine(ins) ?: return
            val parts = first.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val target = parts[1]
            var len = 0L
            while (true) {
                val h = readLine(ins) ?: break
                if (h.isEmpty()) break
                if (h.lowercase().startsWith("content-length:")) len = h.substringAfter(':').trim().toLongOrNull() ?: 0L
            }
            val path = target.substringBefore('?')
            val q = HashMap<String, String>()
            for (kv in target.substringAfter('?', "").split('&')) {
                if (kv.isEmpty()) continue
                q[URLDecoder.decode(kv.substringBefore('='), "UTF-8")] = URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8")
            }
            if (q["code"] != NetPrefs.code(ctx)) { reply(out, 403, "{\"ok\":false,\"error\":\"wrong code\"}"); return }
            val id = q["id"] ?: "?"
            val name = NetPrefs.clean(q["name"] ?: "", "Operator")
            ServerState.touch(ctx, id, name, s.inetAddress?.hostAddress ?: "")
            when {
                method == "GET" && path == "/ping" ->
                    reply(out, 200, JSONObject().put("ok", true).put("server", NetPrefs.deviceName(ctx)).toString())
                method == "POST" && path == "/upload" -> upload(ins, out, q, name, id, len)
                method == "GET" && path == "/templates" -> {
                    val f = File(ctx.filesDir, "templates.json")
                    reply(out, 200, if (f.exists()) f.readText() else "[]")
                }
                method == "GET" && path == "/overlay" -> {
                    val tid = (q["tid"] ?: "").filter { it.isLetterOrDigit() }
                    val f = TemplateStore.overlayFile(ctx, tid)
                    if (f.exists()) replyBytes(out, 200, "image/png", f.readBytes()) else reply(out, 404, "{}")
                }
                else -> reply(out, 404, "{\"ok\":false}")
            }
        } catch (e: Exception) {
            ServerState.event("Error: ${e.message}")
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }

    private fun upload(ins: InputStream, out: OutputStream, q: Map<String, String>, opName: String, id: String, len: Long) {
        val kind = if (q["kind"] == "f") "f" else "o"
        val fname = (q["fname"] ?: "file_${System.currentTimeMillis()}").replace(Regex("[^A-Za-z0-9 _.()-]"), "_")
        val mime = q["mime"] ?: "application/octet-stream"
        val uri = try {
            saveIncoming(opName, kind, fname, mime, ins, len)
        } catch (e: Exception) {
            reply(out, 500, "{\"ok\":false}")
            ServerState.event("Could not save $fname: ${e.message}")
            return
        }
        reply(out, 200, "{\"ok\":true}")
        ServerState.received(ctx, id, opName, fname)
        afterSave(uri, opName, kind, fname, mime)
    }

    private fun saveIncoming(op: String, kind: String, fname: String, mime: String, ins: InputStream, len: Long): Uri {
        val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
        val ext = fname.substringAfterLast('.', "").lowercase()
        val base = NetPrefs.srvFolder(ctx)
        val opDir = NetPrefs.clean(op, "Operator")
        val sub = if (kind == "f") "Templates" else "Originals"
        val coll: Uri
        val type: String
        val rel: String
        when (ext) {
            "jpg", "jpeg", "png", "heic" -> {
                coll = MediaStore.Images.Media.getContentUri(vol)
                type = if (ext == "png") "image/png" else if (ext == "heic") "image/heic" else "image/jpeg"
                rel = "Pictures/$base/$opDir/$sub"
            }
            "mp4", "mov" -> {
                coll = MediaStore.Video.Media.getContentUri(vol)
                type = if (ext == "mov") "video/quicktime" else "video/mp4"
                rel = "Movies/$base/$opDir"
            }
            else -> {
                coll = MediaStore.Downloads.getContentUri(vol)
                type = "application/octet-stream"
                rel = "Download/$base/$opDir"
            }
        }
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fname)
            put(MediaStore.MediaColumns.MIME_TYPE, type)
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(coll, v) ?: throw IOException("Cannot create file")
        try {
            val o = ctx.contentResolver.openOutputStream(uri) ?: throw IOException("Cannot write file")
            o.use {
                val buf = ByteArray(64 * 1024)
                var left = len
                while (left > 0) {
                    val n = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw IOException("Transfer cut off")
                    it.write(buf, 0, n)
                    left -= n
                }
            }
        } catch (e: Exception) {
            try { ctx.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
            throw e
        }
        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        ctx.contentResolver.update(uri, done, null, null)
        return uri
    }

    /** Same extras as on a single device: print, upload, back up, copy to the drive. */
    private fun afterSave(uri: Uri, op: String, kind: String, fname: String, mime: String) {
        try {
            val cp = ctx.getSharedPreferences("canon", Context.MODE_PRIVATE)
            val cl = Cloud.prefs(ctx)
            if (kind == "f" && SafDrive.wantsFinals(ctx)) CloudQueue.add(ctx, "saf", uri, fname)
            if (kind != "f" && SafDrive.wantsOriginals(ctx)) CloudQueue.add(ctx, "saf", uri, fname)
            if (kind == "f") {
                if (cp.getBoolean("auto_print", false)) Printing.printHeadless(ctx, cp, uri) { s -> ServerState.event(s) }
                if (cl.getBoolean("fb_auto", false)) CloudQueue.add(ctx, "fb", uri, fname, true)
                if (cl.getBoolean("hook_auto", false)) CloudQueue.add(ctx, "hook", uri, fname)
                if (cl.getBoolean("qr_drive", false) || cl.getBoolean("drive_final", false)) CloudQueue.add(ctx, "drivepub", uri, fname)
            } else if (cl.getBoolean("drive_auto", false)) {
                CloudQueue.add(ctx, "drive", uri, fname)
            }
            if (cp.getBoolean("ext_auto", false) && ExternalCopy.tree(cp) != null) {
                if (!ExternalCopy.copy(ctx, cp, uri, "${op}_$fname", mime)) ServerState.event("Could not copy $fname to the drive")
            }
            if (CloudQueue.size(ctx) > 0) Uploader.kick(ctx)
        } catch (e: Exception) {
            ServerState.event("Extras failed: ${e.message}")
        }
    }
}

/** Keeps the server running (screen off, app in the background). */
class ServerService : Service() {
    companion object {
        fun start(c: Context) { c.startForegroundService(Intent(c, ServerService::class.java)) }
        fun stop(c: Context) { c.stopService(Intent(c, ServerService::class.java)) }
    }

    private var server: PhotoServer? = null
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var nsd: NsdManager? = null
    private var reg: NsdManager.RegistrationListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = NotificationChannel("server", "Photo server", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notification.Builder(this, "server")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Photo server")
            .setContentText("Receiving photos from operators")
            .setOngoing(true)
            .build()
        startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (server == null) {
            ServerState.load(this)
            try {
                val port = NetPrefs.DEFAULT_PORT
                val s = PhotoServer(this, port)
                s.start()
                server = s
                ServerState.running = true
                ServerState.error = ""
                wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "photobooth:server").also { it.acquire() }
                wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                    .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "photobooth:server").also { it.acquire() }
                register(port)
                ServerState.event("Server started on port $port")
            } catch (e: Exception) {
                ServerState.running = false
                ServerState.error = e.message ?: "cannot start"
                ServerState.event("Server could not start: ${e.message}")
            }
        }
        return START_STICKY
    }

    private fun register(port: Int) {
        try {
            val m = getSystemService(Context.NSD_SERVICE) as NsdManager
            val info = NsdServiceInfo().apply {
                serviceName = "Photobooth " + NetPrefs.deviceName(this@ServerService)
                serviceType = "_photobooth._tcp"
                setPort(port)
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(s: NsdServiceInfo?, e: Int) {}
                override fun onUnregistrationFailed(s: NsdServiceInfo?, e: Int) {}
                override fun onServiceRegistered(s: NsdServiceInfo?) {}
                override fun onServiceUnregistered(s: NsdServiceInfo?) {}
            }
            m.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
            nsd = m
            reg = l
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        try { reg?.let { nsd?.unregisterService(it) } } catch (_: Exception) {}
        server?.stop()
        server = null
        ServerState.running = false
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) {}
        try { if (wifi?.isHeld == true) wifi?.release() } catch (_: Exception) {}
        ServerState.event("Server stopped")
        super.onDestroy()
    }
}

/** Operator side: talks to the server device. */
object ServerClient {
    @Volatile var connected = false
    @Volatile var serverName = ""
    @Volatile var error = ""
    @Volatile var onChange: (() -> Unit)? = null
    private var hb: Thread? = null
    @Volatile private var hbRun = false

    private fun np(c: Context) = NetPrefs.p(c)

    fun hostPort(c: Context): Pair<String, Int>? {
        val raw = (np(c).getString("cl_host", "") ?: "").trim()
        if (raw.isEmpty()) return null
        return Pair(raw.substringBefore(':'), raw.substringAfter(':', "").toIntOrNull() ?: NetPrefs.DEFAULT_PORT)
    }

    fun configured(c: Context) = hostPort(c) != null
    fun enabled(c: Context): Boolean = configured(c) && (Roles.get(c) == Roles.OPERATOR || np(c).getBoolean("cl_on", false))
    fun wantsOriginals(c: Context) = enabled(c) && np(c).getBoolean("cl_orig", true)
    fun wantsFinals(c: Context) = enabled(c) && np(c).getBoolean("cl_final", true)

    private fun url(c: Context, path: String, extra: String = ""): String {
        val hp = hostPort(c) ?: throw IOException("Server address not set")
        return "http://${hp.first}:${hp.second}$path?code=${Cloud.enc(np(c).getString("cl_code", "") ?: "")}" +
            "&id=${Cloud.enc(NetPrefs.deviceId(c))}&name=${Cloud.enc(NetPrefs.deviceName(c))}$extra"
    }

    /** Returns null when the server answered, otherwise a short error. */
    fun ping(c: Context): String? = try {
        val h = Cloud.request(url(c, "/ping"), "GET")
        when (h.code) {
            200 -> { serverName = JSONObject(h.body).optString("server"); null }
            403 -> "Wrong pairing code"
            else -> "Server answered ${h.code}"
        }
    } catch (e: Exception) { e.message ?: "no connection" }

    @Synchronized
    fun startHeartbeat(ctx: Context) {
        if (hb?.isAlive == true) return
        val app = ctx.applicationContext
        hbRun = true
        hb = Thread {
            while (hbRun) {
                if (configured(app)) {
                    val err = ping(app)
                    val was = connected
                    connected = err == null
                    error = err ?: ""
                    if (was != connected) onChange?.invoke()
                    if (connected && !was) Uploader.kick(app)
                } else if (connected) { connected = false; onChange?.invoke() }
                try { Thread.sleep(4000) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stopHeartbeat() { hbRun = false; hb?.interrupt(); connected = false }

    fun upload(ctx: Context, uri: Uri, name: String, mime: String, kind: String): CloudRes {
        var len = -1L
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { if (it.moveToFirst()) len = it.getLong(0) }
        } catch (_: Exception) {}
        val src: InputStream
        if (len <= 0) {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return CloudRes(false, "Cannot open $name", true)
            len = bytes.size.toLong()
            src = ByteArrayInputStream(bytes)
        } else {
            src = ctx.contentResolver.openInputStream(uri) ?: return CloudRes(false, "Cannot open $name", true)
        }
        val c = URL(url(ctx, "/upload", "&kind=$kind&fname=${Cloud.enc(name)}&mime=${Cloud.enc(mime)}")).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 8000
            c.readTimeout = 120000
            c.setFixedLengthStreamingMode(len)
            src.use { i -> c.outputStream.use { o -> i.copyTo(o, 64 * 1024) } }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
            return when (code) {
                200 -> CloudRes(true, "ok")
                403 -> CloudRes(false, "Wrong pairing code", false)
                else -> CloudRes(false, "Server answered $code $body".take(100), false)
            }
        } finally { c.disconnect() }
    }

    private fun bytes(u: String): ByteArray? {
        val c = URL(u).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000; c.readTimeout = 30000
            if (c.responseCode == 200) c.inputStream.use { it.readBytes() } else null
        } finally { c.disconnect() }
    }

    /** Copies the server's templates to this device. Returns a message for the screen. */
    fun fetchTemplates(ctx: Context): String {
        return try {
            val h = Cloud.request(url(ctx, "/templates"), "GET")
            if (h.code == 403) return "Wrong pairing code"
            if (h.code != 200) return "Server answered ${h.code}"
            val arr = JSONArray(h.body)
            val local = TemplateStore.load(ctx)
            var n = 0
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.getString("id")
                val sa = o.getJSONArray("slots")
                val slots = ArrayList<Slot>()
                for (k in 0 until sa.length()) {
                    val s = sa.getJSONArray(k)
                    slots.add(Slot(s.getInt(0), s.getInt(1), s.getInt(2), s.getInt(3)))
                }
                val t = Template(id, o.getString("name"), o.getInt("wPx"), o.getInt("hPx"), o.getDouble("wIn"), o.getDouble("hIn"), o.getInt("bg"), o.getBoolean("overlay"), slots)
                if (t.hasOverlay) {
                    val data = bytes(url(ctx, "/overlay", "&tid=${Cloud.enc(id)}")) ?: continue
                    TemplateStore.overlayFile(ctx, id).writeBytes(data)
                }
                local.removeAll { it.id == id }
                local.add(t)
                n++
            }
            TemplateStore.save(ctx, local)
            "Downloaded $n template(s) from the server"
        } catch (e: Exception) { "Could not get templates: ${e.message}" }
    }
}
