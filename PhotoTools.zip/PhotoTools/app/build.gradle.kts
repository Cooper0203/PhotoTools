plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.phototools.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.phototools"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    flavorDimensions += "tool"
    productFlavors {
        create("canon") {
            dimension = "tool"
            applicationId = "com.phototools.canonsync"
            resValue("string", "app_name", "Canon Auto Copy")
        }
        create("facebook") {
            dimension = "tool"
            applicationId = "com.phototools.fbuploader"
            resValue("string", "app_name", "Facebook Auto Upload")
        }
        create("combo") {
            dimension = "tool"
            applicationId = "com.phototools.combo"
            resValue("string", "app_name", "Android Photobooth")
        }
    }
}

dependencies {
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.print:print:1.0.0")
    implementation("com.google.zxing:core:3.5.3")
}
