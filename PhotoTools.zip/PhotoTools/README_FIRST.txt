PhotoTools - 3 apps from ONE project
  canon    = Canon Auto Copy        (camera cable -> phone, live view, camera info tab, gallery, templates, printing, copy to flash drive)
  facebook = Facebook Auto Upload   (any number of photos -> Page album, via webhook, or profile via Facebook app)
  combo    = Android Photobooth     (all of the above except Camera Info tab + auto upload to Facebook / Drive, QR codes)
Build all 3 (GitHub Actions does this): gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
APKs appear in app/build/outputs/apk/<name>/debug/
