PhotoTools - 3 apps from ONE project
  canon    = Canon Auto Copy        (Full operation / Camera operator only / Server device only, Camera Info tab)
  facebook = Facebook Auto Upload   (any number of photos -> Page album, webhook, or profile via Facebook app)
  combo    = Android Photobooth     (same three modes, plus auto upload to Facebook / Google Drive folder / QR codes)
Camera source: Canon (USB), phone camera or front camera (Status tab).  Session tab: event name = folder name.
Build all 3 (GitHub Actions does this): gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
