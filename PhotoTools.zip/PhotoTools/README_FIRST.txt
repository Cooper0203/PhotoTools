PhotoTools - 3 apps from ONE project
  canon    = Canon Auto Copy        (Full operation / Camera operator only / Server device only, Camera Info tab)
  facebook = Facebook Auto Upload   (any number of photos -> Page album, webhook, or profile via Facebook app)
  combo    = Android Photobooth     (same three modes, plus auto upload to Facebook / Google Drive folder / QR codes)
Google Drive without developer setup: Settings > Google Drive > Choose Drive folder (Android file picker / SAF).
Build all 3 (GitHub Actions does this): gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
