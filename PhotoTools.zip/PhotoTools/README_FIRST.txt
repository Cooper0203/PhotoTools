PhotoTools - 3 apps from ONE project
  canon    = Canon Auto Copy        (camera cable -> phone, live view, gallery, templates, printing)
  facebook = Facebook Auto Upload   (any number of photos -> Page album, or profile via Facebook app)
  combo    = Android Photobooth     (everything in Canon Auto Copy + auto upload to Facebook album + Google Drive backup)
Build all 3 (GitHub Actions does this): gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
APKs appear in app/build/outputs/apk/<name>/debug/
