PhotoTools - 3 apps from ONE project (Android Studio / Code On The Go / GitHub)
  canon    = Canon Auto Copy         (camera cable -> phone, live, offline)
  facebook = Facebook Media Uploader (pick media/folder -> Facebook in batches)
  combo    = Photo Tools             (both in one app)
Build all 3:  gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
APKs appear in app/build/outputs/apk/<name>/debug/
Not tested on a real camera/phone yet - see the step-by-step guide.
