PhotoTools - 3 apps from ONE project
  canon    = Canon Auto Copy        (choose at start: Full operation / Camera operator only / Server device only)
  facebook = Facebook Auto Upload   (any number of photos -> Page album, webhook, or profile via Facebook app)
  combo    = Android Photobooth     (same three modes, plus auto upload to Facebook / Drive and QR codes)
Server mode receives files over Wi-Fi / hotspot (port 8765, pairing code). Operators find it automatically or by IP address.
Build all 3 (GitHub Actions does this): gradle assembleCanonDebug assembleFacebookDebug assembleComboDebug
